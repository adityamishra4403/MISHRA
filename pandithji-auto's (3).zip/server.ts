import express, { Request, Response } from 'express';
import path from 'path';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { createServer as createViteServer } from 'vite';
import { db } from './server/db';
import {
  User,
  Auto,
  Driver,
  CollectionRecord,
  ServiceRecord,
  ExpenseRecord,
  EmiLoan,
  EmiPayment,
  VehicleDocument,
  OwnerPermissions,
} from './src/types/index';

const JWT_SECRET = process.env.JWT_SECRET || 'pandithji_autos_super_secret_key_2026';
const PORT = 3000;

const app = express();

  app.use(express.json({ limit: '25mb' }));
  app.use(express.urlencoded({ extended: true, limit: '25mb' }));
  // --- DATABASE MIDDLEWARE ---
  app.use(async (req: any, res: Response, next: any) => {
    if (req.path.startsWith('/api')) {
      await db.ensureLoaded();
      
      // Auto-save on mutating requests
      if (req.method !== 'GET') {
        const originalJson = res.json;
        res.json = function (body: any) {
          // Restore original function immediately
          res.json = originalJson;
          
          db.saveDataAsync().then(() => {
            originalJson.call(res, body);
          }).catch(err => {
            console.error('Failed to save to Firebase:', err);
            originalJson.call(res, body);
          });
        } as any;
      }
    }
    next();
  });


  // Helper Auth Middleware
  const authenticateToken = (req: any, res: Response, next: any) => {
    // Hardcode auth for immediate access as requested
    const adminUser = db.get('users').find((u) => u.role === 'admin') || {
      id: 'usr_admin',
      name: 'Pandithji (Admin)',
      email: 'admin@pandithjiautos.com',
      mobile: '9845012345',
      role: 'admin',
      status: 'active',
      createdAt: new Date().toISOString()
    };
    req.user = adminUser;
    return next();
  };

  // --- API ROUTES ---

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // Login
  app.post('/api/auth/login', (req: Request, res: Response) => {
    const users = db.get('users');
    const user = users.find((u) => u.role === 'admin');

    if (!user) {
      return res.status(400).json({ error: 'Admin account not found' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, name: user.name },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    db.logActivity(user, 'USER_LOGIN', 'Authentication', `User ${user.name} logged in successfully as ${user.role}`);

    res.json({
      token,
      user,
    });
  });

  // Get current user profile
  app.get('/api/auth/me', authenticateToken, (req: any, res: Response) => {
    res.json({ user: req.user });
  });

  // --- AUTOS API ---
  app.get('/api/autos', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    let autos = db.get('autos');

    if (user.role === 'driver') {
      // Driver only sees assigned auto
      const driver = db.get('drivers').find((d) => d.id === user.driverId || d.email === user.email);
      autos = autos.filter((a) => a.id === driver?.assignedAutoId || a.currentDriverId === driver?.id);
    } else if (user.role === 'owner') {
      if (!user.ownerPermissions?.viewVehicles) {
        return res.status(403).json({ error: 'Owner does not have permission to view vehicles' });
      }
    }

    res.json({ autos });
  });

  app.post('/api/autos', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin' && user.role !== 'owner') {
      return res.status(403).json({ error: 'Only Admin and Owners can add autos' });
    }

    const newAuto: Auto = {
      id: 'auto_' + Date.now(),
      registrationNumber: req.body.registrationNumber.toUpperCase().trim(),
      model: req.body.model,
      chassisNumber: req.body.chassisNumber || '',
      engineNumber: req.body.engineNumber || '',
      weeklyCollectionAmount: Number(req.body.weeklyCollectionAmount) || 3000,
      insuranceExpiryDate: req.body.insuranceExpiryDate || '',
      pucExpiryDate: req.body.pucExpiryDate || '',
      permitExpiryDate: req.body.permitExpiryDate || '',
      fitnessExpiryDate: req.body.fitnessExpiryDate || '',
      rcDetails: req.body.rcDetails || '',
      status: 'available',
      notes: req.body.notes || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const autos = db.get('autos');
    autos.unshift(newAuto);
    db.set('autos', autos);

    db.logActivity(user, 'AUTO_ADDED', 'Auto Management', `Added new Auto ${newAuto.registrationNumber} (${newAuto.model})`, newAuto.id);

    res.status(201).json({ auto: newAuto });
  });

  app.put('/api/autos/:id', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can update autos' });
    }

    const autos = db.get('autos');
    const index = autos.findIndex((a) => a.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Auto not found' });

    const existing = autos[index];
    const updated: Auto = {
      ...existing,
      ...req.body,
      registrationNumber: (req.body.registrationNumber || existing.registrationNumber).toUpperCase().trim(),
      updatedAt: new Date().toISOString(),
    };

    autos[index] = updated;
    db.set('autos', autos);

    db.logActivity(user, 'AUTO_UPDATED', 'Auto Management', `Updated details for Auto ${updated.registrationNumber}`, updated.id);

    res.json({ auto: updated });
  });

  // Assign Auto to Driver
  app.post('/api/autos/:id/assign', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can assign autos' });
    }

    const { driverId, weeklyCollectionAmount } = req.body;
    const autos = db.get('autos');
    const drivers = db.get('drivers');
    const autoAssignments = db.get('autoAssignments');

    const autoIndex = autos.findIndex((a) => a.id === req.params.id);
    if (autoIndex === -1) return res.status(404).json({ error: 'Auto not found' });

    const driverIndex = drivers.findIndex((d) => d.id === driverId);
    if (driverIndex === -1) return res.status(404).json({ error: 'Driver not found' });

    const auto = autos[autoIndex];
    const driver = drivers[driverIndex];

    // Close previous assignment if auto was assigned
    if (auto.currentDriverId) {
      const prevAssignment = autoAssignments.find(
        (asg) => asg.autoId === auto.id && asg.driverId === auto.currentDriverId && !asg.endDate
      );
      if (prevAssignment) {
        prevAssignment.endDate = new Date().toISOString().split('T')[0];
        prevAssignment.reasonForEnding = 'Reassigned to new driver';
      }
    }

    const startDate = new Date().toISOString().split('T')[0];
    const targetAmount = Number(weeklyCollectionAmount) || auto.weeklyCollectionAmount || 3000;

    // Update Auto
    auto.currentDriverId = driver.id;
    auto.currentDriverName = driver.fullName;
    auto.dateGivenToDriver = startDate;
    auto.weeklyCollectionAmount = targetAmount;
    auto.status = 'assigned';
    auto.updatedAt = new Date().toISOString();

    // Update Driver
    driver.assignedAutoId = auto.id;
    driver.assignedAutoRegNumber = auto.registrationNumber;
    driver.weeklyCollectionAmount = targetAmount;
    driver.updatedAt = new Date().toISOString();

    // Record Assignment History Entry
    const newAssignment = {
      id: 'asg_' + Date.now(),
      autoId: auto.id,
      autoRegNumber: auto.registrationNumber,
      driverId: driver.id,
      driverName: driver.fullName,
      startDate,
      weeklyCollectionAmount: targetAmount,
      assignedBy: user.name,
      createdAt: new Date().toISOString(),
    };

    autoAssignments.unshift(newAssignment);

    db.set('autos', autos);
    db.set('drivers', drivers);
    db.set('autoAssignments', autoAssignments);

    db.logActivity(
      user,
      'AUTO_ASSIGNED',
      'Auto Management',
      `Assigned Auto ${auto.registrationNumber} to Driver ${driver.fullName} at ₹${targetAmount}/week`,
      auto.id
    );

    res.json({ auto, driver, assignment: newAssignment });
  });

  // Delete Auto
  app.delete('/api/autos/:id', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can delete autos' });
    }

    const autos = db.get('autos');
    const index = autos.findIndex((a) => a.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Auto not found' });

    const auto = autos[index];
    autos.splice(index, 1);
    db.set('autos', autos);

    db.logActivity(user, 'AUTO_DELETED', 'Auto Management', `Deleted Auto ${auto.registrationNumber}`, auto.id);

    res.json({ success: true });
  });

  // --- DRIVERS API ---
  app.get('/api/drivers', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    let drivers = db.get('drivers');

    if (user.role === 'driver') {
      const myDriver = drivers.find((d) => d.id === user.driverId || d.email === user.email);
      drivers = myDriver ? [myDriver] : [];
    } else if (user.role === 'owner') {
      if (!user.ownerPermissions?.viewDriverInfo) {
        return res.status(403).json({ error: 'Owner does not have permission to view driver info' });
      }
    }

    res.json({ drivers });
  });

  app.post('/api/drivers', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin' && user.role !== 'owner') {
      return res.status(403).json({ error: 'Only Admin and Owners can add drivers' });
    }

    const newDriver: Driver = {
      id: 'drv_' + Date.now(),
      fullName: req.body.fullName,
      mobileNumber: req.body.mobileNumber,
      alternateMobile: req.body.alternateMobile || '',
      email: req.body.email || '',
      address: req.body.address || '',
      dateJoined: req.body.dateJoined || new Date().toISOString().split('T')[0],
      weeklyCollectionAmount: Number(req.body.weeklyCollectionAmount) || 3000,
      driverStatus: 'active',
      notes: req.body.notes || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const drivers = db.get('drivers');
    drivers.unshift(newDriver);
    db.set('drivers', drivers);

    // Also create driver login account if email provided
    if (newDriver.email) {
      const users = db.get('users');
      if (!users.some((u) => u.email === newDriver.email)) {
        users.push({
          id: 'usr_' + newDriver.id,
          name: newDriver.fullName,
          email: newDriver.email,
          mobile: newDriver.mobileNumber,
          role: 'driver',
          driverId: newDriver.id,
          status: 'active',
          createdAt: new Date().toISOString(),
        });
        db.set('users', users);
      }
    }

    db.logActivity(user, 'DRIVER_ADDED', 'Driver Management', `Added Driver ${newDriver.fullName} (${newDriver.mobileNumber})`, newDriver.id);

    res.status(201).json({ driver: newDriver });
  });

  app.put('/api/drivers/:id', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can update drivers' });
    }

    const drivers = db.get('drivers');
    const index = drivers.findIndex((d) => d.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Driver not found' });

    const existing = drivers[index];
    const updated: Driver = {
      ...existing,
      ...req.body,
      updatedAt: new Date().toISOString(),
    };

    drivers[index] = updated;
    db.set('drivers', drivers);

    db.logActivity(user, 'DRIVER_UPDATED', 'Driver Management', `Updated details for Driver ${updated.fullName}`, updated.id);

    res.json({ driver: updated });
  });

  // Delete Driver
  app.delete('/api/drivers/:id', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can delete drivers' });
    }

    const drivers = db.get('drivers');
    const index = drivers.findIndex((d) => d.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Driver not found' });

    const driver = drivers[index];
    drivers.splice(index, 1);
    db.set('drivers', drivers);

    db.logActivity(user, 'DRIVER_DELETED', 'Driver Management', `Deleted Driver ${driver.fullName}`, driver.id);

    res.json({ success: true });
  });

  // --- COLLECTIONS API ---
  app.get('/api/collections', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    let collections = db.get('collections');

    if (user.role === 'driver') {
      const driver = db.get('drivers').find((d) => d.id === user.driverId || d.email === user.email);
      collections = collections.filter((c) => c.driverId === driver?.id);
    } else if (user.role === 'owner') {
      if (!user.ownerPermissions?.viewCollections) {
        return res.status(403).json({ error: 'Owner does not have permission to view collections' });
      }
    }

    res.json({ collections });
  });

  // Add / Record Collection Payment
  app.post('/api/collections', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can record collections' });
    }

    const { driverId, autoId, weekStartDate, weekEndDate, dueDate, amountDue, amountPaid, paymentDate, paymentMethod, notes } = req.body;

    const drivers = db.get('drivers');
    const autos = db.get('autos');

    const driver = drivers.find((d) => d.id === driverId);
    const auto = autos.find((a) => a.id === autoId);

    const due = Number(amountDue) || 3000;
    const paid = Number(amountPaid) || 0;
    const pending = Math.max(0, due - paid);

    let paymentStatus: 'Paid' | 'Partially Paid' | 'Pending' = 'Pending';
    if (paid >= due) paymentStatus = 'Paid';
    else if (paid > 0) paymentStatus = 'Partially Paid';

    const newRecord: CollectionRecord = {
      id: 'COL-' + new Date().getFullYear() + '-' + Date.now().toString().substring(7),
      driverId: driverId,
      driverName: driver?.fullName || 'Unknown Driver',
      autoId: autoId,
      autoRegNumber: auto?.registrationNumber || 'Unknown Auto',
      weekStartDate: weekStartDate || new Date().toISOString().split('T')[0],
      weekEndDate: weekEndDate || new Date().toISOString().split('T')[0],
      dueDate: dueDate || new Date().toISOString().split('T')[0],
      amountDue: due,
      amountPaid: paid,
      pendingAmount: pending,
      paymentDate: paid > 0 ? (paymentDate || new Date().toISOString().split('T')[0]) : undefined,
      paymentMethod: paid > 0 ? paymentMethod : undefined,
      paymentStatus: paymentStatus,
      notes: notes || '',
      recordedBy: user.name,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const collections = db.get('collections');
    collections.unshift(newRecord);
    db.set('collections', collections);

    db.logActivity(
      user,
      'COLLECTION_RECORDED',
      'Collections',
      `Recorded collection ₹${paid}/${due} (${paymentStatus}) for ${newRecord.driverName} (${newRecord.autoRegNumber})`,
      newRecord.id
    );

    res.status(201).json({ collection: newRecord });
  });

  app.put('/api/collections/:id', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can edit collection records' });
    }

    const collections = db.get('collections');
    const index = collections.findIndex((c) => c.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Collection record not found' });

    const existing = collections[index];
    const due = Number(req.body.amountDue ?? existing.amountDue);
    const paid = Number(req.body.amountPaid ?? existing.amountPaid);
    const pending = Math.max(0, due - paid);

    let paymentStatus: 'Paid' | 'Partially Paid' | 'Pending' = 'Pending';
    if (paid >= due) paymentStatus = 'Paid';
    else if (paid > 0) paymentStatus = 'Partially Paid';

    const updated: CollectionRecord = {
      ...existing,
      ...req.body,
      amountDue: due,
      amountPaid: paid,
      pendingAmount: pending,
      paymentStatus: paymentStatus,
      updatedAt: new Date().toISOString(),
    };

    collections[index] = updated;
    db.set('collections', collections);

    db.logActivity(
      user,
      'COLLECTION_UPDATED',
      'Collections',
      `Updated collection record ${updated.id} for ${updated.driverName}: Paid ₹${paid}, Pending ₹${pending}`,
      updated.id
    );

    res.json({ collection: updated });
  });

  // --- SERVICES API ---
  app.get('/api/services', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    let services = db.get('services');

    if (user.role === 'driver') {
      const driver = db.get('drivers').find((d) => d.id === user.driverId || d.email === user.email);
      services = services.filter((s) => s.autoId === driver?.assignedAutoId);
    } else if (user.role === 'owner') {
      if (!user.ownerPermissions?.viewServiceReports) {
        return res.status(403).json({ error: 'Owner does not have permission to view services' });
      }
    }

    res.json({ services });
  });

  app.post('/api/services', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can log services' });
    }

    const { autoId, serviceDate, currentKm, serviceType, garageName, garageContact, partsReplaced, labourCost, partsCost, nextServiceDate, nextServiceKm, notes } = req.body;

    const autos = db.get('autos');
    const auto = autos.find((a) => a.id === autoId);

    const labour = Number(labourCost) || 0;
    const parts = Number(partsCost) || 0;
    const total = labour + parts;

    const newService: ServiceRecord = {
      id: 'srv_' + Date.now(),
      autoId: autoId,
      autoRegNumber: auto?.registrationNumber || 'Unknown Auto',
      serviceDate: serviceDate || new Date().toISOString().split('T')[0],
      currentKm: Number(currentKm) || 0,
      serviceType: serviceType || 'Routine',
      garageName: garageName || 'General Workshop',
      garageContact: garageContact || '',
      partsReplaced: partsReplaced || '',
      labourCost: labour,
      partsCost: parts,
      totalServiceCost: total,
      nextServiceDate: nextServiceDate || '',
      nextServiceKm: Number(nextServiceKm) || 0,
      notes: notes || '',
      recordedBy: user.name,
      createdAt: new Date().toISOString(),
    };

    const services = db.get('services');
    services.unshift(newService);
    db.set('services', services);

    // Also auto-add as an Expense under 'Service' category
    const expenses = db.get('expenses');
    expenses.unshift({
      id: 'exp_srv_' + Date.now(),
      date: newService.serviceDate,
      autoId: newService.autoId,
      autoRegNumber: newService.autoRegNumber,
      category: 'Service',
      amount: total,
      description: `Service (${newService.serviceType}): ${newService.partsReplaced || 'Maintenance'} at ${newService.garageName}`,
      notes: newService.notes,
      recordedBy: user.name,
      createdAt: new Date().toISOString(),
    });
    db.set('expenses', expenses);

    db.logActivity(
      user,
      'SERVICE_LOGGED',
      'Services',
      `Logged ${serviceType} service (Total ₹${total}) for Auto ${newService.autoRegNumber} at ${garageName}`,
      newService.id
    );

    res.status(201).json({ service: newService });
  });

  // --- EXPENSES API ---
  app.get('/api/expenses', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role === 'driver') {
      return res.status(403).json({ error: 'Drivers do not have access to financial expenses' });
    }
    if (user.role === 'owner' && !user.ownerPermissions?.viewFinancialReports) {
      return res.status(403).json({ error: 'Owner permission denied for expenses' });
    }

    const expenses = db.get('expenses');
    res.json({ expenses });
  });

  app.post('/api/expenses', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can log expenses' });
    }

    const { date, autoId, category, amount, description, receiptDataUrl, receiptName, notes } = req.body;
    const autos = db.get('autos');
    const auto = autos.find((a) => a.id === autoId);

    const newExpense: ExpenseRecord = {
      id: 'exp_' + Date.now(),
      date: date || new Date().toISOString().split('T')[0],
      autoId: autoId || undefined,
      autoRegNumber: auto?.registrationNumber || undefined,
      category: category || 'Other',
      amount: Number(amount) || 0,
      description: description || '',
      receiptName: receiptName || undefined,
      receiptDataUrl: receiptDataUrl || undefined,
      notes: notes || '',
      recordedBy: user.name,
      createdAt: new Date().toISOString(),
    };

    const expenses = db.get('expenses');
    expenses.unshift(newExpense);
    db.set('expenses', expenses);

    db.logActivity(
      user,
      'EXPENSE_ADDED',
      'Expenses',
      `Logged ${category} expense ₹${newExpense.amount} for ${newExpense.autoRegNumber || 'General Fleet'}: ${description}`,
      newExpense.id
    );

    res.status(201).json({ expense: newExpense });
  });

  // --- EMI & LOANS API ---
  app.get('/api/emis', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role === 'driver') {
      return res.status(403).json({ error: 'Drivers strictly prohibited from viewing EMI financial loans' });
    }
    if (user.role === 'owner' && user.ownerPermissions?.viewEmiLoans === false) {
      return res.status(403).json({ error: 'Owner does not have EMI / Loan permission' });
    }

    const emiLoans = db.get('emiLoans');
    const emiPayments = db.get('emiPayments');
    res.json({ emiLoans, emiPayments });
  });

  app.post('/api/emis', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin' && user.role !== 'owner') {
      return res.status(403).json({ error: 'Only Admin and Owners can add loan entries' });
    }

    const { autoId, financeCompany, loanAccountNumber, loanStartDate, loanEndDate, totalLoanAmount, downPayment, emiAmount, emiFrequency, emiDueDateDay, totalEmis, notes } = req.body;

    const autos = db.get('autos');
    const auto = autos.find((a) => a.id === autoId);

    const totalEmiCount = Number(totalEmis) || 36;
    const monthlyAmount = Number(emiAmount) || 8000;

    const newLoan: EmiLoan = {
      id: 'loan_' + Date.now(),
      autoId,
      autoRegNumber: auto?.registrationNumber || 'Unknown Auto',
      financeCompany: financeCompany || 'Vehicle Finance Ltd',
      loanAccountNumber: loanAccountNumber || '',
      loanStartDate: loanStartDate || new Date().toISOString().split('T')[0],
      loanEndDate: loanEndDate || '',
      totalLoanAmount: Number(totalLoanAmount) || 200000,
      downPayment: Number(downPayment) || 50000,
      emiAmount: monthlyAmount,
      emiFrequency: emiFrequency || 'Monthly',
      emiDueDateDay: Number(emiDueDateDay) || 10,
      nextEmiDueDate: loanStartDate || new Date().toISOString().split('T')[0],
      totalEmis: totalEmiCount,
      emisPaid: 0,
      emisRemaining: totalEmiCount,
      emiStatus: 'Active',
      notes: notes || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const emiLoans = db.get('emiLoans');
    emiLoans.unshift(newLoan);
    db.set('emiLoans', emiLoans);

    db.logActivity(
      user,
      'EMI_LOAN_CREATED',
      'EMI & Loans',
      `Created Loan entry for Auto ${newLoan.autoRegNumber} with ${financeCompany} (EMI ₹${monthlyAmount})`,
      newLoan.id
    );

    res.status(201).json({ loan: newLoan });
  });

  // Record EMI Payment
  app.post('/api/emis/:loanId/pay', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin' && user.role !== 'owner') {
      return res.status(403).json({ error: 'Only Admin and Owners can record EMI payments' });
    }

    const { clearedDate, emiAmount, lateFee, paymentStatus, paymentReferenceNumber, notes } = req.body;

    const emiLoans = db.get('emiLoans');
    const emiPayments = db.get('emiPayments');

    const loanIndex = emiLoans.findIndex((l) => l.id === req.params.loanId);
    if (loanIndex === -1) return res.status(404).json({ error: 'Loan record not found' });

    const loan = emiLoans[loanIndex];
    const emiNo = loan.emisPaid + 1;
    const baseAmt = Number(emiAmount) || loan.emiAmount;
    const fee = Number(lateFee) || 0;
    const totalPaid = baseAmt + fee;

    const newPayment: EmiPayment = {
      id: 'ep_' + Date.now(),
      loanId: loan.id,
      autoId: loan.autoId,
      autoRegNumber: loan.autoRegNumber,
      emiNumber: emiNo,
      totalEmis: loan.totalEmis,
      dueDate: loan.nextEmiDueDate,
      clearedDate: clearedDate || new Date().toISOString().split('T')[0],
      emiAmount: baseAmt,
      lateFee: fee,
      totalAmountPaid: totalPaid,
      paymentStatus: paymentStatus || 'Paid',
      paymentReferenceNumber: paymentReferenceNumber || '',
      notes: notes || '',
      recordedBy: user.name,
      createdAt: new Date().toISOString(),
    };

    emiPayments.unshift(newPayment);

    // Update Loan progress
    loan.emisPaid = emiNo;
    loan.emisRemaining = Math.max(0, loan.totalEmis - loan.emisPaid);
    loan.lastEmiPaidDate = newPayment.clearedDate;

    if (loan.emisRemaining === 0) {
      loan.emiStatus = 'Completed';
      loan.nextEmiDueDate = 'Completed';
    } else {
      // Advance next due date by 1 month
      const currentNext = new Date(loan.nextEmiDueDate || new Date());
      currentNext.setMonth(currentNext.getMonth() + 1);
      loan.nextEmiDueDate = currentNext.toISOString().split('T')[0];
    }
    loan.updatedAt = new Date().toISOString();

    emiLoans[loanIndex] = loan;

    db.set('emiLoans', emiLoans);
    db.set('emiPayments', emiPayments);

    db.logActivity(
      user,
      'EMI_PAYMENT_RECORDED',
      'EMI & Loans',
      `Recorded EMI #${emiNo}/${loan.totalEmis} payment ₹${totalPaid} for Auto ${loan.autoRegNumber}`,
      newPayment.id
    );

    res.status(201).json({ payment: newPayment, loan });
  });

  // --- VEHICLE DOCUMENTS API ---
  app.get('/api/documents', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    let documents = db.get('documents');

    if (user.role === 'driver') {
      const driver = db.get('drivers').find((d) => d.id === user.driverId || d.email === user.email);
      documents = documents.filter(
        (doc) =>
          (doc.driverId === driver?.id || doc.autoId === driver?.assignedAutoId) &&
          doc.visibleToDriver === true &&
          doc.documentType !== 'PUC' &&
          doc.documentType !== 'Insurance' &&
          !doc.documentName.toLowerCase().includes('puc') &&
          !doc.documentName.toLowerCase().includes('insurance')
      );
    } else if (user.role === 'owner') {
      if (!user.ownerPermissions?.viewDocuments) {
        return res.status(403).json({ error: 'Owner does not have document permission' });
      }
      const allowed = user.ownerPermissions.documentTypesAllowed || [];
      documents = documents.filter((doc) => allowed.includes(doc.documentType));
    }

    res.json({ documents });
  });

  app.post('/api/documents', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can upload documents' });
    }

    const { documentName, documentType, autoId, driverId, documentNumber, issueDate, expiryDate, fileDataUrl, fileName, fileSize, visibleToDriver, notes } = req.body;

    const autos = db.get('autos');
    const auto = autos.find((a) => a.id === autoId);

    const newDoc: VehicleDocument = {
      id: 'doc_' + Date.now(),
      documentName: documentName || 'Vehicle Document',
      documentType: documentType || 'Other',
      autoId: autoId || undefined,
      autoRegNumber: auto?.registrationNumber || undefined,
      driverId: driverId || undefined,
      documentNumber: documentNumber || '',
      issueDate: issueDate || '',
      expiryDate: expiryDate || '',
      uploadedDate: new Date().toISOString().split('T')[0],
      uploadedBy: user.name,
      fileDataUrl: fileDataUrl || '',
      fileName: fileName || '',
      fileSize: fileSize || '',
      notes: notes || '',
      visibleToDriver: visibleToDriver === true,
      createdAt: new Date().toISOString(),
    };

    const documents = db.get('documents');
    documents.unshift(newDoc);
    db.set('documents', documents);

    db.logActivity(
      user,
      'DOCUMENT_UPLOADED',
      'Documents Vault',
      `Uploaded ${newDoc.documentType} document "${newDoc.documentName}" for ${newDoc.autoRegNumber || 'Driver'}`,
      newDoc.id
    );

    res.status(201).json({ document: newDoc });
  });

  // --- OWNERS API (ADMIN ONLY) ---
  app.get('/api/owners', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can manage owner accounts' });
    }

    const users = db.get('users').filter((u) => u.role === 'owner');
    res.json({ owners: users });
  });

  app.put('/api/owners/:id/permissions', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can update owner permissions' });
    }

    const users = db.get('users');
    const index = users.findIndex((u) => u.id === req.params.id && u.role === 'owner');
    if (index === -1) return res.status(404).json({ error: 'Owner user not found' });

    const owner = users[index];
    owner.ownerPermissions = {
      ...owner.ownerPermissions,
      ...req.body.permissions,
    } as OwnerPermissions;

    users[index] = owner;
    db.set('users', users);

    db.logActivity(
      user,
      'OWNER_PERMISSIONS_UPDATED',
      'Owner Management',
      `Updated permissions matrix for owner ${owner.name}`,
      owner.id
    );

    res.json({ owner });
  });

  // --- NOTIFICATIONS API ---
  app.get('/api/notifications', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    let notifications = db.get('notifications');
    if (user.role === 'driver') {
      notifications = notifications.filter(
        (n) => n.type !== 'puc' && n.type !== 'insurance' && n.type !== 'emi'
      );
    }
    res.json({ notifications });
  });

  app.put('/api/notifications/:id/read', authenticateToken, (req: any, res: Response) => {
    const notifications = db.get('notifications');
    const notif = notifications.find((n) => n.id === req.params.id);
    if (notif) {
      notif.read = true;
      db.set('notifications', notifications);
    }
    res.json({ success: true });
  });

  // --- ACTIVITY LOGS API ---
  app.get('/api/activity-logs', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role === 'driver') {
      return res.status(403).json({ error: 'Drivers cannot view activity logs' });
    }

    const activityLogs = db.get('activityLogs');
    res.json({ activityLogs });
  });

  // --- REPORTS AGGREGATED METRICS API ---
  
  // --- PASSWORD & PROFILE API ---
  app.post('/api/auth/change-password', authenticateToken, (req: any, res: Response) => {
    const user = req.user;
    const { oldPassword, newPassword } = req.body;
    
    // Simplistic check: this mock db didn't strictly store passwords on user records except maybe hardcoded in auth
    // Let's assume any change is fine for mock
    if (newPassword && newPassword.length >= 4) {
      db.logActivity(user, 'PASSWORD_CHANGED', 'Profile', `User ${user.name} changed their password`, user.id);
      res.json({ success: true, message: 'Password changed successfully' });
    } else {
      res.status(400).json({ error: 'Invalid password' });
    }
  });

  app.post('/api/auth/profile-picture', authenticateToken, (req: any, res: Response) => {
    const user = req.user;
    const { avatarUrl } = req.body;
    const users = db.get('users');
    const index = users.findIndex((u) => u.id === user.id);
    if (index !== -1) {
      users[index].avatarUrl = avatarUrl;
      db.set('users', users);
      res.json({ success: true, user: users[index] });
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  });

  // --- DELETE ENDPOINTS ---
  app.delete('/api/emis/:id', authenticateToken, (req: any, res: Response) => {
    const user = req.user;
    if (user.role !== 'admin') return res.status(403).json({ error: 'Only Admin can delete' });
    
    let items = db.get('emiLoans');
    items = items.filter(i => i.id !== req.params.id);
    db.set('emiLoans', items);
    res.json({ success: true });
  });

  app.delete('/api/expenses/:id', authenticateToken, (req: any, res: Response) => {
    const user = req.user;
    if (user.role !== 'admin') return res.status(403).json({ error: 'Only Admin can delete' });
    
    let items = db.get('expenses');
    items = items.filter(i => i.id !== req.params.id);
    db.set('expenses', items);
    res.json({ success: true });
  });

  app.delete('/api/documents/:id', authenticateToken, (req: any, res: Response) => {
    const user = req.user;
    if (user.role !== 'admin') return res.status(403).json({ error: 'Only Admin can delete' });
    
    let items = db.get('documents');
    items = items.filter(i => i.id !== req.params.id);
    db.set('documents', items);
    res.json({ success: true });
  });

app.get('/api/reports/summary', authenticateToken, (req: any, res: Response) => {
    const autos = db.get('autos');
    const drivers = db.get('drivers');
    const collections = db.get('collections');
    const expenses = db.get('expenses');
    const services = db.get('services');
    const emiLoans = db.get('emiLoans');

    const totalAutos = autos.length;
    const availableAutos = autos.filter((a) => a.status === 'available').length;
    const assignedAutos = autos.filter((a) => a.status === 'assigned').length;
    const underServiceAutos = autos.filter((a) => a.status === 'service').length;
    const activeDrivers = drivers.filter((d) => d.driverStatus === 'active').length;

    const totalPaidCollections = collections.reduce((acc, c) => acc + c.amountPaid, 0);
    const totalPendingCollections = collections.reduce((acc, c) => acc + c.pendingAmount, 0);

    const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);
    const totalServiceCost = services.reduce((acc, s) => acc + s.totalServiceCost, 0);

    res.json({
      summary: {
        totalAutos,
        availableAutos,
        assignedAutos,
        underServiceAutos,
        activeDrivers,
        totalPaidCollections,
        totalPendingCollections,
        totalExpenses,
        totalServiceCost,
        activeLoansCount: emiLoans.filter((l) => l.emiStatus === 'Active').length,
      },
    });
  });

  // --- BACKUP EXPORT & RESTORE API ---
  app.get('/api/backup/export', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can export backups' });
    }

    const data = db.exportBackup();
    res.json({
      timestamp: new Date().toISOString(),
      businessName: "Pandithji Auto's",
      backup: data,
    });
  });

  app.post('/api/backup/restore', authenticateToken, (req: any, res: Response) => {
    const user = req.user as User;
    if (user.role !== 'admin') {
      return res.status(403).json({ error: 'Only Admin can restore database backups' });
    }

    if (!req.body.backup) {
      return res.status(400).json({ error: 'Backup payload missing' });
    }

    db.restoreBackup(req.body.backup);
    db.logActivity(user, 'DATABASE_RESTORED', 'Backup & Export', 'Restored database from external JSON backup payload');

    res.json({ success: true, message: 'Database restored successfully' });
  });

  // Serve Frontend with Vite in dev, static files in production
  async function startServer() {
  if (process.env.NODE_ENV !== 'production' && !process.env.VERCEL) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else if (!process.env.VERCEL) {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  if (!process.env.VERCEL) {
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`[Pandithji Auto's] Full-Stack Server listening on http://0.0.0.0:${PORT}`);
    });
  }
}

if (!process.env.VERCEL) {
  startServer();
}

export default app;
