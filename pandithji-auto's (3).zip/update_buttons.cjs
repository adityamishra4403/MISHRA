const fs = require('fs');

const files = [
  'src/components/autos/AutoList.tsx',
  'src/components/drivers/DriverList.tsx',
  'src/components/emis/EmiList.tsx',
  'src/components/expenses/ExpenseList.tsx'
];

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf-8');
  
  if (file.includes('AutoList.tsx')) {
    content = content.replace(/<Trash2 className="w-4 h-4" \/>\s*<\/button>/g, '<Trash2 className="w-4 h-4" /> <span className="hidden sm:inline">Delete</span></button>');
    content = content.replace(/className="p-1\.5 text-rose-500/g, 'className="p-1.5 px-3 flex items-center space-x-1 text-rose-500 font-bold');
  }
  
  if (file.includes('DriverList.tsx')) {
    content = content.replace(/<Trash2 className="w-4 h-4" \/>\s*<\/button>/g, '<Trash2 className="w-4 h-4" /> <span className="hidden sm:inline">Delete</span></button>');
    content = content.replace(/className="p-1\.5 text-rose-500/g, 'className="p-1.5 px-3 flex items-center space-x-1 text-rose-500 font-bold');
  }

  if (file.includes('EmiList.tsx')) {
    content = content.replace(/<Trash2 className="w-4 h-4" \/>\s*<\/button>/g, '<Trash2 className="w-4 h-4" /> <span className="hidden sm:inline">Delete</span></button>');
    content = content.replace(/className="p-1\.5 text-rose-500/g, 'className="p-1.5 px-3 flex items-center space-x-1 text-rose-500 font-bold');
  }
  
  if (file.includes('ExpenseList.tsx')) {
    content = content.replace(/<Trash2 className="w-4 h-4" \/>\s*<\/button>/g, '<Trash2 className="w-4 h-4" /> <span className="hidden sm:inline">Delete</span></button>');
    content = content.replace(/className="p-1\.5 text-rose-500/g, 'className="p-1.5 px-3 flex items-center space-x-1 text-rose-500 font-bold');
  }

  fs.writeFileSync(file, content);
});
