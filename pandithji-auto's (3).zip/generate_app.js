const fs = require('fs');

// since I can't read the whole file from history easily inside the bash script,
// I'll just write what I know should be there.
