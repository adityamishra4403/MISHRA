import fs from 'fs';
import path from 'path';
import { initializeApp } from 'firebase/app';
import { getFirestore, doc, getDoc, setDoc } from 'firebase/firestore';

const firebaseConfigPath = path.join(process.cwd(), 'firebase-applet-config.json');
let firebaseConfig = {};
try {
  firebaseConfig = JSON.parse(fs.readFileSync(firebaseConfigPath, 'utf-8'));
} catch (e) {
  console.warn('Could not load firebase-applet-config.json');
}
const app = initializeApp(firebaseConfig);
const firestoreDb = getFirestore(app);

import {
  User,
  Auto,
  Driver,
  AutoAssignment,
  CollectionRecord,
  ServiceRecord,
  ExpenseRecord,
  EmiLoan,
  EmiPayment,
  VehicleDocument,
  NotificationItem,
  ActivityLog,
} from '../src/types/index';

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = process.env.VERCEL ? path.join('/tmp', 'db.json') : path.join(DATA_DIR, 'db.json');

export interface DatabaseSchema {
  users: User[];
  autos: Auto[];
  drivers: Driver[];
  autoAssignments: AutoAssignment[];
  collections: CollectionRecord[];
  services: ServiceRecord[];
  expenses: ExpenseRecord[];
  emiLoans: EmiLoan[];
  emiPayments: EmiPayment[];
  documents: VehicleDocument[];
  notifications: NotificationItem[];
  activityLogs: ActivityLog[];
}

const initialSeedData: DatabaseSchema = {
  users: [
    {
      id: 'usr_admin',
      name: 'Pandithji (Admin)',
      email: 'admin@pandithjiautos.com',
      mobile: '9845012345',
      role: 'admin',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      status: 'active',
      createdAt: '2025-01-01T00:00:00.000Z',
    }
  ],
  autos: [
    {
      id: 'auto_1',
      registrationNumber: 'KA-01-MJ-4012',
      model: 'Bajaj RE Compact 4T LPG',
      chassisNumber: 'MD2A15BZ4NC109823',
      engineNumber: 'AZX8829102',
      currentDriverId: 'drv_1',
      currentDriverName: 'Ramesh Kumar',
      dateGivenToDriver: '2025-01-15',
      weeklyCollectionAmount: 3000,
      insuranceExpiryDate: '2026-09-15',
      pucExpiryDate: '2026-08-25', // Expiring soon!
      permitExpiryDate: '2027-01-10',
      fitnessExpiryDate: '2027-01-10',
      rcDetails: 'Owner: Pandithji Auto\'s, Reg Date: 12-Jan-2023, RTO Indiranagar Bangalore',
      status: 'assigned',
      notes: 'Well maintained vehicle, assigned to senior driver Ramesh.',
      createdAt: '2025-01-01T00:00:00.000Z',
      updatedAt: '2025-01-15T00:00:00.000Z',
    },
    {
      id: 'auto_2',
      registrationNumber: 'KA-02-MH-8821',
      model: 'TVS King Deluxe CNG',
      chassisNumber: 'TVS44921098231',
      engineNumber: 'TVSENG9821',
      currentDriverId: 'drv_2',
      currentDriverName: 'Suresh Gowda',
      dateGivenToDriver: '2025-02-01',
      weeklyCollectionAmount: 3200,
      insuranceExpiryDate: '2026-11-20',
      pucExpiryDate: '2026-10-10',
      permitExpiryDate: '2027-03-15',
      fitnessExpiryDate: '2027-03-15',
      rcDetails: 'Owner: Pandithji Auto\'s, Reg Date: 20-Feb-2023, RTO Rajajinagar',
      status: 'assigned',
      notes: 'New CNG kit fitted in early 2025.',
      createdAt: '2025-01-01T00:00:00.000Z',
      updatedAt: '2025-02-01T00:00:00.000Z',
    },
    {
      id: 'auto_3',
      registrationNumber: 'KA-05-MK-9903',
      model: 'Piaggio Ape City Plus',
      chassisNumber: 'PIAG88291039',
      engineNumber: 'PIAGENG10293',
      currentDriverId: 'drv_3',
      currentDriverName: 'Venkatesh M',
      dateGivenToDriver: '2025-03-01',
      weeklyCollectionAmount: 2800,
      insuranceExpiryDate: '2026-08-18', // Expiring in ~11 days!
      pucExpiryDate: '2026-09-01',
      permitExpiryDate: '2026-12-01',
      fitnessExpiryDate: '2026-12-01',
      rcDetails: 'Owner: Pandithji Auto\'s, Reg Date: 05-Mar-2022, RTO Jayanagar',
      status: 'assigned',
      notes: 'Fully paid off loan.',
      createdAt: '2025-01-01T00:00:00.000Z',
      updatedAt: '2025-03-01T00:00:00.000Z',
    },
    {
      id: 'auto_4',
      registrationNumber: 'KA-03-MP-1102',
      model: 'Bajaj RE Optima Petrol',
      chassisNumber: 'MD2A15BZ4NC55819',
      engineNumber: 'AZX5581920',
      weeklyCollectionAmount: 3000,
      insuranceExpiryDate: '2026-12-30',
      pucExpiryDate: '2026-11-15',
      permitExpiryDate: '2027-04-20',
      fitnessExpiryDate: '2027-04-20',
      rcDetails: 'Owner: Pandithji Auto\'s, Reg Date: 10-Apr-2023, RTO KR Puram',
      status: 'service',
      notes: 'Currently in workshop for clutch plate replacement.',
      createdAt: '2025-01-01T00:00:00.000Z',
      updatedAt: '2026-08-05T00:00:00.000Z',
    },
    {
      id: 'auto_5',
      registrationNumber: 'KA-04-MM-7744',
      model: 'Bajaj Maxima Z Electric',
      chassisNumber: 'MD2EV98102391',
      engineNumber: 'EVMOTOR9812',
      weeklyCollectionAmount: 3500,
      insuranceExpiryDate: '2027-02-15',
      pucExpiryDate: 'N/A (Electric)',
      permitExpiryDate: '2028-02-15',
      fitnessExpiryDate: '2028-02-15',
      rcDetails: 'Owner: Pandithji Auto\'s, Reg Date: 15-Feb-2024, RTO Yelahanka',
      status: 'available',
      notes: 'Brand new EV Auto ready for new driver assignment.',
      createdAt: '2025-01-01T00:00:00.000Z',
      updatedAt: '2026-08-01T00:00:00.000Z',
    },
  ],
  drivers: [
    {
      id: 'drv_1',
      fullName: 'Ramesh Kumar',
      mobileNumber: '9876543210',
      alternateMobile: '9123456789',
      email: 'ramesh@gmail.com',
      address: '24th Main, JP Nagar 1st Phase, Bangalore',
      dateJoined: '2025-01-15',
      assignedAutoId: 'auto_1',
      assignedAutoRegNumber: 'KA-01-MJ-4012',
      weeklyCollectionAmount: 3000,
      driverStatus: 'active',
      notes: 'Punctual with collections. Driving since 10 years.',
      createdAt: '2025-01-15T00:00:00.000Z',
      updatedAt: '2025-01-15T00:00:00.000Z',
    },
    {
      id: 'drv_2',
      fullName: 'Suresh Gowda',
      mobileNumber: '9876543211',
      alternateMobile: '9988776655',
      email: 'suresh@gmail.com',
      address: '12th Cross, Malleshwaram, Bangalore',
      dateJoined: '2025-02-01',
      assignedAutoId: 'auto_2',
      assignedAutoRegNumber: 'KA-02-MH-8821',
      weeklyCollectionAmount: 3200,
      driverStatus: 'active',
      notes: 'Regular driver. Maintains vehicle cleanliness.',
      createdAt: '2025-02-01T00:00:00.000Z',
      updatedAt: '2025-02-01T00:00:00.000Z',
    },
    {
      id: 'drv_3',
      fullName: 'Venkatesh M',
      mobileNumber: '9876543212',
      address: 'Near Water Tank, Banashankari 3rd Stage, Bangalore',
      dateJoined: '2025-03-01',
      assignedAutoId: 'auto_3',
      assignedAutoRegNumber: 'KA-05-MK-9903',
      weeklyCollectionAmount: 2800,
      driverStatus: 'active',
      notes: 'Hardworking driver.',
      createdAt: '2025-03-01T00:00:00.000Z',
      updatedAt: '2025-03-01T00:00:00.000Z',
    },
    {
      id: 'drv_4',
      fullName: 'Syed Pasha',
      mobileNumber: '9876543213',
      address: 'Shivajinagar, Bangalore',
      dateJoined: '2025-06-10',
      weeklyCollectionAmount: 3000,
      driverStatus: 'active',
      notes: 'Relief driver awaiting vehicle allotment.',
      createdAt: '2025-06-10T00:00:00.000Z',
      updatedAt: '2025-06-10T00:00:00.000Z',
    },
  ],
  autoAssignments: [
    {
      id: 'asg_1',
      autoId: 'auto_1',
      autoRegNumber: 'KA-01-MJ-4012',
      driverId: 'drv_1',
      driverName: 'Ramesh Kumar',
      startDate: '2025-01-15',
      weeklyCollectionAmount: 3000,
      assignedBy: 'Pandithji (Owner)',
      createdAt: '2025-01-15T00:00:00.000Z',
    },
    {
      id: 'asg_2',
      autoId: 'auto_2',
      autoRegNumber: 'KA-02-MH-8821',
      driverId: 'drv_2',
      driverName: 'Suresh Gowda',
      startDate: '2025-02-01',
      weeklyCollectionAmount: 3200,
      assignedBy: 'Pandithji (Owner)',
      createdAt: '2025-02-01T00:00:00.000Z',
    },
    {
      id: 'asg_3',
      autoId: 'auto_3',
      autoRegNumber: 'KA-05-MK-9903',
      driverId: 'drv_3',
      driverName: 'Venkatesh M',
      startDate: '2025-03-01',
      weeklyCollectionAmount: 2800,
      assignedBy: 'Pandithji (Owner)',
      createdAt: '2025-03-01T00:00:00.000Z',
    },
  ],
  collections: [
    {
      id: 'COL-2026-W31-01',
      driverId: 'drv_1',
      driverName: 'Ramesh Kumar',
      autoId: 'auto_1',
      autoRegNumber: 'KA-01-MJ-4012',
      weekStartDate: '2026-07-28',
      weekEndDate: '2026-08-03',
      dueDate: '2026-08-03',
      amountDue: 3000,
      amountPaid: 3000,
      pendingAmount: 0,
      paymentDate: '2026-08-03',
      paymentMethod: 'UPI',
      paymentStatus: 'Paid',
      notes: 'GPay transferred fully on time.',
      recordedBy: 'Pandithji (Owner)',
      createdAt: '2026-08-03T10:00:00.000Z',
      updatedAt: '2026-08-03T10:00:00.000Z',
    },
    {
      id: 'COL-2026-W32-01',
      driverId: 'drv_1',
      driverName: 'Ramesh Kumar',
      autoId: 'auto_1',
      autoRegNumber: 'KA-01-MJ-4012',
      weekStartDate: '2026-08-04',
      weekEndDate: '2026-08-10',
      dueDate: '2026-08-10',
      amountDue: 3000,
      amountPaid: 2000,
      pendingAmount: 1000,
      paymentDate: '2026-08-06',
      paymentMethod: 'Cash',
      paymentStatus: 'Partially Paid',
      notes: 'Paid 2,000 cash, promised balance 1,000 on Saturday.',
      recordedBy: 'Pandithji (Owner)',
      createdAt: '2026-08-06T14:30:00.000Z',
      updatedAt: '2026-08-06T14:30:00.000Z',
    },
    {
      id: 'COL-2026-W31-02',
      driverId: 'drv_2',
      driverName: 'Suresh Gowda',
      autoId: 'auto_2',
      autoRegNumber: 'KA-02-MH-8821',
      weekStartDate: '2026-07-28',
      weekEndDate: '2026-08-03',
      dueDate: '2026-08-03',
      amountDue: 3200,
      amountPaid: 3200,
      pendingAmount: 0,
      paymentDate: '2026-08-02',
      paymentMethod: 'UPI',
      paymentStatus: 'Paid',
      notes: 'Full payment received.',
      recordedBy: 'Pandithji (Owner)',
      createdAt: '2026-08-02T18:15:00.000Z',
      updatedAt: '2026-08-02T18:15:00.000Z',
    },
    {
      id: 'COL-2026-W32-02',
      driverId: 'drv_2',
      driverName: 'Suresh Gowda',
      autoId: 'auto_2',
      autoRegNumber: 'KA-02-MH-8821',
      weekStartDate: '2026-08-04',
      weekEndDate: '2026-08-10',
      dueDate: '2026-08-10',
      amountDue: 3200,
      amountPaid: 0,
      pendingAmount: 3200,
      paymentStatus: 'Pending',
      notes: 'Payment due on 10th Aug.',
      recordedBy: 'Pandithji (Owner)',
      createdAt: '2026-08-04T09:00:00.000Z',
      updatedAt: '2026-08-04T09:00:00.000Z',
    },
    {
      id: 'COL-2026-W32-03',
      driverId: 'drv_3',
      driverName: 'Venkatesh M',
      autoId: 'auto_3',
      autoRegNumber: 'KA-05-MK-9903',
      weekStartDate: '2026-08-04',
      weekEndDate: '2026-08-10',
      dueDate: '2026-08-10',
      amountDue: 2800,
      amountPaid: 2800,
      pendingAmount: 0,
      paymentDate: '2026-08-07',
      paymentMethod: 'Cash',
      paymentStatus: 'Paid',
      notes: 'Paid in cash at shed.',
      recordedBy: 'Pandithji (Owner)',
      createdAt: '2026-08-07T11:00:00.000Z',
      updatedAt: '2026-08-07T11:00:00.000Z',
    },
  ],
  services: [
    {
      id: 'srv_1',
      autoId: 'auto_1',
      autoRegNumber: 'KA-01-MJ-4012',
      serviceDate: '2026-06-15',
      currentKm: 42500,
      serviceType: 'Routine',
      garageName: 'Sri Manjunatha Auto Garage, Jayanagar',
      garageContact: '9844011223',
      partsReplaced: 'Engine Oil (Castrol 20W40), Oil Filter, Spark Plug',
      labourCost: 400,
      partsCost: 850,
      totalServiceCost: 1250,
      nextServiceDate: '2026-09-15',
      nextServiceKm: 47500,
      notes: 'General inspection done, brake pads checked.',
      recordedBy: 'Pandithji (Owner)',
      createdAt: '2026-06-15T12:00:00.000Z',
    },
    {
      id: 'srv_2',
      autoId: 'auto_4',
      autoRegNumber: 'KA-03-MP-1102',
      serviceDate: '2026-08-05',
      currentKm: 38200,
      serviceType: 'Major Repair',
      garageName: 'National Auto Works, Indiranagar',
      garageContact: '9880192834',
      partsReplaced: 'Clutch Assembly, Accelerator Cable, Rear Brake Shoes',
      labourCost: 1200,
      partsCost: 3400,
      totalServiceCost: 4600,
      nextServiceDate: '2026-11-05',
      nextServiceKm: 43200,
      notes: 'Clutch slipped due to heavy traffic usage. Replacing complete assembly.',
      recordedBy: 'Pandithji (Owner)',
      createdAt: '2026-08-05T15:00:00.000Z',
    },
  ],
  expenses: [
    {
      id: 'exp_1',
      date: '2026-08-01',
      autoId: 'auto_1',
      autoRegNumber: 'KA-01-MJ-4012',
      category: 'PUC',
      amount: 150,
      description: 'PUC emission test renewal at BPCL Petrol Bunk',
      notes: 'Valid for 6 months',
      recordedBy: 'Pandithji (Owner)',
      createdAt: '2026-08-01T10:00:00.000Z',
    },
    {
      id: 'exp_2',
      date: '2026-08-05',
      autoId: 'auto_4',
      autoRegNumber: 'KA-03-MP-1102',
      category: 'Repair',
      amount: 4600,
      description: 'Clutch assembly repair & brake replacement',
      notes: 'Bill paid to National Auto Works',
      recordedBy: 'Pandithji (Owner)',
      createdAt: '2026-08-05T16:00:00.000Z',
    },
    {
      id: 'exp_3',
      date: '2026-07-20',
      autoId: 'auto_2',
      autoRegNumber: 'KA-02-MH-8821',
      category: 'Insurance',
      amount: 3800,
      description: 'Annual Third Party + Comprehensive Insurance Renewal (United India)',
      notes: 'Policy # UI/2026/882109',
      recordedBy: 'Pandithji (Owner)',
      createdAt: '2026-07-20T11:00:00.000Z',
    },
  ],
  emiLoans: [
    {
      id: 'loan_1',
      autoId: 'auto_1',
      autoRegNumber: 'KA-01-MJ-4012',
      financeCompany: 'Cholamandalam Investment & Finance',
      loanAccountNumber: 'CHOLA-KA01-99201',
      loanStartDate: '2023-01-15',
      loanEndDate: '2026-01-15',
      totalLoanAmount: 220000,
      downPayment: 50000,
      emiAmount: 8500,
      emiFrequency: 'Monthly',
      emiDueDateDay: 10,
      nextEmiDueDate: '2026-08-10', // Due in 3 days!
      totalEmis: 36,
      emisPaid: 31,
      emisRemaining: 5,
      lastEmiPaidDate: '2026-07-09',
      emiStatus: 'Active',
      notes: 'Loan in final leg. 5 EMIs remaining.',
      createdAt: '2025-01-01T00:00:00.000Z',
      updatedAt: '2026-07-09T00:00:00.000Z',
    },
    {
      id: 'loan_2',
      autoId: 'auto_2',
      autoRegNumber: 'KA-02-MH-8821',
      financeCompany: 'Bajaj Finance Commercial Vehicles',
      loanAccountNumber: 'BAJAJ-CV-882100',
      loanStartDate: '2023-02-20',
      loanEndDate: '2026-02-20',
      totalLoanAmount: 240000,
      downPayment: 60000,
      emiAmount: 7800,
      emiFrequency: 'Monthly',
      emiDueDateDay: 15,
      nextEmiDueDate: '2026-08-15',
      totalEmis: 36,
      emisPaid: 30,
      emisRemaining: 6,
      lastEmiPaidDate: '2026-07-14',
      emiStatus: 'Active',
      notes: 'Punctual EMI history.',
      createdAt: '2025-01-01T00:00:00.000Z',
      updatedAt: '2026-07-14T00:00:00.000Z',
    },
    {
      id: 'loan_3',
      autoId: 'auto_3',
      autoRegNumber: 'KA-05-MK-9903',
      financeCompany: 'Shriram Finance Ltd',
      loanAccountNumber: 'SHRIRAM-CV-10923',
      loanStartDate: '2022-03-05',
      loanEndDate: '2025-03-05',
      totalLoanAmount: 200000,
      downPayment: 40000,
      emiAmount: 6500,
      emiFrequency: 'Monthly',
      emiDueDateDay: 5,
      nextEmiDueDate: 'Completed',
      totalEmis: 36,
      emisPaid: 36,
      emisRemaining: 0,
      lastEmiPaidDate: '2025-03-04',
      emiStatus: 'Completed',
      notes: 'No Objection Certificate (NOC) obtained from Shriram Finance.',
      createdAt: '2025-01-01T00:00:00.000Z',
      updatedAt: '2025-03-04T00:00:00.000Z',
    },
  ],
  emiPayments: [
    {
      id: 'ep_1',
      loanId: 'loan_1',
      autoId: 'auto_1',
      autoRegNumber: 'KA-01-MJ-4012',
      emiNumber: 31,
      totalEmis: 36,
      dueDate: '2026-07-10',
      clearedDate: '2026-07-09',
      emiAmount: 8500,
      lateFee: 0,
      totalAmountPaid: 8500,
      paymentStatus: 'Paid',
      paymentReferenceNumber: 'IMPS/619208129/CHOLA',
      notes: 'Paid via NetBanking before due date.',
      recordedBy: 'Pandithji (Owner)',
      createdAt: '2026-07-09T14:00:00.000Z',
    },
    {
      id: 'ep_2',
      loanId: 'loan_2',
      autoId: 'auto_2',
      autoRegNumber: 'KA-02-MH-8821',
      emiNumber: 30,
      totalEmis: 36,
      dueDate: '2026-07-15',
      clearedDate: '2026-07-14',
      emiAmount: 7800,
      lateFee: 0,
      totalAmountPaid: 7800,
      paymentStatus: 'Paid',
      paymentReferenceNumber: 'UPI/619488201/BAJAJ',
      notes: 'Paid via GPay.',
      recordedBy: 'Pandithji (Owner)',
      createdAt: '2026-07-14T16:20:00.000Z',
    },
  ],
  documents: [
    {
      id: 'doc_1',
      documentName: 'KA-01-MJ-4012 Registration Certificate (RC)',
      documentType: 'RC',
      autoId: 'auto_1',
      autoRegNumber: 'KA-01-MJ-4012',
      documentNumber: 'KA01/2023/RC/4012',
      issueDate: '2023-01-12',
      uploadedDate: '2025-01-01',
      uploadedBy: 'Pandithji (Owner)',
      visibleToDriver: true,
      notes: 'Original smart card RC with Indiranagar RTO.',
      createdAt: '2025-01-01T00:00:00.000Z',
    },
    {
      id: 'doc_2',
      documentName: 'KA-01-MJ-4012 Commercial Insurance Policy',
      documentType: 'Insurance',
      autoId: 'auto_1',
      autoRegNumber: 'KA-01-MJ-4012',
      documentNumber: 'UI/2025/4012-INS',
      issueDate: '2025-09-15',
      expiryDate: '2026-09-15',
      uploadedDate: '2025-09-15',
      uploadedBy: 'Pandithji (Owner)',
      visibleToDriver: true,
      notes: 'United India Insurance 1 Year Comprehensive',
      createdAt: '2025-09-15T00:00:00.000Z',
    },
    {
      id: 'doc_3',
      documentName: 'KA-01-MJ-4012 Pollution Under Control (PUC)',
      documentType: 'PUC',
      autoId: 'auto_1',
      autoRegNumber: 'KA-01-MJ-4012',
      documentNumber: 'PUC-KA01-88910',
      issueDate: '2026-02-25',
      expiryDate: '2026-08-25',
      uploadedDate: '2026-02-25',
      uploadedBy: 'Pandithji (Owner)',
      visibleToDriver: true,
      notes: 'Expiring on Aug 25, 2026',
      createdAt: '2026-02-25T00:00:00.000Z',
    },
    {
      id: 'doc_4',
      documentName: 'KA-01-MJ-4012 Loan Agreement & Sanction Letter',
      documentType: 'Loan/Finance Document',
      autoId: 'auto_1',
      autoRegNumber: 'KA-01-MJ-4012',
      documentNumber: 'CHOLA-SANCTION-99201',
      issueDate: '2023-01-15',
      uploadedDate: '2025-01-01',
      uploadedBy: 'Pandithji (Owner)',
      visibleToDriver: false, // Private financial doc
      notes: 'Confidential loan document with Cholamandalam.',
      createdAt: '2025-01-01T00:00:00.000Z',
    },
    {
      id: 'doc_5',
      documentName: 'Ramesh Kumar Driving License',
      documentType: 'Driver Licence',
      driverId: 'drv_1',
      documentNumber: 'KA0120180098210',
      issueDate: '2018-05-21',
      expiryDate: '2028-05-20',
      uploadedDate: '2025-01-15',
      uploadedBy: 'Pandithji (Owner)',
      visibleToDriver: true,
      notes: 'Transport Badge valid till May 2028.',
      createdAt: '2025-01-15T00:00:00.000Z',
    },
  ],
  notifications: [
    {
      id: 'notif_1',
      type: 'emi',
      title: 'EMI Due Soon: KA-01-MJ-4012',
      message: 'Monthly EMI of ₹8,500 for KA-01-MJ-4012 (Cholamandalam) is due on 10/08/2026.',
      severity: 'high',
      autoId: 'auto_1',
      autoRegNumber: 'KA-01-MJ-4012',
      dueDate: '2026-08-10',
      read: false,
      createdAt: '2026-08-07T08:00:00.000Z',
    },
    {
      id: 'notif_2',
      type: 'puc',
      title: 'PUC Expiry Warning: KA-01-MJ-4012',
      message: 'PUC certificate for KA-01-MJ-4012 expires on 25/08/2026 (18 days remaining).',
      severity: 'medium',
      autoId: 'auto_1',
      autoRegNumber: 'KA-01-MJ-4012',
      dueDate: '2026-08-25',
      read: false,
      createdAt: '2026-08-07T08:00:00.000Z',
    },
    {
      id: 'notif_3',
      type: 'insurance',
      title: 'Insurance Expiring Soon: KA-05-MK-9903',
      message: 'Commercial Insurance for KA-05-MK-9903 expires on 18/08/2026 (11 days remaining). Renew immediately!',
      severity: 'high',
      autoId: 'auto_3',
      autoRegNumber: 'KA-05-MK-9903',
      dueDate: '2026-08-18',
      read: false,
      createdAt: '2026-08-07T08:00:00.000Z',
    },
    {
      id: 'notif_4',
      type: 'collection',
      title: 'Pending Weekly Collection: Suresh Gowda',
      message: 'Weekly collection of ₹3,200 for KA-02-MH-8821 is pending for week ending 10/08/2026.',
      severity: 'medium',
      autoId: 'auto_2',
      autoRegNumber: 'KA-02-MH-8821',
      driverId: 'drv_2',
      dueDate: '2026-08-10',
      read: false,
      createdAt: '2026-08-07T08:00:00.000Z',
    },
  ],
  activityLogs: [
    {
      id: 'log_1',
      userId: 'usr_admin',
      userName: 'Pandithji (Owner)',
      userRole: 'admin',
      action: 'COLLECTION_RECORDED',
      module: 'Collections',
      recordId: 'COL-2026-W32-01',
      details: 'Recorded partial payment of ₹2,000 for driver Ramesh Kumar (Auto KA-01-MJ-4012). Pending balance: ₹1,000.',
      timestamp: '2026-08-06T14:30:00.000Z',
    },
    {
      id: 'log_2',
      userId: 'usr_admin',
      userName: 'Pandithji (Owner)',
      userRole: 'admin',
      action: 'AUTO_SERVICE_LOGGED',
      module: 'Services',
      recordId: 'srv_2',
      details: 'Logged major repair service ₹4,600 for Auto KA-03-MP-1102 at National Auto Works.',
      timestamp: '2026-08-05T15:00:00.000Z',
    },
    {
      id: 'log_3',
      userId: 'usr_admin',
      userName: 'Pandithji (Owner)',
      userRole: 'admin',
      action: 'EXPENSE_ADDED',
      module: 'Expenses',
      recordId: 'exp_2',
      details: 'Recorded repair expense ₹4,600 for Auto KA-03-MP-1102.',
      timestamp: '2026-08-05T16:00:00.000Z',
    },
  ],
};

class JsonDB {
  private data: DatabaseSchema | null = null;
  private loadPromise: Promise<void> | null = null;

  constructor() {}

  public async ensureLoaded() {
    if (this.data) return;
    if (!this.loadPromise) {
      this.loadPromise = this._loadFromFirestore();
    }
    await this.loadPromise;
  }

  private async _loadFromFirestore() {
    try {
      const docRef = doc(firestoreDb, 'db', 'main');
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        this.data = { ...initialSeedData, ...(docSnap.data() as DatabaseSchema) };
      } else {
        await setDoc(docRef, initialSeedData);
        this.data = initialSeedData;
      }
    } catch (err) {
      console.error('Error reading Firestore, fallback to seed data:', err);
      this.data = initialSeedData;
    }
  }

  public saveData(data?: DatabaseSchema) {
    if (data) this.data = data;
    // Synchronous signature kept to avoid breaking server.ts routes.
    // The actual save to Firestore will be done by saveDataAsync called by middleware.
  }

  public async saveDataAsync() {
    if (!this.data) return;
    try {
      const docRef = doc(firestoreDb, 'db', 'main');
      await setDoc(docRef, this.data);
    } catch (err) {
      console.error('Failed to save to Firestore:', err);
    }
  }

  public get<K extends keyof DatabaseSchema>(key: K): DatabaseSchema[K] {
    if (!this.data) throw new Error("Database not loaded yet");
    return this.data[key];
  }

  public set<K extends keyof DatabaseSchema>(key: K, value: DatabaseSchema[K]) {
    if (!this.data) return;
    this.data[key] = value;
  }

  public logActivity(
    user: { id: string; name: string; role: any },
    action: string,
    module: string,
    details: string,
    recordId?: string,
    originalValue?: string,
    updatedValue?: string
  ) {
    if (!this.data) return;
    const newLog: ActivityLog = {
      id: 'log_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action,
      module,
      recordId,
      details,
      originalValue,
      updatedValue,
      timestamp: new Date().toISOString(),
    };
    this.data.activityLogs.unshift(newLog);
    if (this.data.activityLogs.length > 500) {
      this.data.activityLogs = this.data.activityLogs.slice(0, 500);
    }
  }

  public exportBackup() {
    return this.data;
  }

  public restoreBackup(data: DatabaseSchema) {
    this.data = data;
  }
}

export const db = new JsonDB();
