export type UserRole = 'admin' | 'driver' | 'owner';

export interface OwnerPermissions {
  viewVehicles: boolean;
  viewCollections: boolean;
  viewFinancialReports: boolean;
  viewServiceReports: boolean;
  viewDriverInfo: boolean;
  viewDocuments: boolean;
  viewEmiLoans: boolean;
  documentTypesAllowed: string[]; // e.g., ['RC', 'Insurance', 'PUC', 'Permit']
}

export interface User {
  id: string;
  name: string;
  email: string;
  mobile: string;
  role: UserRole;
  avatarUrl?: string;
  driverId?: string; // Linked driver ID if role === 'driver'
  ownerPermissions?: OwnerPermissions;
  status: 'active' | 'inactive';
  createdAt: string;
}

export type AutoStatus = 'available' | 'assigned' | 'service' | 'inactive';

export interface Auto {
  id: string;
  registrationNumber: string; // e.g. KA-01-AB-1234
  model: string; // e.g. Bajaj RE Compact / TVS King Deluxe
  chassisNumber?: string;
  engineNumber?: string;
  currentDriverId?: string;
  currentDriverName?: string;
  dateGivenToDriver?: string;
  weeklyCollectionAmount: number; // e.g. 3000
  insuranceExpiryDate: string;
  pucExpiryDate: string;
  permitExpiryDate?: string;
  fitnessExpiryDate?: string;
  rcDetails: string;
  status: AutoStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type DriverStatus = 'active' | 'inactive' | 'suspended';

export interface Driver {
  id: string;
  fullName: string;
  mobileNumber: string;
  alternateMobile?: string;
  email?: string;
  address?: string;
  dateJoined: string;
  assignedAutoId?: string;
  assignedAutoRegNumber?: string;
  weeklyCollectionAmount: number;
  driverStatus: DriverStatus;
  licenseNumber?: string;
  licenseExpiryDate?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AutoAssignment {
  id: string;
  autoId: string;
  autoRegNumber: string;
  driverId: string;
  driverName: string;
  startDate: string;
  endDate?: string;
  weeklyCollectionAmount: number;
  reasonForEnding?: string;
  assignedBy: string;
  createdAt: string;
}

export type PaymentStatus = 'Paid' | 'Partially Paid' | 'Pending';
export type PaymentMethod = 'Cash' | 'UPI' | 'Bank Transfer' | 'Cheque';

export interface CollectionRecord {
  id: string; // Collection ID
  driverId: string;
  driverName: string;
  autoId: string;
  autoRegNumber: string;
  weekStartDate: string;
  weekEndDate: string;
  dueDate: string;
  amountDue: number;
  amountPaid: number;
  pendingAmount: number; // calculated as amountDue - amountPaid
  paymentDate?: string;
  paymentMethod?: PaymentMethod;
  paymentStatus: PaymentStatus;
  notes?: string;
  recordedBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ServiceRecord {
  id: string;
  autoId: string;
  autoRegNumber: string;
  serviceDate: string;
  currentKm: number;
  serviceType: 'Routine' | 'Major Repair' | 'Oil Change' | 'Breakdown' | 'Bodywork';
  garageName: string;
  garageContact?: string;
  partsReplaced: string;
  labourCost: number;
  partsCost: number;
  totalServiceCost: number; // labourCost + partsCost
  nextServiceDate: string;
  nextServiceKm: number;
  notes?: string;
  recordedBy?: string;
  createdAt: string;
}

export type ExpenseCategory = 'Service' | 'Repair' | 'Spare parts' | 'Insurance' | 'PUC' | 'Tax' | 'Permit' | 'Other';

export interface ExpenseRecord {
  id: string;
  date: string;
  autoId?: string;
  autoRegNumber?: string;
  category: ExpenseCategory;
  amount: number;
  description: string;
  receiptName?: string;
  receiptDataUrl?: string; // base64 or file URL
  notes?: string;
  recordedBy?: string;
  createdAt: string;
}

export type EmiStatus = 'Active' | 'Completed' | 'Overdue' | 'Closed';

export interface EmiLoan {
  id: string;
  autoId: string;
  autoRegNumber: string;
  financeCompany: string; // e.g. Cholamandalam / Bajaj Finance / Shriram Finance
  loanAccountNumber: string;
  loanStartDate: string;
  loanEndDate: string;
  totalLoanAmount: number;
  downPayment: number;
  emiAmount: number;
  emiFrequency: 'Monthly' | 'Weekly';
  emiDueDateDay: number; // Day of month e.g. 10th
  nextEmiDueDate: string;
  totalEmis: number; // e.g. 36
  emisPaid: number; // e.g. 18
  emisRemaining: number;
  lastEmiPaidDate?: string;
  emiStatus: EmiStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface EmiPayment {
  id: string;
  loanId: string;
  autoId: string;
  autoRegNumber: string;
  emiNumber: number; // e.g. 18
  totalEmis: number;
  dueDate: string;
  clearedDate: string;
  emiAmount: number;
  lateFee: number;
  totalAmountPaid: number; // emiAmount + lateFee
  paymentStatus: 'Paid' | 'Late Paid' | 'Waived';
  paymentReferenceNumber?: string;
  notes?: string;
  recordedBy?: string;
  createdAt: string;
}

export type DocumentType = 
  | 'RC' 
  | 'Insurance' 
  | 'PUC' 
  | 'Vehicle Invoice' 
  | 'Loan/Finance Document' 
  | 'EMI Document' 
  | 'Tax Document' 
  | 'Permit' 
  | 'Fitness Certificate' 
  | 'Service Document' 
  | 'Driver Licence' 
  | 'Other';

export interface VehicleDocument {
  id: string;
  documentName: string;
  documentType: DocumentType;
  autoId?: string;
  autoRegNumber?: string;
  driverId?: string;
  documentNumber?: string;
  issueDate?: string;
  expiryDate?: string;
  uploadedDate: string;
  uploadedBy: string;
  fileDataUrl?: string;
  fileName?: string;
  fileSize?: string;
  notes?: string;
  visibleToDriver: boolean;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  type: 'collection' | 'service' | 'insurance' | 'puc' | 'permit' | 'fitness' | 'licence' | 'emi';
  title: string;
  message: string;
  severity: 'high' | 'medium' | 'info';
  priority?: 'urgent' | 'warning' | 'info';
  autoId?: string;
  autoRegNumber?: string;
  driverId?: string;
  dueDate?: string;
  read: boolean;
  createdAt: string;
}

export type AppNotification = NotificationItem;

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  performedByName?: string;
  userRole: UserRole;
  action: string;
  actionType?: string;
  module: string;
  recordId?: string;
  details: string;
  description?: string;
  originalValue?: string;
  updatedValue?: string;
  timestamp: string;
}

export interface DashboardMetrics {
  totalAutos: number;
  availableAutos: number;
  assignedAutos: number;
  underServiceAutos: number;
  totalActiveDrivers: number;
  weeklyCollectionTarget: number;
  paidCollectionsThisWeek: number;
  pendingCollectionsThisWeek: number;
  monthlyRevenue: number;
  monthlyExpenses: number;
  upcomingServicesCount: number;
  expiringDocsCount: number;
  overdueEmisCount: number;
  activeLoansCount: number;
}
