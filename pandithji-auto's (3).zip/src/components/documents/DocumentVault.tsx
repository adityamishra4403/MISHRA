import React, { useState } from 'react';
import { FileText, Search, Plus, ShieldCheck, Eye, EyeOff, AlertTriangle } from 'lucide-react';
import { VehicleDocument, Auto, Driver } from '../../types/index';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';

interface DocumentVaultProps {
  documents: VehicleDocument[];
  autos: Auto[];
  drivers: Driver[];
  userRole: string;
  onAddDocument: (data: Partial<VehicleDocument>) => Promise<void>;
  onUpdateDocument: (id: string, data: Partial<VehicleDocument>) => Promise<void>;
  onDeleteDocument?: (id: string) => Promise<void>;
}

export const DocumentVault: React.FC<DocumentVaultProps> = ({
  documents,
  autos,
  drivers,
  userRole,
  onAddDocument,
  onUpdateDocument,
  onDeleteDocument,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form
  const [documentName, setDocumentName] = useState('Vehicle RC Smartcard');
  const [documentType, setDocumentType] = useState<VehicleDocument['documentType']>('RC');
  const [autoId, setAutoId] = useState('');
  const [driverId, setDriverId] = useState('');
  const [documentNumber, setDocumentNumber] = useState('');
  const [issueDate, setIssueDate] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [visibleToDriver, setVisibleToDriver] = useState(true);
  const [notes, setNotes] = useState('');

  const isAdmin = userRole === 'admin';

  const filteredDocs = (documents || []).filter((doc) => {
    if (userRole === 'driver') {
      const typeLower = (doc.documentType || '').toLowerCase();
      const nameLower = (doc.documentName || '').toLowerCase();
      if (
        typeLower === 'puc' ||
        typeLower === 'insurance' ||
        nameLower.includes('puc') ||
        nameLower.includes('pollution') ||
        nameLower.includes('insurance')
      ) {
        return false;
      }
    }
    const term = (searchTerm || '').toLowerCase();
    return (
      (doc.documentName || '').toLowerCase().includes(term) ||
      (doc.documentNumber && doc.documentNumber.toLowerCase().includes(term)) ||
      (doc.autoRegNumber && doc.autoRegNumber.toLowerCase().includes(term)) ||
      (doc.driverName && doc.driverName.toLowerCase().includes(term))
    );
  });

  const handleOpenAdd = () => {
    if (autos.length > 0) setAutoId(autos[0].id);
    setDocumentName('Vehicle Insurance Policy');
    setDocumentNumber('');
    setExpiryDate('');
    setVisibleToDriver(true);
    setIsModalOpen(true);
  };


  const handleDeleteDocument = async (doc: VehicleDocument) => {
    if (onDeleteDocument) {
      await onDeleteDocument(doc.id);
      
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onAddDocument({
      documentName,
      documentType,
      autoId: autoId || undefined,
      driverId: driverId || undefined,
      documentNumber,
      issueDate,
      expiryDate,
      visibleToDriver,
      notes,
    });
    setIsModalOpen(false);
  };

  const handleToggleVisibility = async (doc: VehicleDocument) => {
    await onUpdateDocument(doc.id, { visibleToDriver: !doc.visibleToDriver });
  };

  return (
    <div id="document-vault-module" className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Vehicle Document Vault</h2>
          <p className="text-xs text-slate-500">Secure storage for RC, Insurance, PUC, Fitness Certificates & Driver Licences</p>
        </div>

        {isAdmin && (
          <button
            id="btn-add-document"
            onClick={handleOpenAdd}
            className="px-4 py-2.5 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold rounded-xl text-xs flex items-center space-x-2 transition-all shadow-md shadow-indigo-500/20 shrink-0"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Upload Document</span>
          </button>
        )}
      </div>

      <div className="bg-white dark:bg-slate-900 p-4 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
        <div className="relative max-w-md">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input
            id="search-docs-input"
            type="text"
            placeholder="Search document name, RC number, auto reg..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-hidden"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredDocs.map((doc) => (
          <div
            key={doc.id}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-3 hover:border-indigo-500/40 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">{doc.documentName}</h3>
                  <span className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold">{doc.documentType}</span>
                </div>
                {isAdmin && (
                  <button
                    id={`btn-toggle-vis-${doc.id}`}
                    onClick={() => handleToggleVisibility(doc)}
                    className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                    title={doc.visibleToDriver ? 'Visible to Driver' : 'Hidden from Driver'}
                  >
                    {doc.visibleToDriver ? (
                      <Eye className="w-4 h-4 text-violet-500" />
                    ) : (
                      <EyeOff className="w-4 h-4 text-slate-400" />
                    )}
                  </button>
                )}
              </div>

              <div className="mt-3 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl space-y-1 text-xs">
                {doc.autoRegNumber && (
                  <div className="flex justify-between text-slate-500">
                    <span>Auto Unit:</span>
                    <span className="font-mono font-bold text-slate-900 dark:text-white">{doc.autoRegNumber}</span>
                  </div>
                )}
                {doc.driverName && (
                  <div className="flex justify-between text-slate-500">
                    <span>Driver:</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{doc.driverName}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-500">
                  <span>Document #:</span>
                  <span className="font-mono text-slate-700 dark:text-slate-300">{doc.documentNumber || 'N/A'}</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-xs">
              <span className="text-slate-500">Expires:</span>
              <span className="font-bold text-slate-900 dark:text-white">{doc.expiryDate || 'No Expiry'}</span>
            </div>
          </div>
        ))}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Upload Vehicle Document"
        subtitle="Add document records and configure driver visibility"
      >
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Document Name *</label>
            <input
              id="input-doc-name"
              type="text"
              required
              placeholder="e.g. ICICI Lombard Insurance Policy"
              value={documentName}
              onChange={(e) => setDocumentName(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Document Type *</label>
              <select
                id="select-doc-type"
                value={documentType}
                onChange={(e) => setDocumentType(e.target.value as any)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
              >
                <option value="RC">RC (Registration Certificate)</option>
                <option value="Insurance">Insurance Policy</option>
                <option value="PUC">PUC (Pollution Certificate)</option>
                <option value="Fitness">Fitness Certificate</option>
                <option value="Permit">Road Permit</option>
                <option value="Driver Licence">Driver Licence</option>
                <option value="ID Proof">Aadhaar / ID Proof</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Document Number</label>
              <input
                id="input-doc-no"
                type="text"
                placeholder="e.g. POL-99201928"
                value={documentNumber}
                onChange={(e) => setDocumentNumber(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Select Auto (Optional)</label>
              <select
                id="select-doc-auto"
                value={autoId}
                onChange={(e) => setAutoId(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              >
                <option value="">-- No Specific Auto --</option>
                {autos.map((a) => (
                  <option key={a.id} value={a.id}>{a.registrationNumber} ({a.model})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Expiry Date</label>
              <input
                id="input-doc-expiry"
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>

          <div className="flex items-center space-x-2 pt-2">
            <input
              id="checkbox-doc-vis"
              type="checkbox"
              checked={visibleToDriver}
              onChange={(e) => setVisibleToDriver(e.target.checked)}
              className="w-4 h-4 rounded-sm text-indigo-500 focus:ring-indigo-400"
            />
            <label htmlFor="checkbox-doc-vis" className="font-bold text-slate-800 dark:text-slate-200">
              Make document visible to assigned driver in Driver Portal
            </label>
          </div>

          <button
            id="btn-submit-document"
            type="submit"
            className="w-full py-3 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold rounded-xl text-sm transition-all shadow-md"
          >
            Save Document Record
          </button>
        </form>
      </Modal>
    </div>
  );
};
