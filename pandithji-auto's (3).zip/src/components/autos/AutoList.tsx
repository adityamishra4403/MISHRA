import React, { useState } from 'react';
import {
  Car,
  Search,
  Plus,
  UserPlus,
  Edit,
  History,
  FileText,
  Wrench,
  Wallet,
  Landmark,
  X,
  CheckCircle,
  AlertCircle, Trash2,
} from 'lucide-react';
import { Auto, Driver, AutoAssignment, CollectionRecord, ServiceRecord, ExpenseRecord, EmiLoan } from '../../types/index';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';

interface AutoListProps {
  autos: Auto[];
  drivers: Driver[];
  assignments: AutoAssignment[];
  collections: CollectionRecord[];
  services: ServiceRecord[];
  expenses: ExpenseRecord[];
  emiLoans: EmiLoan[];
  userRole: string;
  onAddAuto: (data: Partial<Auto>) => Promise<void>;
  onUpdateAuto: (id: string, data: Partial<Auto>) => Promise<void>;
  onAssignAuto: (autoId: string, driverId: string, weeklyAmount: number) => Promise<void>;
  onDeleteAuto?: (id: string) => Promise<void>;
}

export const AutoList: React.FC<AutoListProps> = ({
  autos,
  drivers,
  assignments,
  collections,
  services,
  expenses,
  emiLoans,
  userRole,
  onAddAuto,
  onUpdateAuto,
  onAssignAuto,
  onDeleteAuto,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Modal States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [selectedAuto, setSelectedAuto] = useState<Auto | null>(null);

  // Form States
  const [regNo, setRegNo] = useState('');
  const [model, setModel] = useState('Bajaj RE Compact');
  const [weeklyAmt, setWeeklyAmt] = useState(3000);
  const [insExpiry, setInsExpiry] = useState('');
  const [pucExpiry, setPucExpiry] = useState('');
  const [rcDetails, setRcDetails] = useState('');
  const [notes, setNotes] = useState('');

  // Assign Form State
  const [targetDriverId, setTargetDriverId] = useState('');
  const [assignWeeklyAmt, setAssignWeeklyAmt] = useState(3000);


  const isAdmin = userRole === 'admin';
  const canAdd = userRole === 'admin' || userRole === 'owner';

  const filteredAutos = (autos || []).filter((auto) => {
    const term = (searchTerm || '').toLowerCase();
    const matchesSearch =
      (auto.registrationNumber || '').toLowerCase().includes(term) ||
      (auto.model || '').toLowerCase().includes(term) ||
      ((auto.currentDriverName || '').toLowerCase().includes(term));
    const matchesStatus = statusFilter === 'all' || auto.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenAdd = () => {
    setRegNo('');
    setModel('Bajaj RE Compact');
    setWeeklyAmt(3000);
    setInsExpiry('');
    setPucExpiry('');
    setRcDetails('');
    setNotes('');
    setIsAddModalOpen(true);
  };


  const handleShareAuto = async (auto: Auto) => {
    const shareText = `Vehicle Details:
Reg No: ${auto.registrationNumber}
Model: ${auto.model}
Driver: ${auto.currentDriverName || 'Not Assigned'}
Insurance Expiry: ${auto.insuranceExpiryDate || 'N/A'}
PUC Expiry: ${auto.pucExpiryDate || 'N/A'}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Vehicle Details',
          text: shareText,
        });
      } catch (err) {
        console.error('Share failed', err);
      }
    } else {
      // Fallback to whatsapp link
      window.open(`https://wa.me/?text=${encodeURIComponent(shareText)}`);
    }
  };

  const handleCreateAuto = async (e: React.FormEvent) => {
    e.preventDefault();
    await onAddAuto({
      registrationNumber: regNo,
      model,
      weeklyCollectionAmount: Number(weeklyAmt),
      insuranceExpiryDate: insExpiry,
      pucExpiryDate: pucExpiry,
      rcDetails,
      notes,
    });
    setIsAddModalOpen(false);
  };

  const handleOpenAssign = (auto: Auto) => {
    setSelectedAuto(auto);
    setTargetDriverId(auto.currentDriverId || '');
    setAssignWeeklyAmt(auto.weeklyCollectionAmount || 3000);
    setIsAssignModalOpen(true);
  };

  const handleAssignSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedAuto && targetDriverId) {
      await onAssignAuto(selectedAuto.id, targetDriverId, Number(assignWeeklyAmt));
      setIsAssignModalOpen(false);
    }
  };

  const handleOpenHistory = (auto: Auto) => {
    setSelectedAuto(auto);
    setIsHistoryModalOpen(true);
  };

  const handleDeleteAuto = async (auto: Auto) => {
    if (onDeleteAuto) {
      await onDeleteAuto(auto.id);
      
    }
  };

  return (
    <div id="auto-list-module" className="space-y-6 animate-in fade-in duration-200">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Auto Fleet Management</h2>
          <p className="text-xs text-slate-500">Manage all rickshaw units, assignments, driver status & complete history</p>
        </div>

        {canAdd && (
          <button
            id="btn-add-new-auto"
            onClick={handleOpenAdd}
            className="px-4 py-2.5 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold rounded-xl text-xs flex items-center space-x-2 transition-all shadow-md shadow-indigo-500/20 shrink-0"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Add New Auto</span>
          </button>
        )}
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input
            id="search-autos-input"
            type="text"
            placeholder="Search registration number, model, driver..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/50"
          />
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-bold text-slate-500">Status:</span>
          <select
            id="status-filter-select"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 font-semibold focus:outline-hidden"
          >
            <option value="all">All Statuses ({autos.length})</option>
            <option value="assigned">Assigned</option>
            <option value="available">Available</option>
            <option value="service">Under Service</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>

      {/* Autos Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredAutos.map((auto) => (
          <div
            key={auto.id}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between hover:border-indigo-500/40 transition-all space-y-4"
          >
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-lg font-black font-mono text-slate-900 dark:text-white tracking-wider block">
                    {auto.registrationNumber}
                  </span>
                  <span className="text-xs text-slate-500 font-medium">{auto.model}</span>
                </div>
                <Badge
                  variant={
                    auto.status === 'assigned'
                      ? 'success'
                      : auto.status === 'available'
                      ? 'warning'
                      : auto.status === 'service'
                      ? 'danger'
                      : 'neutral'
                  }
                >
                  {(auto.status || 'unknown').toUpperCase()}
                </Badge>
              </div>

              {/* Driver Details Box */}
              <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-500">
                  <span>Assigned Driver:</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {auto.currentDriverName || 'Unassigned'}
                  </span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Weekly Rent Amount:</span>
                  <span className="font-bold text-indigo-600 dark:text-indigo-400 font-mono">
                    ₹{auto.weeklyCollectionAmount.toLocaleString('en-IN')}
                  </span>
                </div>
                {auto.dateGivenToDriver && (
                  <div className="flex justify-between text-slate-500">
                    <span>Date Allotted:</span>
                    <span>{auto.dateGivenToDriver}</span>
                  </div>
                )}
              </div>

              {/* Document Expiry Warnings */}
              {userRole !== 'driver' && (
                <div className="mt-3 space-y-1 text-[11px] text-slate-500">
                  <div className="flex justify-between">
                    <span>Insurance:</span>
                    <span className="font-medium text-slate-700 dark:text-slate-300">{auto.insuranceExpiryDate || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>PUC Expiry:</span>
                    <span className="font-medium text-slate-700 dark:text-slate-300">{auto.pucExpiryDate || 'N/A'}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs gap-2">
              <div className="flex items-center gap-2">
                <button
                  id={`btn-history-${auto.id}`}
                  onClick={() => handleOpenHistory(auto)}
                  className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors flex items-center space-x-1"
                >
                  <History className="w-3.5 h-3.5" />
                  <span>History</span>
                </button>
                <button
                  onClick={() => handleShareAuto(auto)}
                  className="px-3 py-1.5 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-bold rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors"
                >
                  Share
                </button>
              </div>

              {canAdd && (
                <div className="flex items-center gap-2">
                  <button
                    id={`btn-assign-${auto.id}`}
                    onClick={() => handleOpenAssign(auto)}
                    className="px-3 py-1.5 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold rounded-lg transition-colors flex items-center space-x-1"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Assign</span>
                  </button>
                  {onDeleteAuto && (
                    <button
                      onClick={() => handleDeleteAuto(auto)}
                      className="p-1.5 px-3 flex items-center space-x-1 text-rose-500 font-bold hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                      title="Delete Auto"
                    >
                      <Trash2 className="w-4 h-4" /> <span className="hidden sm:inline">Delete</span></button>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Add Auto Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add New Auto to Fleet"
        subtitle="Register new auto rickshaw unit details into Pandithji Auto's database"
      >
        <form onSubmit={handleCreateAuto} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Registration Number *</label>
            <input
              id="input-auto-regno"
              type="text"
              required
              placeholder="e.g. KA-01-MJ-4012"
              value={regNo}
              onChange={(e) => setRegNo(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono uppercase"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Auto Model</label>
              <select
                id="select-auto-model"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              >
                <option value="Bajaj RE Compact 4T">Bajaj RE Compact 4T</option>
                <option value="TVS King Deluxe CNG">TVS King Deluxe CNG</option>
                <option value="Piaggio Ape City Plus">Piaggio Ape City Plus</option>
                <option value="Bajaj Maxima Z EV">Bajaj Maxima Z EV</option>
                <option value="Mahindra Treo Electric">Mahindra Treo Electric</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Weekly Rent (₹)</label>
              <input
                id="input-auto-weekly-amt"
                type="number"
                required
                value={weeklyAmt}
                onChange={(e) => setWeeklyAmt(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Insurance Expiry Date</label>
              <input
                id="input-auto-ins-expiry"
                type="date"
                value={insExpiry}
                onChange={(e) => setInsExpiry(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">PUC Expiry Date</label>
              <input
                id="input-auto-puc-expiry"
                type="date"
                value={pucExpiry}
                onChange={(e) => setPucExpiry(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">RC Details & RTO</label>
            <input
              id="input-auto-rc-details"
              type="text"
              placeholder="e.g. Reg Date: Jan 2023, RTO Indiranagar Bangalore"
              value={rcDetails}
              onChange={(e) => setRcDetails(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Notes</label>
            <textarea
              id="textarea-auto-notes"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
          </div>

          <button
            id="btn-submit-create-auto"
            type="submit"
            className="w-full py-3 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold rounded-xl text-sm transition-all shadow-md"
          >
            Save Auto to Fleet
          </button>
        </form>
      </Modal>

      {/* Assign Driver Modal */}
      <Modal
        isOpen={isAssignModalOpen}
        onClose={() => setIsAssignModalOpen(false)}
        title={`Assign Driver to ${selectedAuto?.registrationNumber}`}
        subtitle="Select a driver to assign or change driver allotment"
      >
        <form onSubmit={handleAssignSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Select Driver</label>
            <select
              id="select-assign-driver"
              required
              value={targetDriverId}
              onChange={(e) => setTargetDriverId(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
            >
              <option value="">-- Choose Driver --</option>
              {drivers.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.fullName} ({d.mobileNumber}) {d.assignedAutoRegNumber ? `- Assigned to ${d.assignedAutoRegNumber}` : '- Available'}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Agreed Weekly Collection Amount (₹)</label>
            <input
              id="input-assign-weekly-amt"
              type="number"
              required
              value={assignWeeklyAmt}
              onChange={(e) => setAssignWeeklyAmt(Number(e.target.value))}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-sm"
            />
          </div>

          <button
            id="btn-submit-assign-driver"
            type="submit"
            className="w-full py-3 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold rounded-xl text-sm transition-all"
          >
            Confirm Driver Assignment
          </button>
        </form>
      </Modal>

      {/* Auto Complete History Modal */}
      {selectedAuto && (
        <Modal
          isOpen={isHistoryModalOpen}
          onClose={() => setIsHistoryModalOpen(false)}
          title={`Complete History: ${selectedAuto.registrationNumber}`}
          subtitle={`Full history log of driver allotments, collections, services & loans`}
          maxWidth="2xl"
        >
          <div className="space-y-5 text-xs">
            {/* Driver Allotment History */}
            <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50/50 dark:bg-slate-900/50">
              <h4 className="font-bold text-slate-900 dark:text-white mb-2 flex items-center space-x-1.5">
                <UserPlus className="w-4 h-4 text-indigo-500" />
                <span>Driver Allotment History</span>
              </h4>
              <div className="space-y-2">
                {assignments
                  .filter((a) => a.autoId === selectedAuto.id)
                  .map((asg) => (
                    <div key={asg.id} className="p-2.5 bg-white dark:bg-slate-800 rounded-lg flex justify-between items-center">
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white">{asg.driverName}</span>
                        <span className="text-[10px] text-slate-500 block">Start: {asg.startDate} {asg.endDate ? `| End: ${asg.endDate}` : '| Currently Assigned'}</span>
                      </div>
                      <span className="font-bold text-indigo-600 dark:text-indigo-400">₹{asg.weeklyCollectionAmount}/wk</span>
                    </div>
                  ))}
              </div>
            </div>

            {/* Collections History */}
            <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4">
              <h4 className="font-bold text-slate-900 dark:text-white mb-2 flex items-center space-x-1.5">
                <Wallet className="w-4 h-4 text-violet-500" />
                <span>Collection Payment History</span>
              </h4>
              <div className="space-y-1.5">
                {collections
                  .filter((c) => c.autoId === selectedAuto.id)
                  .map((col) => (
                    <div key={col.id} className="p-2 bg-slate-50 dark:bg-slate-800/40 rounded-lg flex justify-between items-center text-[11px]">
                      <span>{col.dueDate} ({col.driverName})</span>
                      <span className="font-bold text-violet-600 dark:text-violet-400">Paid ₹{col.amountPaid} / ₹{col.amountDue}</span>
                    </div>
                  ))}
              </div>
            </div>

            {/* Service & Repair Log */}
            <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-4">
              <h4 className="font-bold text-slate-900 dark:text-white mb-2 flex items-center space-x-1.5">
                <Wrench className="w-4 h-4 text-blue-500" />
                <span>Service & Maintenance History</span>
              </h4>
              <div className="space-y-1.5">
                {services
                  .filter((s) => s.autoId === selectedAuto.id)
                  .map((srv) => (
                    <div key={srv.id} className="p-2 bg-slate-50 dark:bg-slate-800/40 rounded-lg flex justify-between items-center text-[11px]">
                      <span>{srv.serviceDate} ({srv.serviceType})</span>
                      <span className="font-bold text-blue-600 dark:text-blue-400">₹{srv.totalServiceCost}</span>
                    </div>
                  ))}
                {services.filter((s) => s.autoId === selectedAuto.id).length === 0 && (
                  <div className="text-slate-500 italic text-center py-2">No service history</div>
                )}
              </div>
            </div>

          </div>
        </Modal>
      )}

    </div>
  );
};
