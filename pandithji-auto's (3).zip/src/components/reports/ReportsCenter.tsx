import React, { useState } from 'react';
import { BarChart3, Download, Search, Filter, ArrowDownToLine, TrendingUp, Users, Car, Wallet, Wrench } from 'lucide-react';
import { Auto, Driver, CollectionRecord, ExpenseRecord, ServiceRecord } from '../../types/index';
import { Badge } from '../common/Badge';

interface ReportsCenterProps {
  autos: Auto[];
  drivers: Driver[];
  collections: CollectionRecord[];
  expenses: ExpenseRecord[];
  services: ServiceRecord[];
}

export const ReportsCenter: React.FC<ReportsCenterProps> = ({
  autos,
  drivers,
  collections,
  expenses,
  services,
}) => {
  const [activeReportTab, setActiveReportTab] = useState<'collections' | 'vehicles' | 'expenses' | 'drivers'>('collections');
  const [searchTerm, setSearchTerm] = useState('');

  // Summaries
  const totalCollected = collections.reduce((acc, c) => acc + c.amountPaid, 0);
  const totalPending = collections.reduce((acc, c) => acc + c.pendingAmount, 0);
  const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);
  const totalServiceCosts = services.reduce((acc, s) => acc + s.totalServiceCost, 0);

  const exportReportCSV = () => {
    let headers: string[] = [];
    let rows: (string | number)[][] = [];
    let filename = `Pandithji_${activeReportTab}_report_${new Date().toISOString().split('T')[0]}.csv`;

    if (activeReportTab === 'collections') {
      headers = ['Driver', 'Auto Reg', 'Due Date', 'Due Amount', 'Paid Amount', 'Pending Amount', 'Status'];
      rows = collections.map((c) => [c.driverName, c.autoRegNumber, c.dueDate, c.amountDue, c.amountPaid, c.pendingAmount, c.paymentStatus]);
    } else if (activeReportTab === 'vehicles') {
      headers = ['Reg Number', 'Model', 'Status', 'Current Driver', 'Weekly Rent'];
      rows = autos.map((a) => [a.registrationNumber, a.model, a.status, a.currentDriverName || 'Unassigned', a.weeklyCollectionAmount]);
    } else if (activeReportTab === 'expenses') {
      headers = ['Date', 'Category', 'Auto Reg', 'Description', 'Amount'];
      rows = expenses.map((e) => [e.date, e.category, e.autoRegNumber || 'General', e.description, e.amount]);
    } else {
      headers = ['Driver Name', 'Mobile', 'Assigned Auto', 'Status', 'Weekly Rent'];
      rows = drivers.map((d) => [d.fullName, d.mobileNumber, d.assignedAutoRegNumber || 'None', d.driverStatus, d.weeklyCollectionAmount]);
    }

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="reports-center-module" className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Business Reports & Analytics</h2>
          <p className="text-xs text-slate-500">Comprehensive business performance metrics, fleet ROI & exportable reports</p>
        </div>

        <button
          id="btn-export-active-report"
          onClick={exportReportCSV}
          className="px-4 py-2.5 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold rounded-xl text-xs flex items-center space-x-2 transition-all shadow-md shadow-indigo-500/20 shrink-0"
        >
          <ArrowDownToLine className="w-4 h-4 stroke-[3]" />
          <span>Export {(activeReportTab || 'REPORT').toUpperCase()} CSV</span>
        </button>
      </div>

      {/* Metric Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Revenue Collected</span>
          <div className="mt-2 text-2xl font-black text-violet-600 dark:text-violet-400 font-mono">
            ₹{totalCollected.toLocaleString('en-IN')}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Pending Dues</span>
          <div className="mt-2 text-2xl font-black text-rose-600 dark:text-rose-400 font-mono">
            ₹{totalPending.toLocaleString('en-IN')}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Fleet Expenses</span>
          <div className="mt-2 text-2xl font-black text-slate-900 dark:text-white font-mono">
            ₹{totalExpenses.toLocaleString('en-IN')}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Service & Maintenance</span>
          <div className="mt-2 text-2xl font-black text-blue-600 dark:text-blue-400 font-mono">
            ₹{totalServiceCosts.toLocaleString('en-IN')}
          </div>
        </div>
      </div>

      {/* Tab Switcher */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 space-x-6 text-sm font-bold">
        <button
          id="tab-report-collections"
          onClick={() => setActiveReportTab('collections')}
          className={`pb-3 transition-all flex items-center space-x-2 border-b-2 ${
            activeReportTab === 'collections'
              ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <Wallet className="w-4 h-4" />
          <span>Collection Reports</span>
        </button>

        <button
          id="tab-report-vehicles"
          onClick={() => setActiveReportTab('vehicles')}
          className={`pb-3 transition-all flex items-center space-x-2 border-b-2 ${
            activeReportTab === 'vehicles'
              ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <Car className="w-4 h-4" />
          <span>Vehicle Reports</span>
        </button>

        <button
          id="tab-report-expenses"
          onClick={() => setActiveReportTab('expenses')}
          className={`pb-3 transition-all flex items-center space-x-2 border-b-2 ${
            activeReportTab === 'expenses'
              ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Expense Reports</span>
        </button>

        <button
          id="tab-report-drivers"
          onClick={() => setActiveReportTab('drivers')}
          className={`pb-3 transition-all flex items-center space-x-2 border-b-2 ${
            activeReportTab === 'drivers'
              ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Driver Performance</span>
        </button>
      </div>

      {/* Active Tab View */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs p-5">
        <h3 className="font-bold text-base text-slate-900 dark:text-white mb-4 uppercase text-xs tracking-wider">
          {activeReportTab} Performance Analytics Data
        </h3>

        <div className="overflow-x-auto">
          {activeReportTab === 'collections' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 uppercase font-semibold">
                <tr>
                  <th className="p-3">Driver</th>
                  <th className="p-3">Auto Reg</th>
                  <th className="p-3">Due Date</th>
                  <th className="p-3">Due</th>
                  <th className="p-3">Paid</th>
                  <th className="p-3">Pending</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {collections.map((c) => (
                  <tr key={c.id}>
                    <td className="p-3 font-bold">{c.driverName}</td>
                    <td className="p-3 font-mono">{c.autoRegNumber}</td>
                    <td className="p-3">{c.dueDate}</td>
                    <td className="p-3">₹{c.amountDue}</td>
                    <td className="p-3 text-violet-600 font-bold">₹{c.amountPaid}</td>
                    <td className="p-3 text-rose-600 font-bold">₹{c.pendingAmount}</td>
                    <td className="p-3"><Badge variant="info">{c.paymentStatus}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeReportTab === 'vehicles' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 uppercase font-semibold">
                <tr>
                  <th className="p-3">Registration</th>
                  <th className="p-3">Model</th>
                  <th className="p-3">Assigned Driver</th>
                  <th className="p-3">Weekly Rent</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {autos.map((a) => (
                  <tr key={a.id}>
                    <td className="p-3 font-mono font-bold">{a.registrationNumber}</td>
                    <td className="p-3">{a.model}</td>
                    <td className="p-3">{a.currentDriverName || 'Unassigned'}</td>
                    <td className="p-3 font-bold">₹{a.weeklyCollectionAmount}</td>
                    <td className="p-3"><Badge variant="success">{a.status}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeReportTab === 'expenses' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 uppercase font-semibold">
                <tr>
                  <th className="p-3">Date</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Auto Reg</th>
                  <th className="p-3">Description</th>
                  <th className="p-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {expenses.map((e) => (
                  <tr key={e.id}>
                    <td className="p-3 font-mono">{e.date}</td>
                    <td className="p-3 font-bold">{e.category}</td>
                    <td className="p-3 font-mono">{e.autoRegNumber || 'General'}</td>
                    <td className="p-3">{e.description}</td>
                    <td className="p-3 text-right font-bold text-rose-600 font-mono">₹{e.amount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeReportTab === 'drivers' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 uppercase font-semibold">
                <tr>
                  <th className="p-3">Driver Name</th>
                  <th className="p-3">Mobile</th>
                  <th className="p-3">Assigned Auto</th>
                  <th className="p-3">Weekly Rent</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {drivers.map((d) => (
                  <tr key={d.id}>
                    <td className="p-3 font-bold">{d.fullName}</td>
                    <td className="p-3 font-mono">{d.mobileNumber}</td>
                    <td className="p-3 font-mono">{d.assignedAutoRegNumber || 'None'}</td>
                    <td className="p-3 font-bold">₹{d.weeklyCollectionAmount}</td>
                    <td className="p-3"><Badge variant="success">{d.driverStatus}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
