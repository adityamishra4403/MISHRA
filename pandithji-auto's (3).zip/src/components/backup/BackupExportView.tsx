import React, { useState } from 'react';
import { Database, Download, Upload, ShieldCheck, RefreshCw, CheckCircle, AlertTriangle } from 'lucide-react';
import { api } from '../../lib/api';

interface BackupExportViewProps {
  onDataRestored: () => void;
}

export const BackupExportView: React.FC<BackupExportViewProps> = ({ onDataRestored }) => {
  const [restoring, setRestoring] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const handleDownloadBackup = async () => {
    try {
      const data = await api.exportBackup();
      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Pandithji_Autos_DB_Backup_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setMessage({ text: 'Database backup downloaded successfully!', type: 'success' });
    } catch (err: any) {
      setMessage({ text: err.message || 'Failed to download backup', type: 'error' });
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        setRestoring(true);
        const jsonContent = JSON.parse(event.target?.result as string);
        await api.importBackup(jsonContent);
        setMessage({ text: 'Database restored successfully! Refreshing records...', type: 'success' });
        onDataRestored();
      } catch (err: any) {
        setMessage({ text: `Invalid backup JSON file: ${err.message}`, type: 'error' });
      } finally {
        setRestoring(false);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div id="backup-export-module" className="space-y-6 animate-in fade-in duration-200">
      <div>
        <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 rounded-full text-[11px] font-bold uppercase tracking-wider mb-1">
          <Database className="w-3.5 h-3.5" />
          <span>Database Security & Recovery</span>
        </div>
        <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">System Backup & Data Export</h2>
        <p className="text-xs text-slate-500">
          Export complete database snapshots or restore business records from a JSON backup file
        </p>
      </div>

      {message && (
        <div
          className={`p-4 rounded-2xl border text-xs font-bold flex items-center space-x-2 ${
            message.type === 'success'
              ? 'bg-violet-50 text-violet-800 border-violet-300'
              : 'bg-rose-50 text-rose-800 border-rose-300'
          }`}
        >
          {message.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
          <span>{message.text}</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Export Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-indigo-500/10 text-indigo-500 rounded-xl">
              <Download className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Export Database Snapshot</h3>
              <p className="text-xs text-slate-500">Download raw JSON file containing all fleet, collections, services & driver records</p>
            </div>
          </div>

          <button
            id="btn-trigger-download-backup"
            onClick={handleDownloadBackup}
            className="w-full py-3 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center space-x-2 transition-all shadow-md"
          >
            <Download className="w-4 h-4" />
            <span>Download Full Backup (.json)</span>
          </button>
        </div>

        {/* Restore Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-blue-500/10 text-blue-500 rounded-xl">
              <Upload className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">Restore Database Snapshot</h3>
              <p className="text-xs text-slate-500">Upload a previously saved Pandithji Auto's backup JSON file to restore complete records</p>
            </div>
          </div>

          <label className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-md">
            <Upload className="w-4 h-4" />
            <span>{restoring ? 'Restoring Database...' : 'Select Backup File (.json)'}</span>
            <input
              id="input-file-restore"
              type="file"
              accept=".json"
              disabled={restoring}
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
        </div>
      </div>
    </div>
  );
};
