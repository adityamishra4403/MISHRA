import React, { useState } from 'react';
import {
  Users,
  Search,
  UserPlus,
  Car,
  Phone,
  Calendar,
  Wallet,
  CheckCircle,
  XCircle,
  FileText,
  AlertCircle, Trash2,
} from 'lucide-react';
import { Driver, Auto, CollectionRecord } from '../../types/index';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';

interface DriverListProps {
  drivers: Driver[];
  autos: Auto[];
  collections: CollectionRecord[];
  userRole: string;
  onAddDriver: (data: Partial<Driver>) => Promise<void>;
  onUpdateDriver: (id: string, data: Partial<Driver>) => Promise<void>;
  onDeleteDriver?: (id: string) => Promise<void>;
}

export const DriverList: React.FC<DriverListProps> = ({
  drivers,
  autos,
  collections,
  userRole,
  onAddDriver,
  onUpdateDriver,
  onDeleteDriver,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState<Driver | null>(null);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);

  // Form Fields
  const [fullName, setFullName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [email, setEmail] = useState('');
  const [weeklyCollectionAmount, setWeeklyCollectionAmount] = useState(3000);
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');

  const isAdmin = userRole === 'admin';
  const canAdd = userRole === 'admin' || userRole === 'owner';

  const filteredDrivers = (drivers || []).filter((d) => {
    const term = (searchTerm || '').toLowerCase();
    return (
      (d.fullName || '').toLowerCase().includes(term) ||
      (d.mobileNumber || '').includes(searchTerm) ||
      (d.assignedAutoRegNumber && d.assignedAutoRegNumber.toLowerCase().includes(term))
    );
  });

  const handleOpenAdd = () => {
    setFullName('');
    setMobileNumber('');
    setEmail('');
    setWeeklyCollectionAmount(3000);
    setAddress('');
    setNotes('');
    setIsAddModalOpen(true);
  };

  const handleSubmitAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    await onAddDriver({
      fullName,
      mobileNumber,
      email,
      weeklyCollectionAmount: Number(weeklyCollectionAmount),
      address,
      notes,
    });
    setIsAddModalOpen(false);
  };

  const handleDeleteDriver = async (driver: Driver) => {
    if (onDeleteDriver) {
      await onDeleteDriver(driver.id);
      
    }
  };

  const handleToggleDeactivate = async (driver: Driver) => {
    const nextStatus = driver.driverStatus === 'active' ? 'inactive' : 'active';
    await onUpdateDriver(driver.id, { driverStatus: nextStatus });
  };

  const handleOpenDriverHistory = (driver: Driver) => {
    setSelectedDriver(driver);
    setIsHistoryModalOpen(true);
  };

  return (
    <div id="driver-list-module" className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Driver Directory</h2>
          <p className="text-xs text-slate-500">Manage all registered drivers, assigned autos & payment histories</p>
        </div>

        {canAdd && (
          <button
            id="btn-add-new-driver"
            onClick={handleOpenAdd}
            className="px-4 py-2.5 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold rounded-xl text-xs flex items-center space-x-2 transition-all shadow-md shadow-indigo-500/20 shrink-0"
          >
            <UserPlus className="w-4 h-4 stroke-[3]" />
            <span>Add New Driver</span>
          </button>
        )}
      </div>

      {/* Search Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
        <div className="relative max-w-md">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input
            id="search-drivers-input"
            type="text"
            placeholder="Search driver name, mobile, auto reg..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-hidden"
          />
        </div>
      </div>

      {/* Driver Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredDrivers.map((driver) => {
          const driverCols = collections.filter((c) => c.driverId === driver.id);
          const pendingTotal = driverCols.reduce((acc, c) => acc + c.pendingAmount, 0);

          return (
            <div
              key={driver.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between space-y-4 hover:border-indigo-500/40 transition-all"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold text-slate-900 dark:text-white flex items-center justify-center">
                      {(driver?.fullName || 'D').charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900 dark:text-white">{driver.fullName}</h3>
                      <p className="text-xs text-slate-500 font-mono">{driver.mobileNumber}</p>
                    </div>
                  </div>
                  <Badge variant={driver.driverStatus === 'active' ? 'success' : 'neutral'}>
                    {driver.driverStatus}
                  </Badge>
                </div>

                <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-500">
                    <span>Assigned Auto:</span>
                    <span className="font-bold text-slate-900 dark:text-white font-mono">
                      {driver.assignedAutoRegNumber || 'None'}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Weekly Rent:</span>
                    <span className="font-bold text-indigo-600 dark:text-indigo-400 font-mono">
                      ₹{driver.weeklyCollectionAmount.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Pending Dues:</span>
                    <span className={`font-bold ${pendingTotal > 0 ? 'text-rose-600' : 'text-violet-600'}`}>
                      ₹{pendingTotal.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs gap-2">
                <button
                  id={`btn-driver-history-${driver.id}`}
                  onClick={() => handleOpenDriverHistory(driver)}
                  className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                >
                  Payment History
                </button>

                {isAdmin && (
                  <div className="flex items-center gap-2">
                    <button
                      id={`btn-deactivate-driver-${driver.id}`}
                      onClick={() => handleToggleDeactivate(driver)}
                      className={`px-3 py-1.5 font-bold rounded-lg text-xs transition-colors ${
                        driver.driverStatus === 'active'
                          ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-300 hover:bg-rose-100'
                          : 'bg-violet-50 dark:bg-violet-950/40 text-violet-600 dark:text-violet-300'
                      }`}
                    >
                      {driver.driverStatus === 'active' ? 'Deactivate' : 'Activate'}
                    </button>
                    {onDeleteDriver && (
                      <button
                        onClick={() => handleDeleteDriver(driver)}
                        className="p-1.5 px-3 flex items-center space-x-1 text-rose-500 font-bold hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                        title="Delete Driver"
                      >
                        <Trash2 className="w-4 h-4" /> <span className="hidden sm:inline">Delete</span></button>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Driver Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add New Driver"
        subtitle="Register driver credentials and driving licence info"
      >
        <form onSubmit={handleSubmitAdd} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Driver Full Name *</label>
            <input
              id="input-driver-fullname"
              type="text"
              required
              placeholder="e.g. Ramesh Kumar"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Mobile Number *</label>
              <input
                id="input-driver-mobile"
                type="tel"
                required
                placeholder="e.g. 9876543210"
                value={mobileNumber}
                onChange={(e) => setMobileNumber(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Email (Optional)</label>
              <input
                id="input-driver-email"
                type="email"
                placeholder="e.g. driver@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Address</label>
            <input
              id="input-driver-address"
              type="text"
              placeholder="Full local residential address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
          </div>

          <button
            id="btn-submit-add-driver"
            type="submit"
            className="w-full py-3 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold rounded-xl text-sm transition-all shadow-md"
          >
            Save Driver Profile
          </button>
        </form>
      </Modal>

      {/* Driver Payment History Modal */}
      {selectedDriver && (
        <Modal
          isOpen={isHistoryModalOpen}
          onClose={() => setIsHistoryModalOpen(false)}
          title={`Payment & Collection History: ${selectedDriver.fullName}`}
          subtitle={`Current Assigned Auto: ${selectedDriver.assignedAutoRegNumber || 'None'}`}
        >
          <div className="space-y-3 text-xs">
            {collections
              .filter((c) => c.driverId === selectedDriver.id)
              .map((col) => (
                <div
                  key={col.id}
                  className="p-3 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between"
                >
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white block">{col.dueDate}</span>
                    <span className="text-[10px] text-slate-500">Auto: {col.autoRegNumber}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-violet-600 block">Paid ₹{col.amountPaid} / Due ₹{col.amountDue}</span>
                    <Badge
                      variant={
                        col.paymentStatus === 'Paid'
                          ? 'success'
                          : col.paymentStatus === 'Partially Paid'
                          ? 'warning'
                          : 'danger'
                      }
                    >
                      {col.paymentStatus}
                    </Badge>
                  </div>
                </div>
              ))}
          </div>
        </Modal>
      )}
    </div>
  );
};
