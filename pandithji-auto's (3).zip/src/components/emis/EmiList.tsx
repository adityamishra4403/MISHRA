import React, { useState } from 'react';
import {
  Landmark,
  Search,
  Plus,
  CheckCircle,
  AlertCircle, Trash2,
  Clock,
  DollarSign,
  Calendar,
  FileCheck,
} from 'lucide-react';
import { EmiLoan, EmiPayment, Auto } from '../../types/index';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';

interface EmiListProps {
  emiLoans: EmiLoan[];
  emiPayments: EmiPayment[];
  autos: Auto[];
  userRole: string;
  onAddEmiLoan: (data: Partial<EmiLoan>) => Promise<void>;
  onPayEmi: (loanId: string, data: Partial<EmiPayment>) => Promise<void>;
  onDeleteEmiLoan?: (id: string) => Promise<void>;
}

export const EmiList: React.FC<EmiListProps> = ({
  emiLoans,
  emiPayments,
  autos,
  userRole,
  onAddEmiLoan,
  onPayEmi,
  onDeleteEmiLoan,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const [isAddLoanModalOpen, setIsAddLoanModalOpen] = useState(false);
  const [isPayModalOpen, setIsPayModalOpen] = useState(false);
  const [selectedLoan, setSelectedLoan] = useState<EmiLoan | null>(null);

  // New Loan Form State
  const [autoId, setAutoId] = useState('');
  const [financeCompany, setFinanceCompany] = useState('Cholamandalam Finance');
  const [loanAccountNumber, setLoanAccountNumber] = useState('');
  const [loanStartDate, setLoanStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [totalLoanAmount, setTotalLoanAmount] = useState(200000);
  const [downPayment, setDownPayment] = useState(40000);
  const [emiAmount, setEmiAmount] = useState(7500);
  const [totalEmis, setTotalEmis] = useState(36);
  const [notes, setNotes] = useState('');

  // Pay EMI Form State
  const [clearedDate, setClearedDate] = useState(new Date().toISOString().split('T')[0]);
  const [payEmiAmount, setPayEmiAmount] = useState(0);
  const [lateFee, setLateFee] = useState(0);
  const [paymentRef, setPaymentRef] = useState('');
  const [payNotes, setPayNotes] = useState('');

  const filteredLoans = (emiLoans || []).filter((loan) => {
    const term = (searchTerm || '').toLowerCase();
    const matchesSearch =
      (loan.autoRegNumber || '').toLowerCase().includes(term) ||
      (loan.financeCompany || '').toLowerCase().includes(term) ||
      (loan.loanAccountNumber || '').toLowerCase().includes(term);
    const matchesStatus = statusFilter === 'all' || loan.emiStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenAddLoan = () => {
    if (autos.length > 0) setAutoId(autos[0].id);
    setFinanceCompany('Cholamandalam Finance');
    setLoanAccountNumber('');
    setTotalLoanAmount(220000);
    setDownPayment(50000);
    setEmiAmount(8500);
    setTotalEmis(36);
    setNotes('');
    setIsAddLoanModalOpen(true);
  };

  const handleAddLoanSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onAddEmiLoan({
      autoId,
      financeCompany,
      loanAccountNumber,
      loanStartDate,
      totalLoanAmount: Number(totalLoanAmount),
      downPayment: Number(downPayment),
      emiAmount: Number(emiAmount),
      totalEmis: Number(totalEmis),
      notes,
    });
    setIsAddLoanModalOpen(false);
  };

  const handleOpenPayEmi = (loan: EmiLoan) => {
    setSelectedLoan(loan);
    setPayEmiAmount(loan.emiAmount);
    setLateFee(0);
    setPaymentRef('');
    setPayNotes('');
    setIsPayModalOpen(true);
  };

  const handlePayEmiSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedLoan) {
      await onPayEmi(selectedLoan.id, {
        clearedDate,
        emiAmount: Number(payEmiAmount),
        lateFee: Number(lateFee),
        paymentReferenceNumber: paymentRef,
        notes: payNotes,
      });
      setIsPayModalOpen(false);
    }
  };

  return (
    <div id="emi-loans-module" className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20 rounded-full text-[11px] font-bold uppercase tracking-wider mb-1">
            <Landmark className="w-3.5 h-3.5" />
            <span>Private Financial Vault</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">EMI & Vehicle Loan Management</h2>
          <p className="text-xs text-slate-500">Track loan accounts, monthly EMI schedules, clearance history & finance company records</p>
        </div>

        <button
          id="btn-add-loan-account"
          onClick={handleOpenAddLoan}
          className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs flex items-center space-x-2 transition-all shadow-md shadow-purple-600/20 shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Add Loan Account</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input
            id="search-emi-input"
            type="text"
            placeholder="Search auto, finance company, loan account #..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-hidden"
          />
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-bold text-slate-500">Loan Status:</span>
          <select
            id="filter-emi-status"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 font-semibold"
          >
            <option value="all">All Loans ({emiLoans.length})</option>
            <option value="Active">Active</option>
            <option value="Completed">Completed</option>
            <option value="Overdue">Overdue</option>
          </select>
        </div>
      </div>

      {/* Loans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredLoans.map((loan) => (
          <div
            key={loan.id}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between space-y-4 hover:border-purple-500/40 transition-all"
          >
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-lg font-black font-mono text-slate-900 dark:text-white tracking-wider block">
                    {loan.autoRegNumber}
                  </span>
                  <span className="text-xs text-purple-600 dark:text-purple-400 font-bold">{loan.financeCompany}</span>
                </div>
                <Badge
                  variant={
                    loan.emiStatus === 'Active'
                      ? 'info'
                      : loan.emiStatus === 'Completed'
                      ? 'success'
                      : 'danger'
                  }
                >
                  {(loan.emiStatus || 'ACTIVE').toUpperCase()}
                </Badge>
              </div>

              {/* Progress Bar */}
              <div className="mt-4 space-y-1">
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-500">EMI Progress</span>
                  <span className="text-slate-900 dark:text-white font-mono">
                    {loan.emisPaid} / {loan.totalEmis} EMIs
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-purple-600 rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, (loan.emisPaid / loan.totalEmis) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Loan Details */}
              <div className="mt-3 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-500">
                  <span>Loan Account #:</span>
                  <span className="font-mono text-slate-800 dark:text-slate-200 font-bold">{loan.loanAccountNumber || 'N/A'}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Monthly EMI Amount:</span>
                  <span className="font-bold text-slate-900 dark:text-white font-mono">
                    ₹{loan.emiAmount.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Next EMI Due Date:</span>
                  <span className="font-bold text-indigo-600 dark:text-indigo-400">{loan.nextEmiDueDate}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Total Loan Amount:</span>
                  <span>₹{loan.totalLoanAmount.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-500 font-mono text-[11px]">{loan.emisRemaining} EMIs Left</span>
              <div className="flex items-center gap-2">
                {onDeleteEmiLoan && (
                  <button
                    onClick={async () => {
                      await onDeleteEmiLoan(loan.id);
                      
                    }}
                    className="p-1.5 px-3 flex items-center space-x-1 text-rose-500 font-bold hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                    title="Delete Loan"
                  >
                    <Trash2 className="w-4 h-4" /> <span className="hidden sm:inline">Delete</span></button>
                )}
                {loan.emiStatus !== 'Completed' && (
                  <button
                    id={`btn-pay-emi-${loan.id}`}
                    onClick={() => handleOpenPayEmi(loan)}
                    className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-lg transition-colors flex items-center space-x-1"
                  >
                    <DollarSign className="w-3.5 h-3.5" />
                    <span>Record EMI Payment</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Loan Modal */}
      <Modal
        isOpen={isAddLoanModalOpen}
        onClose={() => setIsAddLoanModalOpen(false)}
        title="Add Vehicle Finance Loan"
        subtitle="Register financing company, total loan amount & monthly EMI terms"
      >
        <form onSubmit={handleAddLoanSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Select Financed Auto *</label>
            <select
              id="select-loan-auto"
              required
              value={autoId}
              onChange={(e) => setAutoId(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
            >
              {autos.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.registrationNumber} ({a.model})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Finance Company Name *</label>
              <input
                id="input-loan-company"
                type="text"
                required
                placeholder="e.g. Cholamandalam Finance"
                value={financeCompany}
                onChange={(e) => setFinanceCompany(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Loan Account Number</label>
              <input
                id="input-loan-account-no"
                type="text"
                placeholder="e.g. CHOLA-KA01-99201"
                value={loanAccountNumber}
                onChange={(e) => setLoanAccountNumber(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Total Loan Amount (₹)</label>
              <input
                id="input-loan-total-amt"
                type="number"
                required
                value={totalLoanAmount}
                onChange={(e) => setTotalLoanAmount(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Down Payment (₹)</label>
              <input
                id="input-loan-down-payment"
                type="number"
                value={downPayment}
                onChange={(e) => setDownPayment(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Monthly EMI (₹)</label>
              <input
                id="input-loan-emi-amt"
                type="number"
                required
                value={emiAmount}
                onChange={(e) => setEmiAmount(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-purple-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Loan Start Date</label>
              <input
                id="input-loan-start-date"
                type="date"
                value={loanStartDate}
                onChange={(e) => setLoanStartDate(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Total Number of EMIs</label>
              <input
                id="input-loan-total-emis"
                type="number"
                value={totalEmis}
                onChange={(e) => setTotalEmis(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
              />
            </div>
          </div>

          <button
            id="btn-submit-add-loan"
            type="submit"
            className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-sm transition-all shadow-md"
          >
            Save Loan Record
          </button>
        </form>
      </Modal>

      {/* Pay EMI Modal */}
      {selectedLoan && (
        <Modal
          isOpen={isPayModalOpen}
          onClose={() => setIsPayModalOpen(false)}
          title={`Record EMI #${selectedLoan.emisPaid + 1} of ${selectedLoan.totalEmis}`}
          subtitle={`Auto: ${selectedLoan.autoRegNumber} | Finance: ${selectedLoan.financeCompany}`}
        >
          <form onSubmit={handlePayEmiSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Cleared Date</label>
                <input
                  id="pay-emi-date"
                  type="date"
                  required
                  value={clearedDate}
                  onChange={(e) => setClearedDate(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">EMI Amount (₹)</label>
                <input
                  id="pay-emi-amount"
                  type="number"
                  required
                  value={payEmiAmount}
                  onChange={(e) => setPayEmiAmount(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Late Fee (If Any)</label>
                <input
                  id="pay-emi-latefee"
                  type="number"
                  value={lateFee}
                  onChange={(e) => setLateFee(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Payment Reference #</label>
                <input
                  id="pay-emi-ref"
                  type="text"
                  placeholder="e.g. IMPS/619208129/CHOLA"
                  value={paymentRef}
                  onChange={(e) => setPaymentRef(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
                />
              </div>
            </div>

            <button
              id="btn-submit-pay-emi"
              type="submit"
              className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-sm transition-all shadow-md"
            >
              Clear EMI #{selectedLoan.emisPaid + 1}
            </button>
          </form>
        </Modal>
      )}
    </div>
  );
};
