import React, { useState } from 'react';
import {
  Wallet,
  Search,
  Plus,
  Download,
  Filter,
  CheckCircle,
  Clock,
  AlertTriangle,
  ArrowDownToLine,
} from 'lucide-react';
import { CollectionRecord, Driver, Auto } from '../../types/index';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';

interface CollectionListProps {
  collections: CollectionRecord[];
  drivers: Driver[];
  autos: Auto[];
  userRole: string;
  onAddCollection: (data: Partial<CollectionRecord>) => Promise<void>;
  onUpdateCollection: (id: string, data: Partial<CollectionRecord>) => Promise<void>;
}

export const CollectionList: React.FC<CollectionListProps> = ({
  collections,
  drivers,
  autos,
  userRole,
  onAddCollection,
  onUpdateCollection,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedDriverId, setSelectedDriverId] = useState('all');

  const [isRecordModalOpen, setIsRecordModalOpen] = useState(false);
  const [selectedCol, setSelectedCol] = useState<CollectionRecord | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Record Collection Form
  const [driverId, setDriverId] = useState('');
  const [autoId, setAutoId] = useState('');
  const [dueDate, setDueDate] = useState(new Date().toISOString().split('T')[0]);
  const [amountDue, setAmountDue] = useState(3000);
  const [amountPaid, setAmountPaid] = useState(3000);
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'UPI' | 'Bank Transfer' | 'Cheque'>('UPI');
  const [notes, setNotes] = useState('');

  const isAdmin = userRole === 'admin';

  // Automatically calculated pending amount
  const calculatedPending = Math.max(0, Number(amountDue) - Number(amountPaid));

  const filteredCollections = (collections || []).filter((col) => {
    const term = (searchTerm || '').toLowerCase();
    const matchesSearch =
      (col.driverName || '').toLowerCase().includes(term) ||
      (col.autoRegNumber || '').toLowerCase().includes(term) ||
      (col.id || '').toLowerCase().includes(term);
    const matchesStatus = statusFilter === 'all' || col.paymentStatus === statusFilter;
    const matchesDriver = selectedDriverId === 'all' || col.driverId === selectedDriverId;
    return matchesSearch && matchesStatus && matchesDriver;
  });

  const handleDriverChange = (dId: string) => {
    setDriverId(dId);
    const drv = drivers.find((d) => d.id === dId);
    if (drv) {
      setAmountDue(drv.weeklyCollectionAmount || 3000);
      setAmountPaid(drv.weeklyCollectionAmount || 3000);
      const matchedAuto = autos.find((a) => a.id === drv.assignedAutoId || a.registrationNumber === drv.assignedAutoRegNumber);
      if (matchedAuto) setAutoId(matchedAuto.id);
    }
  };

  const handleOpenRecordModal = () => {
    if (drivers.length > 0) {
      handleDriverChange(drivers[0].id);
    }
    setNotes('');
    setIsRecordModalOpen(true);
  };

  const handleSubmitRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    await onAddCollection({
      driverId,
      autoId,
      dueDate,
      amountDue: Number(amountDue),
      amountPaid: Number(amountPaid),
      paymentDate,
      paymentMethod,
      notes,
    });
    setIsRecordModalOpen(false);
  };

  const handleOpenEdit = (col: CollectionRecord) => {
    setSelectedCol(col);
    setAmountDue(col.amountDue);
    setAmountPaid(col.amountPaid);
    setIsEditModalOpen(true);
  };

  const handleUpdateEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedCol) {
      await onUpdateCollection(selectedCol.id, {
        amountDue: Number(amountDue),
        amountPaid: Number(amountPaid),
      });
      setIsEditModalOpen(false);
    }
  };

  const exportCSV = () => {
    const headers = ['Collection ID', 'Driver', 'Auto Reg', 'Due Date', 'Amount Due', 'Amount Paid', 'Pending Amount', 'Payment Date', 'Method', 'Status'];
    const rows = filteredCollections.map((c) => [
      c.id,
      `"${c.driverName}"`,
      c.autoRegNumber,
      c.dueDate,
      c.amountDue,
      c.amountPaid,
      c.pendingAmount,
      c.paymentDate || '',
      c.paymentMethod || '',
      c.paymentStatus,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Pandithji_Collections_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="collections-module" className="space-y-6 animate-in fade-in duration-200">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Weekly Collection Management</h2>
          <p className="text-xs text-slate-500">Track driver payments, automatic pending balance calculations & collection history</p>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button
            id="btn-export-collections-csv"
            onClick={exportCSV}
            className="px-3.5 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 transition-colors border border-slate-200 dark:border-slate-700"
          >
            <ArrowDownToLine className="w-4 h-4" />
            <span>Export CSV</span>
          </button>

          {isAdmin && (
            <button
              id="btn-record-collection"
              onClick={handleOpenRecordModal}
              className="px-4 py-2.5 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold rounded-xl text-xs flex items-center space-x-2 transition-all shadow-md shadow-indigo-500/20"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Record Payment</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input
            id="search-collections-input"
            type="text"
            placeholder="Search driver, auto, collection ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-hidden"
          />
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <select
            id="filter-col-driver"
            value={selectedDriverId}
            onChange={(e) => setSelectedDriverId(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold"
          >
            <option value="all">All Drivers</option>
            {drivers.map((d) => (
              <option key={d.id} value={d.id}>{d.fullName}</option>
            ))}
          </select>

          <select
            id="filter-col-status"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold"
          >
            <option value="all">All Statuses</option>
            <option value="Paid">Paid</option>
            <option value="Partially Paid">Partially Paid</option>
            <option value="Pending">Pending</option>
          </select>
        </div>
      </div>

      {/* Collections Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 uppercase font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-4 py-3">Collection ID</th>
                <th className="px-4 py-3">Driver</th>
                <th className="px-4 py-3">Auto Reg</th>
                <th className="px-4 py-3">Due Date</th>
                <th className="px-4 py-3">Amount Due</th>
                <th className="px-4 py-3">Amount Paid</th>
                <th className="px-4 py-3">Pending Amount</th>
                <th className="px-4 py-3">Status</th>
                {isAdmin && <th className="px-4 py-3 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredCollections.map((col) => (
                <tr key={col.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                  <td className="px-4 py-3 font-mono text-slate-500 font-semibold">{col.id}</td>
                  <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">{col.driverName}</td>
                  <td className="px-4 py-3 font-mono font-bold text-slate-700 dark:text-slate-300">{col.autoRegNumber}</td>
                  <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{col.dueDate}</td>
                  <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">
                    ₹{col.amountDue.toLocaleString('en-IN')}
                  </td>
                  <td className="px-4 py-3 font-bold text-violet-600 dark:text-violet-400">
                    ₹{col.amountPaid.toLocaleString('en-IN')}
                  </td>
                  <td className="px-4 py-3 font-bold text-rose-600 dark:text-rose-400">
                    ₹{col.pendingAmount.toLocaleString('en-IN')}
                  </td>
                  <td className="px-4 py-3">
                    <Badge
                      variant={
                        col.paymentStatus === 'Paid'
                          ? 'success'
                          : col.paymentStatus === 'Partially Paid'
                          ? 'warning'
                          : 'danger'
                      }
                    >
                      {col.paymentStatus}
                    </Badge>
                  </td>
                  {isAdmin && (
                    <td className="px-4 py-3 text-right">
                      <button
                        id={`btn-edit-col-${col.id}`}
                        onClick={() => handleOpenEdit(col)}
                        className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold rounded-lg text-xs"
                      >
                        Edit Payment
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Collection Modal */}
      <Modal
        isOpen={isRecordModalOpen}
        onClose={() => setIsRecordModalOpen(false)}
        title="Record Weekly Collection Payment"
        subtitle="Log driver payment with automatic pending amount calculation"
      >
        <form onSubmit={handleSubmitRecord} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Select Driver *</label>
            <select
              id="select-col-driver"
              required
              value={driverId}
              onChange={(e) => handleDriverChange(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
            >
              {drivers.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.fullName} ({d.assignedAutoRegNumber || 'No Auto'})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Collection Due Date</label>
              <input
                id="input-col-duedate"
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Payment Method</label>
              <select
                id="select-col-method"
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as any)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              >
                <option value="UPI">UPI (GPay / PhonePe / Paytm)</option>
                <option value="Cash">Cash at Shed</option>
                <option value="Bank Transfer">Bank Transfer (NEFT/IMPS)</option>
                <option value="Cheque">Cheque</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Weekly Rent Due (₹)</label>
              <input
                id="input-col-amountdue"
                type="number"
                required
                value={amountDue}
                onChange={(e) => setAmountDue(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Amount Paid (₹)</label>
              <input
                id="input-col-amountpaid"
                type="number"
                required
                value={amountPaid}
                onChange={(e) => setAmountPaid(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-violet-600"
              />
            </div>
          </div>

          {/* Automatic Calculation Highlight */}
          <div className="p-3 bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-900/50 rounded-xl flex justify-between items-center font-bold">
            <span className="text-indigo-800 dark:text-indigo-300">Automatically Calculated Pending:</span>
            <span className="text-rose-600 dark:text-rose-400 font-mono text-sm">₹{calculatedPending.toLocaleString('en-IN')}</span>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Payment Notes</label>
            <input
              id="input-col-notes"
              type="text"
              placeholder="e.g. Paid via GPay. Balance promised by Saturday."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
          </div>

          <button
            id="btn-submit-record-collection"
            type="submit"
            className="w-full py-3 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold rounded-xl text-sm transition-all shadow-md"
          >
            Save Collection Record
          </button>
        </form>
      </Modal>

      {/* Edit Payment Modal */}
      {selectedCol && (
        <Modal
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          title={`Edit Collection #${selectedCol.id}`}
          subtitle={`Driver: ${selectedCol.driverName} | Auto: ${selectedCol.autoRegNumber}`}
        >
          <form onSubmit={handleUpdateEdit} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Amount Due (₹)</label>
              <input
                id="edit-input-amountdue"
                type="number"
                value={amountDue}
                onChange={(e) => setAmountDue(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Amount Paid (₹)</label>
              <input
                id="edit-input-amountpaid"
                type="number"
                value={amountPaid}
                onChange={(e) => setAmountPaid(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-violet-600"
              />
            </div>

            <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-xl flex justify-between font-bold">
              <span>New Calculated Pending:</span>
              <span className="text-rose-600">₹{Math.max(0, amountDue - amountPaid).toLocaleString('en-IN')}</span>
            </div>

            <button
              id="btn-submit-update-collection"
              type="submit"
              className="w-full py-3 bg-indigo-500 hover:bg-indigo-400 text-slate-950 font-bold rounded-xl text-sm"
            >
              Update Collection Record
            </button>
          </form>
        </Modal>
      )}
    </div>
  );
};
