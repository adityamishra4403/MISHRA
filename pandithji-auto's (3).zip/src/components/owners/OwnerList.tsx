import React, { useState } from 'react';
import { Shield, Plus, Lock, CheckCircle, XCircle } from 'lucide-react';
import { User, OwnerPermissions } from '../../types/index';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';

interface OwnerListProps {
  users: User[];
  onAddOwner: (data: any) => Promise<void>;
  onUpdatePermissions: (ownerId: string, perms: OwnerPermissions) => Promise<void>;
}

export const OwnerList: React.FC<OwnerListProps> = ({
  users,
  onAddOwner,
  onUpdatePermissions,
}) => {
  const owners = (users || []).filter((u) => u.role === 'owner');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form State
  const [username, setUsername] = useState('owner2');
  const [password, setPassword] = useState('owner123');
  const [name, setName] = useState('Suresh Patel');
  const [mobileNumber, setMobileNumber] = useState('9845012345');

  const [perms, setPerms] = useState<OwnerPermissions>({
    viewVehicles: true,
    viewCollections: true,
    viewFinancialReports: true,
    viewEmiLoans: true,
    viewDriverInfo: true,
    viewServiceLogs: true,
  });

  const handleOpenAdd = () => {
    setUsername(`owner_${Date.now().toString().slice(-4)}`);
    setPassword('owner123');
    setName('');
    setMobileNumber('');
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onAddOwner({
      username,
      password,
      name,
      mobileNumber,
      ownerPermissions: perms,
    });
    setIsModalOpen(false);
  };

  const handleTogglePerm = async (owner: User, key: keyof OwnerPermissions) => {
    if (!owner.ownerPermissions) return;
    const updated = {
      ...owner.ownerPermissions,
      [key]: !owner.ownerPermissions[key],
    };
    await onUpdatePermissions(owner.id, updated);
  };

  return (
    <div id="owners-module" className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Business Owner Accounts</h2>
          <p className="text-xs text-slate-500">Create owner accounts and configure granular feature & financial permissions</p>
        </div>

        <button
          id="btn-add-owner-account"
          onClick={handleOpenAdd}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center space-x-2 transition-all shadow-md shadow-blue-600/20 shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Create Owner Account</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {owners.map((owner) => {
          const pPerms = owner.ownerPermissions || perms;

          return (
            <div
              key={owner.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <div>
                  <h3 className="font-bold text-base text-slate-900 dark:text-white">{owner.name}</h3>
                  <span className="text-xs text-slate-500 font-mono">Username: {owner.username} | {owner.mobileNumber}</span>
                </div>
                <Badge variant="info">Business Owner</Badge>
              </div>

              {/* Granular Permission Control Toggles */}
              <div className="space-y-2 text-xs">
                <span className="font-bold text-slate-700 dark:text-slate-300 block mb-2">Granular Access Permissions:</span>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    id={`perm-vehicles-${owner.id}`}
                    onClick={() => handleTogglePerm(owner, 'viewVehicles')}
                    className={`p-2.5 rounded-xl border flex items-center justify-between transition-all font-semibold ${
                      pPerms.viewVehicles
                        ? 'bg-violet-50 dark:bg-violet-950/30 border-violet-300 text-violet-800 dark:text-violet-300'
                        : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 text-slate-500'
                    }`}
                  >
                    <span>View Autos</span>
                    {pPerms.viewVehicles ? <CheckCircle className="w-4 h-4 text-violet-500" /> : <Lock className="w-4 h-4" />}
                  </button>

                  <button
                    id={`perm-collections-${owner.id}`}
                    onClick={() => handleTogglePerm(owner, 'viewCollections')}
                    className={`p-2.5 rounded-xl border flex items-center justify-between transition-all font-semibold ${
                      pPerms.viewCollections
                        ? 'bg-violet-50 dark:bg-violet-950/30 border-violet-300 text-violet-800 dark:text-violet-300'
                        : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 text-slate-500'
                    }`}
                  >
                    <span>View Collections</span>
                    {pPerms.viewCollections ? <CheckCircle className="w-4 h-4 text-violet-500" /> : <Lock className="w-4 h-4" />}
                  </button>

                  <button
                    id={`perm-finances-${owner.id}`}
                    onClick={() => handleTogglePerm(owner, 'viewFinancialReports')}
                    className={`p-2.5 rounded-xl border flex items-center justify-between transition-all font-semibold ${
                      pPerms.viewFinancialReports
                        ? 'bg-violet-50 dark:bg-violet-950/30 border-violet-300 text-violet-800 dark:text-violet-300'
                        : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 text-slate-500'
                    }`}
                  >
                    <span>View Financials</span>
                    {pPerms.viewFinancialReports ? <CheckCircle className="w-4 h-4 text-violet-500" /> : <Lock className="w-4 h-4" />}
                  </button>

                  <button
                    id={`perm-emi-${owner.id}`}
                    onClick={() => handleTogglePerm(owner, 'viewEmiLoans')}
                    className={`p-2.5 rounded-xl border flex items-center justify-between transition-all font-semibold ${
                      pPerms.viewEmiLoans
                        ? 'bg-purple-50 dark:bg-purple-950/30 border-purple-300 text-purple-800 dark:text-purple-300'
                        : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 text-slate-500'
                    }`}
                  >
                    <span>View Private EMI</span>
                    {pPerms.viewEmiLoans ? <CheckCircle className="w-4 h-4 text-purple-500" /> : <Lock className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Create Business Owner Login"
        subtitle="Set owner credentials and initial access permissions"
      >
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Owner Full Name *</label>
            <input
              id="input-owner-name"
              type="text"
              required
              placeholder="e.g. Suresh Patel"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Username *</label>
              <input
                id="input-owner-username"
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Password *</label>
              <input
                id="input-owner-password"
                type="text"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Mobile Number</label>
            <input
              id="input-owner-mobile"
              type="tel"
              value={mobileNumber}
              onChange={(e) => setMobileNumber(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
            />
          </div>

          <button
            id="btn-submit-owner"
            type="submit"
            className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-sm transition-all shadow-md"
          >
            Create Owner Account
          </button>
        </form>
      </Modal>
    </div>
  );
};
