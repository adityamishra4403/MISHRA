import React from 'react';
import {
  Car,
  Users,
  Wallet,
  Wrench,
  AlertTriangle,
  TrendingUp,
  Landmark,
  FileCheck,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  ShieldAlert,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  Auto,
  Driver,
  CollectionRecord,
  ServiceRecord,
  ExpenseRecord,
  EmiLoan,
  VehicleDocument,
  NotificationItem,
} from '../../types/index';
import { Badge } from '../common/Badge';

interface AdminDashboardProps {
  autos: Auto[];
  drivers: Driver[];
  collections: CollectionRecord[];
  services: ServiceRecord[];
  expenses: ExpenseRecord[];
  emiLoans: EmiLoan[];
  documents: VehicleDocument[];
  notifications: NotificationItem[];
  onNavigate: (tab: any) => void;
  onOpenRecordCollection: () => void;
  onOpenAddAuto: () => void;
  onOpenLogService: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  autos,
  drivers,
  collections,
  services,
  expenses,
  emiLoans,
  documents,
  notifications,
  onNavigate,
  onOpenRecordCollection,
  onOpenAddAuto,
  onOpenLogService,
}) => {
  // Metrics Calculations
  const totalAutos = autos.length;
  const availableAutos = autos.filter((a) => a.status === 'available').length;
  const assignedAutos = autos.filter((a) => a.status === 'assigned').length;
  const serviceAutos = autos.filter((a) => a.status === 'service').length;
  const totalActiveDrivers = drivers.filter((d) => d.driverStatus === 'active').length;

  const totalWeeklyDue = collections.reduce((acc, c) => acc + c.amountDue, 0);
  const totalWeeklyPaid = collections.reduce((acc, c) => acc + c.amountPaid, 0);
  const totalWeeklyPending = collections.reduce((acc, c) => acc + c.pendingAmount, 0);

  const totalMonthlyExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);
  const totalMonthlyRevenue = totalWeeklyPaid;

  const activeLoans = emiLoans.filter((l) => l.emiStatus === 'Active');
  const overdueLoans = emiLoans.filter((l) => l.emiStatus === 'Overdue');

  // Chart Data Preparation
  const chartData = [
    { name: 'Week 1', Collections: 8500, Expenses: 1200 },
    { name: 'Week 2', Collections: 9200, Expenses: 3800 },
    { name: 'Week 3', Collections: 9000, Expenses: 1500 },
    { name: 'Current Wk', Collections: totalWeeklyPaid, Expenses: totalMonthlyExpenses },
  ];

  const pieData = [
    { name: 'Assigned', value: assignedAutos, color: '#10b981' },
    { name: 'Available', value: availableAutos, color: '#f59e0b' },
    { name: 'Under Service', value: serviceAutos, color: '#ef4444' },
  ];

  return (
    <div id="admin-dashboard-container" className="space-y-6 animate-in fade-in duration-200 font-sans">
      {/* Top Banner / Quick Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-6 text-white shadow-2xl">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 bg-violet-500/20 text-violet-400 border border-violet-500/30 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
            <span>Pandithji Auto's Owner Dashboard</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight italic">
            Fleet Overview & <span className="text-violet-400 font-black">Business Intelligence</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time tracking for {totalAutos} Autos, {totalActiveDrivers} Active Drivers and Weekly Collection Flows
          </p>
        </div>

        <div className="flex items-center space-x-3 shrink-0">
          <button
            id="btn-quick-record-collection"
            onClick={onOpenRecordCollection}
            className="px-5 py-2.5 bg-violet-500 hover:bg-violet-400 text-slate-950 font-extrabold rounded-xl text-xs flex items-center space-x-2 transition-all shadow-lg shadow-violet-500/20"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Record Collection</span>
          </button>
          <button
            id="btn-quick-add-auto"
            onClick={onOpenAddAuto}
            className="px-4 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold rounded-xl text-xs flex items-center space-x-2 transition-all"
          >
            <Car className="w-4 h-4 text-violet-400" />
            <span>Add Auto</span>
          </button>
        </div>
      </div>

      {/* KPI Stat Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total & Assigned Autos */}
        <div
          id="kpi-card-autos"
          onClick={() => onNavigate('autos')}
          className="bg-white/5 border border-white/10 backdrop-blur-md p-5 rounded-2xl hover:border-violet-500/40 cursor-pointer transition-all group shadow-lg"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Auto Fleet</span>
            <div className="p-2.5 bg-violet-500/20 text-violet-400 border border-violet-500/30 rounded-xl">
              <Car className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-black text-white tracking-tight">{totalAutos}</span>
            <span className="text-xs text-slate-400 ml-2 font-medium">Total Fleet</span>
          </div>
          <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
            <span className="text-violet-400 font-semibold">{assignedAutos} Assigned</span>
            <span className="text-indigo-400 font-semibold">{availableAutos} Free</span>
            <span className="text-rose-400 font-semibold">{serviceAutos} Service</span>
          </div>
        </div>

        {/* Weekly Collections */}
        <div
          id="kpi-card-collections"
          onClick={() => onNavigate('collections')}
          className="bg-white/5 border border-white/10 backdrop-blur-md p-5 rounded-2xl hover:border-violet-500/40 cursor-pointer transition-all group shadow-lg"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Weekly Revenue</span>
            <div className="p-2.5 bg-violet-500/20 text-violet-400 border border-violet-500/30 rounded-xl">
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-black text-white tracking-tight italic">
              ₹{totalWeeklyPaid.toLocaleString('en-IN')}
            </span>
            <span className="text-xs text-violet-400 font-bold ml-2">Collected</span>
          </div>
          <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
            <span className="text-slate-400">Target: ₹{totalWeeklyDue.toLocaleString('en-IN')}</span>
            <span className="text-indigo-400 font-bold">Pending: ₹{totalWeeklyPending.toLocaleString('en-IN')}</span>
          </div>
        </div>

        {/* Active Drivers */}
        <div
          id="kpi-card-drivers"
          onClick={() => onNavigate('drivers')}
          className="bg-white/5 border border-white/10 backdrop-blur-md p-5 rounded-2xl hover:border-blue-500/40 cursor-pointer transition-all group shadow-lg"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Drivers</span>
            <div className="p-2.5 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded-xl">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-black text-white tracking-tight">{totalActiveDrivers}</span>
            <span className="text-xs text-blue-400 font-bold ml-2">Active</span>
          </div>
          <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
            <span>{drivers.length} Registered</span>
            <span className="text-violet-400 font-semibold">100% On-Boarded</span>
          </div>
        </div>

        {/* EMI Loans & Finance */}
        <div
          id="kpi-card-emis"
          onClick={() => onNavigate('emis')}
          className="bg-white/5 border border-white/10 backdrop-blur-md p-5 rounded-2xl border-l-4 border-l-indigo-500 hover:border-indigo-500/40 cursor-pointer transition-all group shadow-lg"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Loans & EMIs</span>
            <div className="p-2.5 bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded-xl">
              <Landmark className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-black text-white tracking-tight">{activeLoans.length}</span>
            <span className="text-xs text-indigo-400 font-bold ml-2">Financed</span>
          </div>
          <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
            <span className="text-slate-400">
              Next: ₹{activeLoans[0]?.emiAmount?.toLocaleString('en-IN') || 0}
            </span>
            {overdueLoans.length > 0 ? (
              <span className="text-rose-400 font-bold">{overdueLoans.length} Overdue</span>
            ) : (
              <span className="text-violet-400 font-semibold">On Track</span>
            )}
          </div>
        </div>
      </div>

      {/* Analytics Charts & Fleet Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Weekly Financial Bar Chart */}
        <div className="lg:col-span-2 bg-slate-900/50 backdrop-blur-md border border-white/10 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-white">Collections vs Expenses Trend</h3>
              <p className="text-xs text-slate-400">Weekly revenue collections compared against maintenance & operational costs</p>
            </div>
            <div className="flex items-center space-x-3 text-xs font-semibold">
              <div className="flex items-center space-x-1.5">
                <div className="w-3 h-3 rounded-xs bg-violet-500" />
                <span className="text-slate-300">Collections</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <div className="w-3 h-3 rounded-xs bg-rose-500" />
                <span className="text-slate-300">Expenses</span>
              </div>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ffffff" opacity={0.08} />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: 'rgba(255,255,255,0.1)',
                    borderRadius: '0.75rem',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="Collections" fill="#10b981" radius={[6, 6, 0, 0]} />
                <Bar dataKey="Expenses" fill="#f43f5e" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Fleet Status Pie */}
        <div className="bg-slate-900/50 backdrop-blur-md border border-white/10 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-white">Fleet Utilization</h3>
            <p className="text-xs text-slate-400">Status distribution across active autos</p>
            <div className="h-44 w-full my-2">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={75}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: 'rgba(255,255,255,0.1)',
                      borderRadius: '0.5rem',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="space-y-2 pt-3 border-t border-white/10 text-xs">
            {pieData.map((item) => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-slate-300">{item.name}</span>
                </div>
                <span className="font-bold text-white">{item.value} Autos</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Expiries, Reminders & Recent Collections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Urgent Expiries & Reminders */}
        <div className="bg-slate-900/50 backdrop-blur-md border border-white/10 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <ShieldAlert className="w-5 h-5 text-indigo-400" />
              <h3 className="text-base font-bold text-white">Documents Expiring Soon</h3>
            </div>
            <button
              onClick={() => onNavigate('documents')}
              className="text-xs font-bold text-violet-400 hover:underline"
            >
              View Vault
            </button>
          </div>

          <div className="space-y-3">
            {autos
              .filter(
                (a) =>
                  a.insuranceExpiryDate?.includes('2026-08') ||
                  a.pucExpiryDate?.includes('2026-08') ||
                  a.insuranceExpiryDate?.includes('2026-09')
              )
              .map((auto) => (
                <div
                  key={auto.id}
                  className="p-3.5 bg-indigo-500/10 border border-indigo-500/20 rounded-xl flex items-center justify-between"
                >
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-black text-white font-mono">
                        {auto.registrationNumber}
                      </span>
                      <span className="text-[11px] text-slate-400">({auto.model})</span>
                    </div>
                    <p className="text-xs text-indigo-300 mt-0.5">
                      Insurance/PUC renewal due: {auto.pucExpiryDate || auto.insuranceExpiryDate}
                    </p>
                  </div>
                  <Badge variant="warning">Action Needed</Badge>
                </div>
              ))}

            {drivers
              .filter((d) => d.licenseExpiryDate?.includes('2026-08'))
              .map((drv) => (
                <div
                  key={drv.id}
                  className="p-3.5 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-center justify-between"
                >
                  <div>
                    <span className="text-xs font-bold text-white">
                      Driver Licence Expiry: {drv.fullName}
                    </span>
                    <p className="text-xs text-rose-300 mt-0.5">
                      Licence #{drv.licenseNumber} expires {drv.licenseExpiryDate}
                    </p>
                  </div>
                  <Badge variant="danger">Critical</Badge>
                </div>
              ))}
          </div>
        </div>

        {/* Recent Weekly Collections Table */}
        <div className="bg-slate-900/50 backdrop-blur-md border border-white/10 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-white">Recent Weekly Collections</h3>
            <button
              onClick={() => onNavigate('collections')}
              className="text-xs font-bold text-violet-400 hover:underline"
            >
              View All
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-white/5 text-slate-400 uppercase font-semibold border-b border-white/10">
                <tr>
                  <th className="px-3 py-2.5 rounded-l-lg">Driver / Auto</th>
                  <th className="px-3 py-2.5">Due Date</th>
                  <th className="px-3 py-2.5">Paid / Due</th>
                  <th className="px-3 py-2.5 rounded-r-lg">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {collections.slice(0, 4).map((col) => (
                  <tr key={col.id} className="hover:bg-white/5 transition-colors">
                    <td className="px-3 py-3">
                      <div className="font-bold text-white">{col.driverName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{col.autoRegNumber}</div>
                    </td>
                    <td className="px-3 py-3 text-slate-300">{col.dueDate}</td>
                    <td className="px-3 py-3 font-bold text-white">
                      ₹{col.amountPaid.toLocaleString('en-IN')} / ₹{col.amountDue.toLocaleString('en-IN')}
                    </td>
                    <td className="px-3 py-3">
                      <Badge
                        variant={
                          col.paymentStatus === 'Paid'
                            ? 'success'
                            : col.paymentStatus === 'Partially Paid'
                            ? 'warning'
                            : 'danger'
                        }
                      >
                        {col.paymentStatus}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
