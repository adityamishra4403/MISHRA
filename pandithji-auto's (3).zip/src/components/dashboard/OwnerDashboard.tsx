import React from 'react';
import {
  Car,
  Users,
  Wallet,
  Wrench,
  BarChart3,
  Shield,
  FileText,
  Lock,
} from 'lucide-react';
import {
  Auto,
  Driver,
  CollectionRecord,
  ServiceRecord,
  ExpenseRecord,
  User,
} from '../../types/index';
import { Badge } from '../common/Badge';

interface OwnerDashboardProps {
  owner: User;
  autos: Auto[];
  drivers: Driver[];
  collections: CollectionRecord[];
  services: ServiceRecord[];
  expenses: ExpenseRecord[];
  onNavigate: (tab: any) => void;
}

export const OwnerDashboard: React.FC<OwnerDashboardProps> = ({
  owner,
  autos,
  drivers,
  collections,
  services,
  expenses,
  onNavigate,
}) => {
  const perms = owner.ownerPermissions;

  const totalAutos = autos.length;
  const activeAutos = autos.filter((a) => a.status === 'assigned').length;
  const activeDrivers = drivers.filter((d) => d.driverStatus === 'active').length;

  const totalPaid = collections.reduce((acc, c) => acc + c.amountPaid, 0);
  const totalPending = collections.reduce((acc, c) => acc + c.pendingAmount, 0);
  const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);

  return (
    <div id="owner-dashboard-container" className="space-y-6 animate-in fade-in duration-200">
      {/* Owner Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-slate-900 to-slate-900 border border-blue-800/60 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-0.5 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded-full text-[11px] font-bold uppercase tracking-wider mb-1">
            <span>Business Owner Portal</span>
          </div>
          <h2 className="text-2xl font-black tracking-tight">Owner Performance Dashboard</h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Controlled access mode for <span className="font-bold text-blue-400">{owner.name}</span>
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <Shield className="w-5 h-5 text-blue-400" />
          <span className="text-xs text-slate-300 font-medium">Owner Controlled Permissions</span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {perms?.viewVehicles ? (
          <div
            onClick={() => onNavigate('autos')}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs cursor-pointer hover:border-blue-500/40 transition-all"
          >
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Fleet Summary</span>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl font-black text-slate-900 dark:text-white">{totalAutos}</span>
              <span className="text-xs text-violet-600 font-bold">{activeAutos} Active</span>
            </div>
          </div>
        ) : (
          <div className="bg-slate-100 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 opacity-60 flex items-center justify-between text-xs text-slate-400">
            <span>Vehicle Access Restricted</span>
            <Lock className="w-4 h-4" />
          </div>
        )}

        {perms?.viewCollections ? (
          <div
            onClick={() => onNavigate('collections')}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs cursor-pointer hover:border-violet-500/40 transition-all"
          >
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Collections Paid</span>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl font-black text-slate-900 dark:text-white">
                ₹{totalPaid.toLocaleString('en-IN')}
              </span>
              <span className="text-xs text-rose-600 font-bold">Pending: ₹{totalPending.toLocaleString('en-IN')}</span>
            </div>
          </div>
        ) : (
          <div className="bg-slate-100 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 opacity-60 flex items-center justify-between text-xs text-slate-400">
            <span>Collections Access Restricted</span>
            <Lock className="w-4 h-4" />
          </div>
        )}

        {perms?.viewFinancialReports ? (
          <div
            onClick={() => onNavigate('reports')}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs cursor-pointer hover:border-indigo-500/40 transition-all"
          >
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Fleet Expenses</span>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl font-black text-slate-900 dark:text-white">
                ₹{totalExpenses.toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        ) : (
          <div className="bg-slate-100 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 opacity-60 flex items-center justify-between text-xs text-slate-400">
            <span>Financial Access Restricted</span>
            <Lock className="w-4 h-4" />
          </div>
        )}

        {perms?.viewDriverInfo ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Active Drivers</span>
            <div className="mt-2">
              <span className="text-2xl font-black text-slate-900 dark:text-white">{activeDrivers}</span>
            </div>
          </div>
        ) : (
          <div className="bg-slate-100 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 opacity-60 flex items-center justify-between text-xs text-slate-400">
            <span>Driver Info Restricted</span>
            <Lock className="w-4 h-4" />
          </div>
        )}
      </div>

      {/* Allowed Section Summary */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs">
        <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">Owner Permission Matrix</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl flex items-center justify-between">
            <span>Vehicles</span>
            <Badge variant={perms?.viewVehicles ? 'success' : 'neutral'}>
              {perms?.viewVehicles ? 'Granted' : 'Locked'}
            </Badge>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl flex items-center justify-between">
            <span>Collections</span>
            <Badge variant={perms?.viewCollections ? 'success' : 'neutral'}>
              {perms?.viewCollections ? 'Granted' : 'Locked'}
            </Badge>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl flex items-center justify-between">
            <span>Financial Reports</span>
            <Badge variant={perms?.viewFinancialReports ? 'success' : 'neutral'}>
              {perms?.viewFinancialReports ? 'Granted' : 'Locked'}
            </Badge>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl flex items-center justify-between">
            <span>EMI & Loans</span>
            <Badge variant={perms?.viewEmiLoans ? 'success' : 'neutral'}>
              {perms?.viewEmiLoans ? 'Granted' : 'Locked'}
            </Badge>
          </div>
        </div>
      </div>
    </div>
  );
};
