import React from 'react';
import {
  Car,
  Wallet,
  Wrench,
  FileText,
  Calendar,
  CheckCircle2,
  Clock,
  AlertCircle,
  ShieldCheck,
  User,
} from 'lucide-react';
import {
  Auto,
  Driver,
  CollectionRecord,
  ServiceRecord,
  VehicleDocument,
} from '../../types/index';
import { Badge } from '../common/Badge';

interface DriverDashboardProps {
  driver: Driver;
  auto?: Auto;
  collections: CollectionRecord[];
  services: ServiceRecord[];
  documents: VehicleDocument[];
}

export const DriverDashboard: React.FC<DriverDashboardProps> = ({
  driver,
  auto,
  collections,
  services,
  documents,
}) => {
  const totalPaid = collections.reduce((acc, c) => acc + c.amountPaid, 0);
  const totalPending = collections.reduce((acc, c) => acc + c.pendingAmount, 0);
  const latestCollection = collections[0];

  return (
    <div id="driver-dashboard-container" className="space-y-6 animate-in fade-in duration-200">
      {/* Driver Welcome Header */}
      <div className="bg-gradient-to-r from-violet-900 via-slate-900 to-slate-900 border border-violet-800/60 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-violet-500 text-slate-950 font-black text-2xl flex items-center justify-center shadow-lg shadow-violet-500/20 shrink-0">
            {(driver?.fullName || 'Driver').charAt(0).toUpperCase()}
          </div>
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-0.5 bg-violet-500/20 text-violet-400 border border-violet-500/30 rounded-full text-[11px] font-bold uppercase tracking-wider mb-1">
              <span>Driver Portal</span>
            </div>
            <h2 className="text-2xl font-black tracking-tight">Welcome, {driver?.fullName || 'Driver'}</h2>
            <p className="text-xs text-slate-300 mt-0.5 font-mono">
              Assigned Auto: <span className="font-bold text-violet-400">{driver?.assignedAutoRegNumber || 'None'}</span> | Weekly Collection: ₹{(driver?.weeklyCollectionAmount || 0).toLocaleString('en-IN')}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3 shrink-0">
          <div className="px-4 py-2 bg-slate-800/80 border border-slate-700/80 rounded-2xl text-right">
            <span className="text-[10px] text-slate-400 block uppercase font-bold">Total Collection Paid</span>
            <span className="text-lg font-black text-violet-400 font-mono">₹{totalPaid.toLocaleString('en-IN')}</span>
          </div>
        </div>
      </div>

      {/* Grid: My Auto & Payment Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* My Auto Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <Car className="w-5 h-5 text-indigo-500" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">My Auto Details</h3>
            </div>
            {auto && (
              <Badge variant={auto.status === 'assigned' ? 'success' : 'warning'}>
                {auto.status}
              </Badge>
            )}
          </div>

          {auto ? (
            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                <span className="text-slate-500 block text-[10px] uppercase font-bold">Registration Number</span>
                <span className="text-lg font-black font-mono text-slate-900 dark:text-white">
                  {auto.registrationNumber}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-lg">
                  <span className="text-slate-500 block text-[10px]">Model</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">{auto.model}</span>
                </div>
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-lg">
                  <span className="text-slate-500 block text-[10px]">Date Allotted</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">{auto.dateGivenToDriver || driver.dateJoined}</span>
                </div>
              </div>

              <div className="p-3 border border-slate-100 dark:border-slate-800 rounded-xl space-y-2">
                <div className="flex justify-between items-center text-slate-600 dark:text-slate-300">
                  <span>Weekly Fixed Rent:</span>
                  <span className="font-bold text-slate-900 dark:text-white">₹{auto.weeklyCollectionAmount.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-6 text-center text-slate-500 text-xs">
              No Auto assigned currently. Please contact Pandithji.
            </div>
          )}
        </div>

        {/* Collections Overview & Status */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <Wallet className="w-5 h-5 text-violet-500" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">My Collections & Payments</h3>
            </div>
            {totalPending > 0 ? (
              <Badge variant="warning">Pending ₹{totalPending.toLocaleString('en-IN')}</Badge>
            ) : (
              <Badge variant="success">All Clear</Badge>
            )}
          </div>

          {/* Collection History Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 uppercase font-semibold">
                <tr>
                  <th className="px-3 py-2.5 rounded-l-lg">Due Date</th>
                  <th className="px-3 py-2.5">Weekly Amount</th>
                  <th className="px-3 py-2.5">Paid</th>
                  <th className="px-3 py-2.5">Pending</th>
                  <th className="px-3 py-2.5">Method</th>
                  <th className="px-3 py-2.5 rounded-r-lg">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {collections.map((col) => (
                  <tr key={col.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                    <td className="px-3 py-2.5 font-medium text-slate-900 dark:text-white">{col.dueDate}</td>
                    <td className="px-3 py-2.5 text-slate-700 dark:text-slate-300">₹{col.amountDue.toLocaleString('en-IN')}</td>
                    <td className="px-3 py-2.5 font-bold text-violet-600 dark:text-violet-400">₹{col.amountPaid.toLocaleString('en-IN')}</td>
                    <td className="px-3 py-2.5 font-bold text-rose-600 dark:text-rose-400">₹{col.pendingAmount.toLocaleString('en-IN')}</td>
                    <td className="px-3 py-2.5 text-slate-500">{col.paymentMethod || '-'}</td>
                    <td className="px-3 py-2.5">
                      <Badge
                        variant={
                          col.paymentStatus === 'Paid'
                            ? 'success'
                            : col.paymentStatus === 'Partially Paid'
                            ? 'warning'
                            : 'danger'
                        }
                      >
                        {col.paymentStatus}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Services & Permitted Documents */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Service History */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-100 dark:border-slate-800 pb-3">
            <Wrench className="w-5 h-5 text-blue-500" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Auto Maintenance & Services</h3>
          </div>

          <div className="space-y-3">
            {services.map((srv) => (
              <div
                key={srv.id}
                className="p-3.5 bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-700/50 rounded-xl space-y-1.5"
              >
                <div className="flex justify-between items-center text-xs font-bold text-slate-900 dark:text-white">
                  <span>{srv.serviceType} Service ({srv.serviceDate})</span>
                  <span className="font-mono text-slate-500">{srv.currentKm} KM</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300">{srv.partsReplaced || 'Routine checkup'}</p>
                <p className="text-[11px] text-slate-400">Garage: {srv.garageName}</p>
              </div>
            ))}
            {services.length === 0 && (
              <p className="text-xs text-slate-500 text-center py-4">No service records for this vehicle.</p>
            )}
          </div>
        </div>

        {/* Visible Vehicle Documents */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center space-x-2 border-b border-slate-100 dark:border-slate-800 pb-3">
            <FileText className="w-5 h-5 text-purple-500" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white">My Vehicle & Driver Documents</h3>
          </div>

          <div className="space-y-2.5">
            {documents.map((doc) => (
              <div
                key={doc.id}
                className="p-3 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-slate-900 dark:text-white">{doc.documentName}</div>
                  <div className="text-[11px] text-slate-500">Doc #: {doc.documentNumber || 'N/A'}</div>
                </div>
                {doc.expiryDate && (
                  <Badge variant="info">Expires {doc.expiryDate}</Badge>
                )}
              </div>
            ))}
            {documents.length === 0 && (
              <p className="text-xs text-slate-500 text-center py-4">No documents shared by Owner.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
