import React from 'react';
import {
  LayoutDashboard,
  Car,
  Users,
  WalletCards,
  Landmark,
  Wrench,
  Receipt,
  BarChart3,
  FileText,
  UserCheck,
  Bell,
  History,
  Database,
  Settings,
  User as UserIcon,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export type NavTab =
  | 'dashboard'
  | 'autos'
  | 'drivers'
  | 'collections'
  | 'emis'
  | 'services'
  | 'expenses'
  | 'reports'
  | 'documents'
  | 'owners'
  | 'notifications'
  | 'activity'
  | 'backup'
  | 'settings'
  | 'profile';

export type NavigationTab = NavTab;

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab?: (tab: NavTab) => void;
  onTabChange?: (tab: NavTab) => void;
  onNavigate?: (tab: NavTab) => void;
  userRole?: string;
  ownerPermissions?: any;
  unreadNotifCount?: number;
  isOpen?: boolean;
  onClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  onTabChange,
  onNavigate,
  unreadNotifCount = 0,
  isOpen = false,
  onClose,
}) => {
  const handleTabSelect = (tab: NavTab) => {
    if (typeof onTabChange === 'function') {
      onTabChange(tab);
    }
    if (typeof setActiveTab === 'function') {
      setActiveTab(tab);
    }
    if (typeof onNavigate === 'function') {
      onNavigate(tab);
    }
    if (typeof onClose === 'function') {
      onClose();
    }
  };
  const { user } = useAuth();

  if (!user) return null;

  const role = user.role;
  const ownerPerms = user.ownerPermissions;

  // Build navigation items based on exact role permissions
  const getNavItems = () => {
    if (role === 'admin') {
      return [
        { id: 'dashboard' as NavTab, label: 'Dashboard', icon: LayoutDashboard },
        { id: 'autos' as NavTab, label: 'Autos', icon: Car },
        { id: 'drivers' as NavTab, label: 'Drivers', icon: Users },
        { id: 'collections' as NavTab, label: 'Collections', icon: WalletCards },
        { id: 'emis' as NavTab, label: 'EMI & Loans', icon: Landmark },
        { id: 'services' as NavTab, label: 'Services', icon: Wrench },
        { id: 'expenses' as NavTab, label: 'Expenses', icon: Receipt },
        { id: 'reports' as NavTab, label: 'Reports', icon: BarChart3 },
        { id: 'documents' as NavTab, label: 'Documents', icon: FileText },
        { id: 'owners' as NavTab, label: 'Owners', icon: UserCheck },
        { id: 'notifications' as NavTab, label: 'Notifications', icon: Bell, badge: unreadNotifCount },
        { id: 'activity' as NavTab, label: 'Activity Log', icon: History },
        { id: 'backup' as NavTab, label: 'Backup & Export', icon: Database },
        { id: 'settings' as NavTab, label: 'Settings', icon: Settings },
        { id: 'profile' as NavTab, label: 'Profile', icon: UserIcon },
      ];
    } else if (role === 'driver') {
      return [
        { id: 'dashboard' as NavTab, label: 'Dashboard', icon: LayoutDashboard },
        { id: 'autos' as NavTab, label: 'My Auto', icon: Car },
        { id: 'collections' as NavTab, label: 'My Collections', icon: WalletCards },
        { id: 'services' as NavTab, label: 'My Services', icon: Wrench },
        { id: 'documents' as NavTab, label: 'My Documents', icon: FileText },
        { id: 'profile' as NavTab, label: 'Profile', icon: UserIcon },
      ];
    } else if (role === 'owner') {
      const items = [
        { id: 'dashboard' as NavTab, label: 'Dashboard', icon: LayoutDashboard },
      ];

      if (ownerPerms?.viewVehicles) {
        items.push({ id: 'autos' as NavTab, label: 'Autos', icon: Car });
      }
      if (ownerPerms?.viewCollections) {
        items.push({ id: 'collections' as NavTab, label: 'Collections', icon: WalletCards });
      }
      if (ownerPerms?.viewFinancialReports) {
        items.push({ id: 'reports' as NavTab, label: 'Reports', icon: BarChart3 });
      }
      if (ownerPerms?.viewServiceReports) {
        items.push({ id: 'services' as NavTab, label: 'Services', icon: Wrench });
      }
      if (ownerPerms?.viewDocuments) {
        items.push({ id: 'documents' as NavTab, label: 'Documents', icon: FileText });
      }
      if (ownerPerms?.viewEmiLoans !== false) {
        items.push({ id: 'emis' as NavTab, label: 'EMI & Loans', icon: Landmark });
      }

      items.push({ id: 'profile' as NavTab, label: 'Profile', icon: UserIcon });
      return items;
    }

    return [];
  };

  const navItems = getNavItems();

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      <aside
        id="app-sidebar"
        className={`fixed inset-y-0 left-0 z-50 transform ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:relative lg:translate-x-0 w-64 bg-slate-900/95 lg:bg-slate-900/40 backdrop-blur-xl border-r border-white/10 text-slate-300 flex flex-col shrink-0 min-h-screen p-5 transition-transform duration-300 ease-in-out`}
      >
        {/* Brand Header */}
      <div className="mb-6 pb-5 border-b border-white/10 flex items-center space-x-3">
        <div className="w-10 h-10 rounded-xl bg-violet-500/20 text-violet-400 border border-violet-500/30 flex items-center justify-center font-black shadow-lg shadow-violet-500/10">
          <Car className="w-6 h-6 stroke-[2.5]" />
        </div>
        <div>
          <h1 className="text-base font-bold text-white tracking-tight uppercase italic">
            Pandithji <span className="text-violet-400 font-black">Auto's</span>
          </h1>
          <p className="text-slate-400 text-[9px] tracking-widest mt-0.5 font-semibold">
            FLEET MANAGEMENT SYSTEM
          </p>
        </div>
      </div>

      {/* Role Indicator Banner */}
      <div className="mb-4 px-3 py-2 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 rounded-full bg-violet-400 animate-pulse" />
          <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
            {role === 'admin' ? 'Owner Admin' : role === 'driver' ? 'Driver Portal' : 'Owner View'}
          </span>
        </div>
        <span className="text-[10px] text-violet-400 bg-violet-500/10 border border-violet-500/20 px-2 py-0.5 rounded-full font-mono font-bold">
          v2.4
        </span>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 space-y-1 overflow-y-auto pr-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              id={`nav-${item.id}`}
              onClick={() => handleTabSelect(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-violet-500/20 text-violet-400 border border-violet-500/30 font-bold shadow-md shadow-violet-500/10'
                  : 'text-slate-400 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-violet-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge && item.badge > 0 ? (
                <span className="px-2 py-0.5 text-[10px] font-bold bg-violet-500 text-slate-950 rounded-full">
                  {item.badge}
                </span>
              ) : isActive ? (
                <ChevronRight className="w-3.5 h-3.5 text-violet-400/80" />
              ) : null}
            </button>
          );
        })}
      </nav>

      {/* Account Info Footer */}
      <div className="mt-auto pt-4 border-t border-white/10">
        <div className="p-3.5 rounded-xl bg-white/5 border border-white/10">
          <p className="text-slate-500 text-[9px] uppercase font-bold tracking-wider mb-1.5">Account Profile</p>
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-violet-500 flex items-center justify-center font-black text-slate-950 text-xs shadow-md shadow-violet-500/20">
              {(user?.name || 'User').slice(0, 2).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-white font-semibold text-xs leading-none truncate">{user?.name || 'User'}</p>
              <p className="text-violet-400 text-[10px] font-mono mt-1 capitalize">{role || 'admin'} Account</p>
            </div>
          </div>
        </div>
      </div>
    </aside>
    </>
  );
};
