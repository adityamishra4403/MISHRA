import React, { useState } from 'react';
import {
  Bell,
  Search,
  LogOut,
  User as UserIcon,
  ShieldCheck,
  ChevronDown,
  RefreshCw,
  Car,
  UserCheck,
  Menu,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types/index';

interface HeaderProps {
  onOpenNotifications?: () => void;
  unreadCount?: number;
  notificationsCount?: number;
  onRefreshData?: () => void;
  activeTab?: string;
  onMenuToggle?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenNotifications,
  unreadCount = 0,
  notificationsCount,
  onRefreshData,
  onMenuToggle,
}) => {
  const { user } = useAuth();
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  if (!user) return null;

  const displayUnread = unreadCount ?? notificationsCount ?? 0;
  const userName = user?.name || 'User';

  return (
    <header
      id="app-header"
      className="sticky top-0 z-30 h-16 bg-slate-900/40 backdrop-blur-xl border-b border-white/10 px-4 md:px-6 flex items-center justify-between shadow-xs"
    >
      {/* Left Search / Title */}
      <div className="flex items-center space-x-3 md:space-x-4">
        <button
          onClick={onMenuToggle}
          className="p-2 -ml-2 text-slate-300 hover:text-white bg-transparent hover:bg-white/10 rounded-lg lg:hidden transition-colors"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div className="relative hidden md:block w-72">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            id="global-search-input"
            type="text"
            placeholder="Search auto, driver, receipt, loan..."
            className="w-full pl-9 pr-4 py-1.5 text-xs bg-white/5 border border-white/10 rounded-lg text-white placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-violet-500/50"
          />
        </div>
      </div>

      {/* Right Controls & Quick Demo Switcher */}
      <div className="flex items-center space-x-3">

        {/* Refresh Data Button */}
        {onRefreshData && (
          <button
            id="btn-refresh-data"
            onClick={onRefreshData}
            title="Refresh Data"
            className="p-2 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        )}

        {/* Notification Bell */}
        <button
          id="btn-notifications-bell"
          onClick={() => onOpenNotifications && onOpenNotifications()}
          className="relative p-2 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-colors"
        >
          <Bell className="w-4 h-4" />
          {displayUnread > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white rounded-full text-[10px] font-bold flex items-center justify-center animate-bounce shadow-md shadow-rose-500/30">
              {displayUnread}
            </span>
          )}
        </button>

        {/* User Profile Dropdown */}
        <div className="relative">
          <button
            id="user-profile-menu-button"
            onClick={() => setUserDropdownOpen(!userDropdownOpen)}
            className="flex items-center space-x-2.5 p-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors"
          >
            {user.avatarUrl ? (
              <img
                src={user.avatarUrl}
                alt={userName}
                className="w-8 h-8 rounded-lg object-cover ring-2 ring-violet-500/30"
              />
            ) : (
              <div className="w-8 h-8 rounded-lg bg-violet-500 text-slate-950 font-black flex items-center justify-center text-xs">
                {userName.charAt(0).toUpperCase()}
              </div>
            )}
            <div className="text-left hidden sm:block">
              <p className="text-xs font-bold text-white leading-tight">{userName}</p>
              <p className="text-[10px] text-violet-400 uppercase font-mono">{user.role}</p>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {/* Profile Dropdown Menu */}
          {userDropdownOpen && (
            <div
              id="user-dropdown-menu"
              className="absolute right-0 mt-2 w-56 bg-slate-900/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl py-2 z-50 animate-in fade-in duration-150"
            >
              <div className="px-4 py-2 border-b border-white/10">
                <p className="text-xs font-bold text-white">{user.name}</p>
                <p className="text-xs text-slate-400 truncate">{user.email}</p>
              </div>

              
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
