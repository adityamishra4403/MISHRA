import React, { useState } from 'react';
import { History, Search, Shield, User, Clock } from 'lucide-react';
import { ActivityLog } from '../../types/index';
import { Badge } from '../common/Badge';

interface ActivityLogViewProps {
  logs: ActivityLog[];
}

export const ActivityLogView: React.FC<ActivityLogViewProps> = ({ logs }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLogs = (logs || []).filter((l) => {
    const term = (searchTerm || '').toLowerCase();
    return (
      (l.performedByName || '').toLowerCase().includes(term) ||
      (l.actionType || '').toLowerCase().includes(term) ||
      (l.description || '').toLowerCase().includes(term)
    );
  });

  return (
    <div id="activity-log-module" className="space-y-6 animate-in fade-in duration-200">
      <div>
        <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 rounded-full text-[11px] font-bold uppercase tracking-wider mb-1">
          <Shield className="w-3.5 h-3.5" />
          <span>Admin Audit Trail</span>
        </div>
        <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">System Activity Logs</h2>
        <p className="text-xs text-slate-500">
          Complete security audit trail of all driver assignments, payment records, edits & admin actions
        </p>
      </div>

      <div className="bg-white dark:bg-slate-900 p-4 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
        <div className="relative max-w-md">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input
            id="search-activity-logs"
            type="text"
            placeholder="Search performed by, action type, description..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-hidden"
          />
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 uppercase font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-4 py-3">Timestamp</th>
                <th className="px-4 py-3">User</th>
                <th className="px-4 py-3">Action Type</th>
                <th className="px-4 py-3">Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                  <td className="px-4 py-3 font-mono text-slate-500">{log.timestamp}</td>
                  <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">
                    {log.performedByName} <span className="text-[10px] text-slate-400 font-normal">({log.userRole})</span>
                  </td>
                  <td className="px-4 py-3 font-mono">
                    <Badge variant="info">{log.actionType}</Badge>
                  </td>
                  <td className="px-4 py-3 text-slate-700 dark:text-slate-300">{log.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
