import React, { useState } from 'react';
import { Trash2, Receipt, Search, Plus, DollarSign, Calendar, Tag, AlertCircle } from 'lucide-react';
import { ExpenseRecord, ExpenseCategory, Auto } from '../../types/index';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';

interface ExpenseListProps {
  expenses: ExpenseRecord[];
  autos: Auto[];
  userRole: string;
  onAddExpense: (data: Partial<ExpenseRecord>) => Promise<void>;
  onDeleteExpense?: (id: string) => Promise<void>;
}

export const ExpenseList: React.FC<ExpenseListProps> = ({
  expenses,
  autos,
  userRole,
  onAddExpense,
  onDeleteExpense,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form State
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [autoId, setAutoId] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('Spare parts');
  const [amount, setAmount] = useState(1500);
  const [description, setDescription] = useState('');
  const [notes, setNotes] = useState('');

  const isAdmin = userRole === 'admin';

  const categories: ExpenseCategory[] = ['Service', 'Repair', 'Spare parts', 'Insurance', 'PUC', 'Tax', 'Permit', 'Other'];

  const filteredExpenses = (expenses || []).filter((exp) => {
    const term = (searchTerm || '').toLowerCase();
    const matchesSearch =
      (exp.description || '').toLowerCase().includes(term) ||
      (exp.autoRegNumber && exp.autoRegNumber.toLowerCase().includes(term));
    const matchesCat = categoryFilter === 'all' || exp.category === categoryFilter;
    return matchesSearch && matchesCat;
  });

  const totalExpenseSum = filteredExpenses.reduce((acc, e) => acc + e.amount, 0);

  const handleOpenAdd = () => {
    if (autos.length > 0) setAutoId(autos[0].id);
    setDescription('');
    setNotes('');
    setIsModalOpen(true);
  };


  const handleDeleteExpense = async (expense: ExpenseRecord) => {
    if (onDeleteExpense) {
      await onDeleteExpense(expense.id);
      
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onAddExpense({
      date,
      autoId: autoId || undefined,
      category,
      amount: Number(amount),
      description,
      notes,
    });
    setIsModalOpen(false);
  };

  return (
    <div id="expenses-module" className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Fleet Expense Tracking</h2>
          <p className="text-xs text-slate-500">Track spare parts, repairs, insurance renewals, permits & general overhead</p>
        </div>

        {isAdmin && (
          <button
            id="btn-add-expense"
            onClick={handleOpenAdd}
            className="px-4 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs flex items-center space-x-2 transition-all shadow-md shadow-rose-600/20 shrink-0"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Add Expense</span>
          </button>
        )}
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input
            id="search-expenses-input"
            type="text"
            placeholder="Search description, auto registration..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-hidden"
          />
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <select
            id="filter-expense-category"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-semibold"
          >
            <option value="all">All Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <div className="px-3 py-2 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 rounded-xl font-bold font-mono">
            Total: ₹{totalExpenseSum.toLocaleString('en-IN')}
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 uppercase font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">Auto Reg</th>
                <th className="px-4 py-3">Description</th>
                <th className="px-4 py-3 text-right">Amount (₹)</th>
                {onDeleteExpense && <th className="px-4 py-3 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredExpenses.map((exp) => (
                <tr key={exp.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                  <td className="px-4 py-3 font-mono text-slate-500">{exp.date}</td>
                  <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">
                    <Badge variant="neutral">{exp.category}</Badge>
                  </td>
                  <td className="px-4 py-3 font-mono font-bold text-slate-700 dark:text-slate-300">
                    {exp.autoRegNumber || 'General Fleet'}
                  </td>
                  <td className="px-4 py-3 text-slate-600 dark:text-slate-300">{exp.description}</td>
                  <td className="px-4 py-3 text-right font-black text-rose-600 dark:text-rose-400 font-mono text-sm">
                    ₹{exp.amount.toLocaleString('en-IN')}
                  </td>
                  {onDeleteExpense && (
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => handleDeleteExpense(exp)}
                        className="p-1.5 px-3 flex items-center space-x-1 text-rose-500 font-bold hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors inline-flex"
                        title="Delete Expense"
                      >
                        <Trash2 className="w-4 h-4" /> <span className="hidden sm:inline">Delete</span></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Add Fleet Expense Record"
        subtitle="Log operational costs, spare parts, insurance renewals or PUC fees"
      >
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Expense Date *</label>
              <input
                id="input-expense-date"
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Expense Category *</label>
              <select
                id="select-expense-category"
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
              >
                {categories.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Auto Registration (Optional)</label>
              <select
                id="select-expense-auto"
                value={autoId}
                onChange={(e) => setAutoId(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              >
                <option value="">General Overhead (No Specific Auto)</option>
                {autos.map((a) => (
                  <option key={a.id} value={a.id}>{a.registrationNumber} ({a.model})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Amount Paid (₹) *</label>
              <input
                id="input-expense-amount"
                type="number"
                required
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-rose-600"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Description *</label>
            <input
              id="input-expense-description"
              type="text"
              required
              placeholder="e.g. New Battery installation at Exide store"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
          </div>

          <button
            id="btn-submit-expense"
            type="submit"
            className="w-full py-3 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-sm transition-all shadow-md"
          >
            Save Expense Entry
          </button>
        </form>
      </Modal>
    </div>
  );
};
