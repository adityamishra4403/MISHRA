import React, { useState } from 'react';
import { Wrench, Search, Plus, Calendar, DollarSign } from 'lucide-react';
import { ServiceRecord, Auto } from '../../types/index';
import { Modal } from '../common/Modal';

interface ServiceListProps {
  services: ServiceRecord[];
  autos: Auto[];
  userRole: string;
  onAddService: (data: Partial<ServiceRecord>) => Promise<void>;
}

export const ServiceList: React.FC<ServiceListProps> = ({
  services,
  autos,
  userRole,
  onAddService,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);

  // Form State
  const [autoId, setAutoId] = useState('');
  const [serviceDate, setServiceDate] = useState(new Date().toISOString().split('T')[0]);
  const [currentKm, setCurrentKm] = useState(40000);
  const [serviceType, setServiceType] = useState<'Routine' | 'Major Repair' | 'Oil Change' | 'Breakdown' | 'Bodywork'>('Routine');
  const [garageName, setGarageName] = useState('Sri Manjunatha Auto Garage');
  const [partsReplaced, setPartsReplaced] = useState('Engine Oil, Spark Plug');
  const [labourCost, setLabourCost] = useState(500);
  const [partsCost, setPartsCost] = useState(1000);
  const [nextServiceDate, setNextServiceDate] = useState('');
  const [nextServiceKm, setNextServiceKm] = useState(45000);
  const [notes, setNotes] = useState('');

  const isAdmin = userRole === 'admin';

  const filteredServices = (services || []).filter((s) => {
    const term = (searchTerm || '').toLowerCase();
    return (
      (s.autoRegNumber || '').toLowerCase().includes(term) ||
      (s.garageName || '').toLowerCase().includes(term) ||
      (s.partsReplaced || '').toLowerCase().includes(term)
    );
  });

  const handleOpenLog = () => {
    if (autos.length > 0) setAutoId(autos[0].id);
    setIsLogModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onAddService({
      autoId,
      serviceDate,
      currentKm: Number(currentKm),
      serviceType,
      garageName,
      partsReplaced,
      labourCost: Number(labourCost),
      partsCost: Number(partsCost),
      nextServiceDate,
      nextServiceKm: Number(nextServiceKm),
      notes,
    });
    setIsLogModalOpen(false);
  };

  return (
    <div id="services-module" className="space-y-6 animate-in fade-in duration-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">Auto Service Management</h2>
          <p className="text-xs text-slate-500">Track garage repairs, spare parts cost, current KM & service reminders</p>
        </div>

        {isAdmin && (
          <button
            id="btn-log-service"
            onClick={handleOpenLog}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center space-x-2 transition-all shadow-md shadow-blue-600/20 shrink-0"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Log Maintenance / Service</span>
          </button>
        )}
      </div>

      <div className="bg-white dark:bg-slate-900 p-4 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs">
        <div className="relative max-w-md">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input
            id="search-services-input"
            type="text"
            placeholder="Search auto, garage name, parts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-hidden"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredServices.map((srv) => (
          <div
            key={srv.id}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-3 hover:border-blue-500/40 transition-all"
          >
            <div className="flex justify-between items-start">
              <div>
                <span className="text-base font-black font-mono text-slate-900 dark:text-white block">
                  {srv.autoRegNumber}
                </span>
                <span className="text-xs font-bold text-blue-600 dark:text-blue-400">{srv.serviceType} Service</span>
              </div>
              <span className="text-xs font-bold font-mono text-slate-500">{srv.serviceDate}</span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl space-y-1 text-xs">
              <div className="flex justify-between text-slate-500">
                <span>Garage:</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{srv.garageName}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Current Reading:</span>
                <span className="font-mono">{srv.currentKm} KM</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Parts Cost + Labour:</span>
                <span className="font-mono">₹{srv.partsCost} + ₹{srv.labourCost}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-xs">
              <span className="text-slate-500">Total Cost:</span>
              <span className="text-base font-black text-slate-900 dark:text-white font-mono">
                ₹{srv.totalServiceCost.toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        ))}
      </div>

      <Modal
        isOpen={isLogModalOpen}
        onClose={() => setIsLogModalOpen(false)}
        title="Log Vehicle Service / Repair"
        subtitle="Record parts replaced, garage bills, labour costs & next service schedule"
      >
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Select Auto *</label>
            <select
              id="select-srv-auto"
              required
              value={autoId}
              onChange={(e) => setAutoId(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
            >
              {autos.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.registrationNumber} ({a.model})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Service Date</label>
              <input
                id="input-srv-date"
                type="date"
                required
                value={serviceDate}
                onChange={(e) => setServiceDate(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Current Odometer KM</label>
              <input
                id="input-srv-km"
                type="number"
                required
                value={currentKm}
                onChange={(e) => setCurrentKm(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Service Type</label>
              <select
                id="select-srv-type"
                value={serviceType}
                onChange={(e) => setServiceType(e.target.value as any)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              >
                <option value="Routine">Routine Maintenance</option>
                <option value="Major Repair">Major Repair</option>
                <option value="Oil Change">Oil Change</option>
                <option value="Breakdown">Breakdown Emergency</option>
                <option value="Bodywork">Bodywork / Paint</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Garage / Provider Name</label>
              <input
                id="input-srv-garage"
                type="text"
                required
                value={garageName}
                onChange={(e) => setGarageName(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Parts Replaced / Repair Work</label>
            <input
              id="input-srv-parts"
              type="text"
              placeholder="e.g. Engine Oil, Spark Plug, Clutch Cable"
              value={partsReplaced}
              onChange={(e) => setPartsReplaced(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Parts Cost (₹)</label>
              <input
                id="input-srv-parts-cost"
                type="number"
                value={partsCost}
                onChange={(e) => setPartsCost(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Labour Charge (₹)</label>
              <input
                id="input-srv-labour-cost"
                type="number"
                value={labourCost}
                onChange={(e) => setLabourCost(Number(e.target.value))}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold"
              />
            </div>
          </div>

          <div className="p-3 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 rounded-xl flex justify-between items-center font-bold">
            <span className="text-blue-800 dark:text-blue-300">Total Service Bill:</span>
            <span className="text-blue-600 dark:text-blue-400 font-mono text-sm">
              ₹{(Number(labourCost) + Number(partsCost)).toLocaleString('en-IN')}
            </span>
          </div>

          <button
            id="btn-submit-service-log"
            type="submit"
            className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-sm transition-all shadow-md"
          >
            Save Service Record
          </button>
        </form>
      </Modal>
    </div>
  );
};
