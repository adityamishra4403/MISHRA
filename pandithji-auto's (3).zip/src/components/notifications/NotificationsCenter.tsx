import React from 'react';
import { Bell, AlertTriangle, Calendar, CheckCircle2, Clock, Wrench, ShieldAlert } from 'lucide-react';
import { AppNotification } from '../../types/index';
import { Badge } from '../common/Badge';

interface NotificationsCenterProps {
  notifications: AppNotification[];
  userRole: string;
}

export const NotificationsCenter: React.FC<NotificationsCenterProps> = ({
  notifications,
  userRole,
}) => {
  return (
    <div id="notifications-module" className="space-y-6 animate-in fade-in duration-200">
      <div>
        <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">System Reminders & Alerts</h2>
        <p className="text-xs text-slate-500">
          Automated notification center for pending collections, vehicle document expiries, EMI due dates & service reminders
        </p>
      </div>

      <div className="space-y-3">
        {notifications
          .filter((notif) => {
            if (userRole === 'driver') {
              if (notif.type === 'puc' || notif.type === 'insurance' || notif.type === 'emi') {
                return false;
              }
            }
            return true;
          })
          .map((notif) => (
          <div
            key={notif.id}
            className={`p-4 border rounded-2xl shadow-xs flex items-start justify-between gap-4 transition-all ${
              notif.priority === 'urgent'
                ? 'bg-rose-50/60 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/50'
                : notif.priority === 'warning'
                ? 'bg-indigo-50/60 dark:bg-indigo-950/20 border-indigo-200 dark:border-indigo-900/50'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
            }`}
          >
            <div className="flex items-start space-x-3">
              <div
                className={`p-2.5 rounded-xl shrink-0 ${
                  notif.priority === 'urgent'
                    ? 'bg-rose-500 text-white'
                    : notif.priority === 'warning'
                    ? 'bg-indigo-500 text-slate-950'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                <Bell className="w-5 h-5" />
              </div>

              <div>
                <div className="flex items-center space-x-2">
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">{notif.title}</h3>
                  <Badge variant={notif.priority === 'urgent' ? 'danger' : notif.priority === 'warning' ? 'warning' : 'info'}>
                    {(notif?.priority || 'INFO').toUpperCase()}
                  </Badge>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">{notif.message}</p>
                <span className="text-[10px] text-slate-400 font-mono mt-1 block">{notif.createdAt}</span>
              </div>
            </div>
          </div>
        ))}

        {notifications.length === 0 && (
          <div className="p-12 text-center text-slate-400 text-xs bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
            No active reminders or alerts. All collections, document expiries & EMIs are up to date!
          </div>
        )}
      </div>
    </div>
  );
};
