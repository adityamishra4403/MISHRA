import React, { useState } from 'react';
import { Car, Lock, ArrowRight, AlertCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const LoginForm: React.FC = () => {
  const { login } = useAuth();
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await login('');
    } catch (err: any) {
      setError(err.message || 'Login failed. Please check credentials.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      id="login-page-container"
      className="min-h-screen bg-[#0f172a] bg-gradient-to-br from-slate-900 via-[#0f172a] to-violet-950/30 text-slate-100 flex items-center justify-center p-4 relative overflow-hidden font-sans"
    >
      {/* Background Decor Shapes */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-violet-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-sm bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 shadow-2xl relative z-10">
        {/* Header Branding */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-violet-500/20 text-violet-400 border border-violet-500/30 shadow-lg shadow-violet-500/10 mb-3">
            <Car className="w-9 h-9 stroke-[2.5]" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white uppercase italic">
            Pandithji <span className="text-violet-400 font-black">Auto's</span>
          </h1>
          <p className="text-xs font-semibold text-slate-400 mt-1 uppercase tracking-widest">
            Admin Portal
          </p>
        </div>

        {error && (
          <div className="mb-6 p-3.5 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center space-x-2.5">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-400">Email / Username</label>
            <input type="text" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500" placeholder="admin@pandithjiautos.com" />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-400">Password</label>
            <input type="password" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500" placeholder="••••••••" />
          </div>
          <button
            id="login-submit-btn"
            type="submit"
            disabled={submitting}
            className="w-full py-3 mt-4 bg-violet-500 hover:bg-violet-400 text-slate-950 font-extrabold rounded-xl text-sm transition-all shadow-lg shadow-violet-500/20 flex items-center justify-center space-x-2"
          >
            <span>{submitting ? 'Authenticating...' : 'Sign In'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
