import {
  User,
  Auto,
  Driver,
  CollectionRecord,
  ServiceRecord,
  ExpenseRecord,
  EmiLoan,
  EmiPayment,
  VehicleDocument,
  NotificationItem,
  ActivityLog,
  OwnerPermissions,
} from '../types/index';

const API_BASE = '/api';

export function getAuthToken(): string | null {
  return localStorage.getItem('pandithji_token');
}

export function setAuthToken(token: string) {
  localStorage.setItem('pandithji_token', token);
}

export function removeAuthToken() {
  localStorage.removeItem('pandithji_token');
}

export function getCurrentDemoUserId(): string | null {
  return localStorage.getItem('pandithji_demo_user_id');
}

export function setCurrentDemoUserId(userId: string | null) {
  if (userId) {
    localStorage.setItem('pandithji_demo_user_id', userId);
  } else {
    localStorage.removeItem('pandithji_demo_user_id');
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const demoUserId = 'usr_admin';

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  if (demoUserId) {
    headers['x-user-id'] = demoUserId;
  }

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(errorData.error || `HTTP error ${response.status}`);
  }

  return response.json();
}

export const api = {

  // Passwords and Profile
  changePassword: (oldPassword: string, newPassword: string) =>
    request<{ success: boolean; message: string }>('/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ oldPassword, newPassword })
    }),
  updateProfilePicture: (avatarUrl: string) =>
    request<{ success: boolean; user: User }>('/auth/profile-picture', {
      method: 'POST',
      body: JSON.stringify({ avatarUrl })
    }),

  // Auth
  login: (identity: string, password?: string, role?: string) =>
    request<{ token: string; user: User }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identity, password, role }),
    }),

  getMe: () => request<{ user: User }>('/auth/me'),

  // Autos
  getAutos: async () => {
    try {
      const res = await request<{ autos: Auto[] }>('/autos');
      return res.autos || [];
    } catch {
      return [];
    }
  },
  addAuto: (data: Partial<Auto>) =>
    request<{ auto: Auto }>('/autos', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  updateAuto: (id: string, data: Partial<Auto>) =>
    request<{ auto: Auto }>(`/autos/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  deleteAuto: (id: string) =>
    request<{ success: boolean }>(`/autos/${id}`, {
      method: 'DELETE',
    }),
  assignAuto: (id: string, driverId: string, weeklyCollectionAmount?: number) =>
    request<{ auto: Auto; driver: Driver; assignment: any }>(`/autos/${id}/assign`, {
      method: 'POST',
      body: JSON.stringify({ driverId, weeklyCollectionAmount }),
    }),

  // Drivers
  getDrivers: async () => {
    try {
      const res = await request<{ drivers: Driver[] }>('/drivers');
      return res.drivers || [];
    } catch {
      return [];
    }
  },
  addDriver: (data: Partial<Driver>) =>
    request<{ driver: Driver }>('/drivers', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  updateDriver: (id: string, data: Partial<Driver>) =>
    request<{ driver: Driver }>(`/drivers/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  deleteDriver: (id: string) =>
    request<{ success: boolean }>(`/drivers/${id}`, {
      method: 'DELETE',
    }),

  // Collections
  getCollections: async () => {
    try {
      const res = await request<{ collections: CollectionRecord[] }>('/collections');
      return res.collections || [];
    } catch {
      return [];
    }
  },
  addCollection: (data: Partial<CollectionRecord>) =>
    request<{ collection: CollectionRecord }>('/collections', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  updateCollection: (id: string, data: Partial<CollectionRecord>) =>
    request<{ collection: CollectionRecord }>(`/collections/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  // Services
  getServices: async () => {
    try {
      const res = await request<{ services: ServiceRecord[] }>('/services');
      return res.services || [];
    } catch {
      return [];
    }
  },
  addService: (data: Partial<ServiceRecord>) =>
    request<{ service: ServiceRecord }>('/services', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Expenses
  getExpenses: async () => {
    try {
      const res = await request<{ expenses: ExpenseRecord[] }>('/expenses');
      return res.expenses || [];
    } catch {
      return [];
    }
  },
  addExpense: (data: Partial<ExpenseRecord>) =>
    request<{ expense: ExpenseRecord }>('/expenses', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // EMI & Loans
  getEmis: () => request<{ emiLoans: EmiLoan[]; emiPayments: EmiPayment[] }>('/emis'),
  getEmiLoans: async () => {
    try {
      const res = await request<{ emiLoans: EmiLoan[]; emiPayments: EmiPayment[] }>('/emis');
      return res?.emiLoans || [];
    } catch {
      return [];
    }
  },
  getEmiPayments: async () => {
    try {
      const res = await request<{ emiLoans: EmiLoan[]; emiPayments: EmiPayment[] }>('/emis');
      return res?.emiPayments || [];
    } catch {
      return [];
    }
  },
  addEmiLoan: (data: Partial<EmiLoan>) =>
    request<{ loan: EmiLoan }>('/emis', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  payEmi: (loanId: string, paymentData: Partial<EmiPayment>) =>
    request<{ payment: EmiPayment; loan: EmiLoan }>(`/emis/${loanId}/pay`, {
      method: 'POST',
      body: JSON.stringify(paymentData),
    }),

  // Documents
  getDocuments: async () => {
    try {
      const res = await request<{ documents: VehicleDocument[] }>('/documents');
      return res?.documents || [];
    } catch {
      return [];
    }
  },
  addDocument: (data: Partial<VehicleDocument>) =>
    request<{ document: VehicleDocument }>('/documents', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  updateDocument: (id: string, data: Partial<VehicleDocument>) =>
    request<{ document: VehicleDocument }>(`/documents/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  // Owners
  getOwners: () => request<{ owners: User[] }>('/owners'),
  getUsers: async () => {
    try {
      const res = await request<{ owners: User[] }>('/owners');
      return res?.owners || [];
    } catch {
      return [];
    }
  },
  addOwner: (data: any) =>
    request<{ owner: User }>('/owners', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  updateOwnerPermissions: (ownerId: string, permissions: Partial<OwnerPermissions>) =>
    request<{ owner: User }>(`/owners/${ownerId}/permissions`, {
      method: 'PUT',
      body: JSON.stringify({ permissions }),
    }),

  // Assignments
  getAssignments: async () => {
    return [];
  },

  // Notifications
  getNotifications: async () => {
    try {
      const res = await request<{ notifications: NotificationItem[] }>('/notifications');
      return res?.notifications || [];
    } catch {
      return [];
    }
  },
  markNotificationRead: (id: string) =>
    request<{ success: boolean }>(`/notifications/${id}/read`, {
      method: 'PUT',
    }),

  // Activity Logs
  getActivityLogs: async () => {
    try {
      const res = await request<{ activityLogs: ActivityLog[] }>('/activity-logs');
      return res?.activityLogs || [];
    } catch {
      return [];
    }
  },

  
  deleteExpense: (id: string) => request<{ success: boolean }>(`/expenses/${id}`, { method: 'DELETE' }),
  deleteEmiLoan: (id: string) => request<{ success: boolean }>(`/emis/${id}`, { method: 'DELETE' }),
  deleteDocument: (id: string) => request<{ success: boolean }>(`/documents/${id}`, { method: 'DELETE' }),

  // Reports
  getReportSummary: () => request<{ summary: any }>('/reports/summary'),

  // Backup & Restore
  exportBackup: () => request<any>('/backup/export'),
  importBackup: (backup: any) =>
    request<{ success: boolean; message: string }>('/backup/restore', {
      method: 'POST',
      body: JSON.stringify({ backup }),
    }),
  restoreBackup: (backup: any) =>
    request<{ success: boolean; message: string }>('/backup/restore', {
      method: 'POST',
      body: JSON.stringify({ backup }),
    }),
};
