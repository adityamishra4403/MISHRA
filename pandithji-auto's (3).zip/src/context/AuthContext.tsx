import React, { createContext, useContext, useState } from 'react';
import { User } from '../types/index';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  isAuthenticated: boolean;
  login: (password: string) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const defaultAdmin: User = {
  id: 'usr_admin',
  name: 'Pandithji (Admin)',
  email: 'admin@pandithjiautos.com',
  mobile: '9845012345',
  role: 'admin',
  status: 'active',
  createdAt: new Date().toISOString()
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <AuthContext.Provider
      value={{
        user: defaultAdmin,
        loading: false,
        isAuthenticated: true,
        login: async () => {},
        logout: () => {},
        refreshUser: async () => {},
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
