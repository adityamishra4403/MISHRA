import React, { useState, useEffect } from 'react';
import { useAuth } from './context/AuthContext';
import { Sidebar, NavigationTab } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { AdminDashboard } from './components/dashboard/AdminDashboard';
import { AutoList } from './components/autos/AutoList';
import { DriverList } from './components/drivers/DriverList';
import { CollectionList } from './components/collections/CollectionList';
import { EmiList } from './components/emis/EmiList';
import { ServiceList } from './components/services/ServiceList';
import { ExpenseList } from './components/expenses/ExpenseList';
import { DocumentVault } from './components/documents/DocumentVault';
import { OwnerList } from './components/owners/OwnerList';
import { ReportsCenter } from './components/reports/ReportsCenter';
import { NotificationsCenter } from './components/notifications/NotificationsCenter';
import { ActivityLogView } from './components/activity/ActivityLogView';
import { BackupExportView } from './components/backup/BackupExportView';
import { ProfileSettings } from './components/profile/ProfileSettings';

import { api } from './lib/api';
import {
  Auto,
  Driver,
  AutoAssignment,
  CollectionRecord,
  EmiLoan,
  EmiPayment,
  ServiceRecord,
  ExpenseRecord,
  VehicleDocument,
  NotificationItem,
  User,
  ActivityLog
} from './types';

const App = () => {
  const { isAuthenticated, user, refreshUser, loading } = useAuth();
  
  const [activeTab, setActiveTab] = useState<NavigationTab>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const [autos, setAutos] = useState<Auto[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [assignments, setAssignments] = useState<AutoAssignment[]>([]);
  const [collections, setCollections] = useState<CollectionRecord[]>([]);
  const [emiLoans, setEmiLoans] = useState<EmiLoan[]>([]);
  const [emiPayments, setEmiPayments] = useState<EmiPayment[]>([]);
  const [services, setServices] = useState<ServiceRecord[]>([]);
  const [expenses, setExpenses] = useState<ExpenseRecord[]>([]);
  const [documents, setDocuments] = useState<VehicleDocument[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [logs, setLogs] = useState<ActivityLog[]>([]);

  const fetchAllData = async () => {
    if (!isAuthenticated) return;
    try {
      const [
        autosData,
        driversData,
        assignmentsData,
        collectionsData,
        emiLoansData,
        emiPaymentsData,
        servicesData,
        expensesData,
        documentsData,
        notificationsData,
        usersData,
        logsData
      ] = await Promise.all([
        api.getAutos(),
        api.getDrivers(),
        api.getAssignments(),
        api.getCollections(),
        api.getEmiLoans(),
        api.getEmiPayments(),
        api.getServices(),
        api.getExpenses(),
        api.getDocuments(),
        api.getNotifications(),
        api.getUsers(),
        api.getActivityLogs()
      ]);
      setAutos(autosData);
      setDrivers(driversData);
      setAssignments(assignmentsData);
      setCollections(collectionsData);
      setEmiLoans(emiLoansData);
      setEmiPayments(emiPaymentsData);
      setServices(servicesData);
      setExpenses(expensesData);
      setDocuments(documentsData);
      setNotifications(notificationsData);
      setUsersList(usersData);
      setLogs(logsData);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, [isAuthenticated]);

  const handleAddAuto = async (data: Partial<Auto>) => {
    await api.addAuto(data);
    await fetchAllData();
  };
  const handleUpdateAuto = async (id: string, data: Partial<Auto>) => {
    await api.updateAuto(id, data);
    await fetchAllData();
  };
  const handleAssignAuto = async (autoId: string, driverId: string, weeklyAmount: number) => {
    await api.assignAuto(autoId, driverId, weeklyAmount);
    await fetchAllData();
  };
  const handleAddDriver = async (data: Partial<Driver>) => {
    await api.addDriver(data);
    await fetchAllData();
  };
  const handleUpdateDriver = async (id: string, data: Partial<Driver>) => {
    await api.updateDriver(id, data);
    await fetchAllData();
  };
  const handleDeleteDriver = async (id: string) => {
    await api.deleteDriver(id);
    await fetchAllData();
  };

  const handleDeleteEmiLoan = async (id: string) => {
    await api.deleteEmiLoan(id);
    await fetchAllData();
  };
  const handleDeleteExpense = async (id: string) => {
    await api.deleteExpense(id);
    await fetchAllData();
  };
  const handleDeleteDocument = async (id: string) => {
    await api.deleteDocument(id);
    await fetchAllData();
  };

  const handleDeleteAuto = async (id: string) => {
    await api.deleteAuto(id);
    await fetchAllData();
  };
  const handleAddCollection = async (data: Partial<CollectionRecord>) => {
    await api.addCollection(data);
    await fetchAllData();
  };
  const handleUpdateCollection = async (id: string, data: Partial<CollectionRecord>) => {
    await api.updateCollection(id, data);
    await fetchAllData();
  };
  const handleAddEmiLoan = async (data: Partial<EmiLoan>) => {
    await api.addEmiLoan(data);
    await fetchAllData();
  };
  const handlePayEmi = async (loanId: string, data: Partial<EmiPayment>) => {
    await api.payEmi(loanId, data);
    await fetchAllData();
  };
  const handleAddService = async (data: Partial<ServiceRecord>) => {
    await api.addService(data);
    await fetchAllData();
  };
  const handleAddExpense = async (data: Partial<ExpenseRecord>) => {
    await api.addExpense(data);
    await fetchAllData();
  };
  const handleAddDocument = async (data: Partial<VehicleDocument>) => {
    await api.addDocument(data);
    await fetchAllData();
  };
  const handleUpdateDocument = async (id: string, data: Partial<VehicleDocument>) => {
    await api.updateDocument(id, data);
    await fetchAllData();
  };
  const handleAddOwner = async (data: any) => {
    await api.addOwner(data);
    await fetchAllData();
  };
  const handleUpdateOwnerPermissions = async (ownerId: string, perms: any) => {
    await api.updateOwnerPermissions(ownerId, perms);
    await fetchAllData();
  };

  

  

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-[#0f172a] to-violet-950/20 text-slate-100 flex font-sans antialiased selection:bg-violet-500 selection:text-slate-950">
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onTabChange={(tab) => { setActiveTab(tab); setIsMobileMenuOpen(false); }}
        userRole={user.role}
        ownerPermissions={user.ownerPermissions}
        unreadNotifCount={Array.isArray(notifications) ? notifications.filter(n => !n.isRead).length : 0}
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
      />
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        <Header
          activeTab={activeTab}
          notificationsCount={Array.isArray(notifications) ? notifications.length : 0}
          unreadCount={Array.isArray(notifications) ? notifications.filter(n => !n.isRead).length : 0}
          onOpenNotifications={() => setActiveTab('notifications')}
          onRefreshData={fetchAllData}
          onMenuToggle={() => setIsMobileMenuOpen(true)}
        />
        <main className="flex-1 p-4 md:p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">
          
          {activeTab === 'profile' && (
            <ProfileSettings />
          )}
          {activeTab === 'dashboard' && (
            <AdminDashboard
              autos={autos}
              drivers={drivers}
              collections={collections}
              services={services}
              expenses={expenses}
              emiLoans={emiLoans}
              notifications={notifications}
              onNavigate={setActiveTab}
            />
          )}
          {activeTab === 'autos' && (
            <AutoList
              autos={autos}
              drivers={drivers}
              assignments={assignments}
              collections={collections}
              services={services}
              expenses={expenses}
              emiLoans={emiLoans}
              userRole={user.role}
              onAddAuto={handleAddAuto}
              onUpdateAuto={handleUpdateAuto}
              onAssignAuto={handleAssignAuto}
              onDeleteAuto={handleDeleteAuto}
            />
          )}
          {activeTab === 'drivers' && (
            <DriverList
              drivers={drivers}
              autos={autos}
              collections={collections}
              userRole={user.role}
              onAddDriver={handleAddDriver}
              onUpdateDriver={handleUpdateDriver}
              onDeleteDriver={handleDeleteDriver}
            />
          )}
          {activeTab === 'collections' && (
            <CollectionList
              collections={collections}
              drivers={drivers}
              autos={autos}
              userRole={user.role}
              onAddCollection={handleAddCollection}
              onUpdateCollection={handleUpdateCollection}
            />
          )}
          {activeTab === 'emis' && (
            <EmiList
              onDeleteEmiLoan={handleDeleteEmiLoan}
              emiLoans={emiLoans}
              emiPayments={emiPayments}
              autos={autos}
              userRole={user.role}
              onAddEmiLoan={handleAddEmiLoan}
              onPayEmi={handlePayEmi}
            />
          )}
          {activeTab === 'services' && (
            <ServiceList
              services={services}
              autos={autos}
              userRole={user.role}
              onAddService={handleAddService}
            />
          )}
          {activeTab === 'expenses' && (
            <ExpenseList
              onDeleteExpense={handleDeleteExpense}
              expenses={expenses}
              autos={autos}
              userRole={user.role}
              onAddExpense={handleAddExpense}
            />
          )}
          {activeTab === 'documents' && (
            <DocumentVault
              onDeleteDocument={handleDeleteDocument}
              documents={documents}
              autos={autos}
              drivers={drivers}
              userRole={user.role}
              onAddDocument={handleAddDocument}
              onUpdateDocument={handleUpdateDocument}
            />
          )}
          {activeTab === 'owners' && (
            <OwnerList
              users={usersList}
              onAddOwner={handleAddOwner}
              onUpdatePermissions={handleUpdateOwnerPermissions}
            />
          )}
          {activeTab === 'reports' && (
            <ReportsCenter
              autos={autos}
              drivers={drivers}
              collections={collections}
              expenses={expenses}
              services={services}
            />
          )}
          {activeTab === 'notifications' && (
            <NotificationsCenter
              notifications={notifications}
              userRole={user.role}
            />
          )}
          {activeTab === 'activity' && (
            <ActivityLogView logs={logs} />
          )}
          {activeTab === 'backup' && (
            <BackupExportView onDataRestored={fetchAllData} />
          )}
        </main>
      </div>
    </div>
  );
};

export default App;
