const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf-8');
const startIdx = content.indexOf('{activeTab === \'dashboard\' && (');
const endIdx = content.indexOf('          {activeTab === \'autos\' && (');
const replacement = `{activeTab === 'dashboard' && (
            <AdminDashboard
              autos={autos}
              drivers={drivers}
              collections={collections}
              services={services}
              expenses={expenses}
              emiLoans={emiLoans}
              notifications={notifications}
              onNavigate={setActiveTab}
            />
          )}
`;
content = content.substring(0, startIdx) + replacement + content.substring(endIdx);
fs.writeFileSync('src/App.tsx', content);
