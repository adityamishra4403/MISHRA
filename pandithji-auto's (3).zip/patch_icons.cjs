const fs = require('fs');

const files = [
  'src/components/autos/AutoList.tsx',
  'src/components/drivers/DriverList.tsx',
  'src/components/emis/EmiList.tsx',
  'src/components/expenses/ExpenseList.tsx'
];

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf-8');
  
  if (!content.includes('Trash2')) {
    content = content.replace(/AlertCircle,/, 'AlertCircle, Trash2,');
    if (!content.includes('Trash2,')) {
       content = content.replace(/import \{ /, 'import { Trash2, ');
    }
  }

  // AutoList
  if (file.includes('AutoList.tsx')) {
    content = content.replace(/<AlertCircle className="w-4 h-4" \/>(\s*)<\/button>(\s*)\)}/g, '<Trash2 className="w-4 h-4" />$1</button>$2)}');
  }
  
  // DriverList
  if (file.includes('DriverList.tsx')) {
    content = content.replace(/<AlertCircle className="w-4 h-4" \/>(\s*)<\/button>(\s*)\)}/g, '<Trash2 className="w-4 h-4" />$1</button>$2)}');
  }

  // EmiList
  if (file.includes('EmiList.tsx')) {
    content = content.replace(/<AlertCircle className="w-4 h-4" \/>(\s*)<\/button>(\s*)\)}/g, '<Trash2 className="w-4 h-4" />$1</button>$2)}');
  }

  // ExpenseList
  if (file.includes('ExpenseList.tsx')) {
    content = content.replace(/<AlertCircle className="w-4 h-4" \/>(\s*)<\/button>(\s*)<\/td>(\s*)\)}/g, '<Trash2 className="w-4 h-4" />$1</button>$2</td>$3)}');
  }

  fs.writeFileSync(file, content);
});
